WINDOWS LOCK SYSTEM 2.0

Enthalten:
- Vollbild-Lockscreen
- Taskleiste während der Sperre ausgeblendet
- typische Windows-/Alt-Tab-/Alt-F4-Escape-Wege blockiert
- frei einstellbarer Entsperrcode
- Uhrzeit, Datum, Akku und Netzwerkstatus
- Logo, Farben und Texte konfigurierbar
- Fehlversuchs-Limit und Sperrzeit
- Fehlerton/Erfolgston
- lock.log
- wrong_codes.log: JEDER falsche eingegebene Code mit Zeitstempel
- optionaler Autostart
- kein Neustart nach Entsperren
- Mauszeiger bleibt sichtbar

Standard-Code: 1234
Mit "python set_code.py" ändern.

Falsche Codes werden in wrong_codes.log gespeichert, z.B.:
[2026-10-05 17:20:01] FALSCHER CODE: 9999

Der korrekte Code wird nicht in wrong_codes.log geschrieben.

WICHTIG:
Das ist ein Software-Lockscreen. Strg+Alt+Entf und geschützte Windows-Sicherheitsfunktionen
können von einer normalen Anwendung nicht vollständig blockiert werden.
Für einen echten Kiosk-PC zusätzlich Windows Assigned Access/Kiosk Mode verwenden.
