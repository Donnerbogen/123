#!/usr/bin/env bash
set -Eeuo pipefail
HERE="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
if [[ ! -f "$HERE/start-linux.sh" ]]; then
  echo "FEHLER: start-linux.sh wurde nicht gefunden." >&2
  exit 1
fi
exec bash "$HERE/start-linux.sh"
