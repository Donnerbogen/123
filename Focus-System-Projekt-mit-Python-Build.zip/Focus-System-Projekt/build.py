#!/usr/bin/env python3
# Focus System – einmaliger Windows-Build ohne lokal installiertes Node.js/npm.
# Benötigt: Windows 10/11, Python 3.10+ und Internet für den ersten Build.
# Node.js wird in .build-tools abgelegt und nicht systemweit installiert.

from __future__ import annotations
import json
import os
import platform
import shutil
import subprocess
import sys
import urllib.request
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent
TOOLS = ROOT / ".build-tools"
NODE_DIR = TOOLS / "node"
DIST = ROOT / "dist"
NODE_INDEX = "https://nodejs.org/dist/index.json"

def fail(message: str, code: int = 1) -> None:
    print(f"\nFEHLER: {message}")
    input("\nZum Beenden Enter drücken ...")
    raise SystemExit(code)

def download(url: str, destination: Path) -> None:
    destination.parent.mkdir(parents=True, exist_ok=True)
    request = urllib.request.Request(url, headers={"User-Agent": "Focus-System-Builder/3.0"})
    with urllib.request.urlopen(request, timeout=60) as response, destination.open("wb") as out:
        shutil.copyfileobj(response, out)

def get_portable_node() -> tuple[Path, Path]:
    if platform.system() != "Windows":
        fail("Dieser Build erzeugt eine Windows-Anwendung und muss unter Windows ausgeführt werden.")
    if platform.machine().lower() not in ("amd64", "x86_64"):
        fail("Dieser Build ist derzeit für Windows x64 vorgesehen.")

    node_exe = NODE_DIR / "node.exe"
    npm_cmd = NODE_DIR / "npm.cmd"
    if node_exe.exists() and npm_cmd.exists():
        return node_exe, npm_cmd

    print("Suche aktuelle Node.js-LTS-Version ...")
    try:
        with urllib.request.urlopen(NODE_INDEX, timeout=30) as r:
            versions = json.loads(r.read().decode("utf-8"))
        lts = next(v for v in versions if v.get("lts"))
        version = lts["version"]
        archive = f"node-{version}-win-x64.zip"
        url = f"https://nodejs.org/dist/{version}/{archive}"
        zip_path = TOOLS / archive
        print(f"Lade portable Node.js-Version {version} herunter ...")
        download(url, zip_path)
        temp = TOOLS / "extract"
        if temp.exists():
            shutil.rmtree(temp)
        temp.mkdir(parents=True)
        with zipfile.ZipFile(zip_path) as z:
            z.extractall(temp)
        extracted = temp / f"node-{version}-win-x64"
        if not extracted.exists():
            fail("Das heruntergeladene Node.js-Archiv hat eine unerwartete Struktur.")
        if NODE_DIR.exists():
            shutil.rmtree(NODE_DIR)
        shutil.move(str(extracted), str(NODE_DIR))
        shutil.rmtree(temp, ignore_errors=True)
        zip_path.unlink(missing_ok=True)
    except Exception as exc:
        fail(f"Node.js konnte nicht automatisch bereitgestellt werden: {exc}")

    if not node_exe.exists() or not npm_cmd.exists():
        fail("Portable Node.js/npm wurde nicht vollständig entpackt.")
    return node_exe, npm_cmd

def run(command: list[str], *, cwd: Path, env: dict[str, str]) -> None:
    print("\n> " + subprocess.list2cmdline(command))
    result = subprocess.run(command, cwd=str(cwd), env=env)
    if result.returncode != 0:
        fail(f"Ein Build-Schritt ist mit Exit-Code {result.returncode} fehlgeschlagen.", result.returncode)

def main() -> None:
    if sys.version_info < (3, 10):
        fail("Bitte Python 3.10 oder neuer für den einmaligen Build verwenden.")
    if not (ROOT / "package.json").exists() or not (ROOT / "src" / "main.js").exists():
        fail("Projektdateien fehlen. Bitte build.py im unveränderten Projektordner starten.")

    print("=" * 62)
    print("FOCUS SYSTEM 3.0 – PORTABLER WINDOWS-BUILD")
    print("=" * 62)
    print("Python wird nur für diesen Build verwendet.")
    print("Node.js und npm werden projektlokal bereitgestellt, nicht installiert.")
    node_exe, npm_cmd = get_portable_node()

    env = os.environ.copy()
    env["PATH"] = str(NODE_DIR) + os.pathsep + env.get("PATH", "")
    env["npm_config_audit"] = "false"
    env["npm_config_fund"] = "false"

    print("\nInstalliere Build-Abhängigkeiten im Projektordner ...")
    npm_cli = NODE_DIR / "node_modules" / "npm" / "bin" / "npm-cli.js"
    if not npm_cli.exists():
        fail("Die npm-CLI wurde im portablen Node.js-Paket nicht gefunden.")
    run([str(node_exe), str(npm_cli), "install", "--no-audit", "--no-fund"], cwd=ROOT, env=env)

    print("\nErstelle portable Windows-Anwendung ...")
    run([str(node_exe), str(npm_cli), "run", "build:win"], cwd=ROOT, env=env)

    unpacked = DIST / "win-unpacked"
    if not unpacked.exists():
        # electron-builder dir target normally produces win-unpacked.
        candidates = [p for p in DIST.iterdir() if p.is_dir() and (p / "Focus System.exe").exists()] if DIST.exists() else []
        unpacked = candidates[0] if candidates else unpacked
    exe = unpacked / "Focus System.exe"
    if not exe.exists():
        fail("Build beendet, aber 'Focus System.exe' wurde nicht gefunden.")

    zip_target = ROOT / "Focus-System-Windows.zip"
    zip_target.unlink(missing_ok=True)
    print("\nPacke portable Anwendung ...")
    with zipfile.ZipFile(zip_target, "w", zipfile.ZIP_DEFLATED, compresslevel=6) as z:
        for item in unpacked.rglob("*"):
            if item.is_file():
                z.write(item, Path("Focus-System") / item.relative_to(unpacked))
        # Die beiden Such-BATs liegen neben dem Programmordner und bleiben unabhängig.
        for bat_name in ("Windows-Suche-einrichten.bat", "Windows-Suche-entfernen.bat"):
            z.write(ROOT / bat_name, bat_name)

    print("\n" + "=" * 62)
    print("BUILD ERFOLGREICH")
    print(f"EXE: {exe}")
    print(f"ZIP: {zip_target}")
    print("=" * 62)
    print("Zum Ausführen später nur den gesamten Ordner 'Focus-System' entpacken.")
    print("Python, Node.js und npm werden auf dem Ziel-PC nicht benötigt.")
    input("\nZum Beenden Enter drücken ...")

if __name__ == "__main__":
    main()
