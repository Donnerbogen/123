﻿@echo off
setlocal
chcp 65001 >nul
cd /d "%~dp0"
title CORE Nexus Server
if not exist "installed.flag" (
  echo CORE Nexus Server wurde noch nicht installiert.
  echo Bitte zuerst install.bat ausfuehren.
  pause
  exit /b 1
)
where py >nul 2>&1
if %errorlevel%==0 (
  py -3 server.py
) else (
  python server.py
)
if errorlevel 1 (
  echo.
  echo CORE Nexus wurde mit einem Fehler beendet.
  pause
)
