#!/usr/bin/env bash
set -Eeuo pipefail
cd "$(dirname "$(readlink -f "$0")")"
PYTHON="${PYTHON:-python3}"
"$PYTHON" -c 'import tkinter' 2>/dev/null || { echo "Tkinter fehlt. Debian/Ubuntu: sudo apt install python3-tk python3-venv python3-pip."; exit 1; }
if [[ -z "${VIRTUAL_ENV:-}" ]]; then
  "$PYTHON" -m venv .venv || { echo "Virtuelle Umgebung fehlt. Debian/Ubuntu: sudo apt install python3-venv"; exit 1; }
  PIP=".venv/bin/python -m pip"
else PIP="$PYTHON -m pip"; fi
# shellcheck disable=SC2086
$PIP install --upgrade pip
# shellcheck disable=SC2086
$PIP install -r requirements-linux.txt
"${PYTHON}" -m py_compile adminserver.py
cp -n connection_config.example.json connection_config.json 2>/dev/null || true
chmod +x start-linux.sh
echo "Installation fertig. Starte mit ./start-linux.sh"
