const { app, BrowserWindow, ipcMain, Tray, Menu, nativeImage, Notification, screen } = require("electron");
const path = require("path");
const fs = require("fs");
const os = require("os");
const { execFile, spawn } = require("child_process");

const APP_DIR = app.isPackaged ? path.dirname(process.execPath) : path.resolve(__dirname, "..");
const CONFIG_PATH = path.join(APP_DIR, "config.json");
const LOG_PATH = path.join(APP_DIR, "focus.log");
let win = null, tray = null, lockWindow = null, enforcementTimer = null, schedulerTimer = null;
let session = null, lockSession = null, quitting = false;

const defaultConfig = () => ({
  password: null,
  categories: [],
  settings: { enforcementIntervalMs: 1200 },
  schedule: { categoryId: null, startAt: null, endAt: null, durationMinutes: null, completed: false, notified: [] }
});

function log(message) {
  const line = `[${new Date().toISOString()}] ${message}\n`;
  try { fs.appendFileSync(LOG_PATH, line, "utf8"); } catch {}
}
function readConfig() {
  try { return { ...defaultConfig(), ...JSON.parse(fs.readFileSync(CONFIG_PATH, "utf8")) }; }
  catch { return defaultConfig(); }
}
let config = readConfig();
function saveConfig() {
  try { fs.writeFileSync(CONFIG_PATH, JSON.stringify(config, null, 2), "utf8"); }
  catch (e) { log(`Konfiguration konnte nicht gespeichert werden: ${e.message}`); }
}
function notify(message) {
  if (Notification.isSupported()) new Notification({ title: "Focus System", body: message, silent: false }).show();
  if (win && !win.isDestroyed()) win.webContents.send("notice", message);
}
function broadcast() {
  if (win && !win.isDestroyed()) win.webContents.send("state:update", publicState());
}
function publicState() {
  return {
    needsSetup: !config.password,
    categories: config.categories,
    schedule: config.schedule,
    active: !!session,
    activeCategoryId: session?.categoryId || null,
    activeUntil: session?.until || null,
    lockActive: !!lockSession
  };
}
function ensureMainWindow() {
  if (win && !win.isDestroyed()) return win;
  win = new BrowserWindow({
    width: 1120, height: 780, minWidth: 850, minHeight: 620,
    backgroundColor: "#080d18", show: false,
    webPreferences: { preload: path.join(__dirname, "preload.js"), contextIsolation: true, nodeIntegration: false }
  });
  win.loadFile(path.join(__dirname, "index.html"));
  win.once("ready-to-show", () => win.show());
  win.on("close", (event) => {
    if (!quitting) { event.preventDefault(); win.hide(); }
  });
  win.on("closed", () => { win = null; });
  return win;
}
function createTray() {
  try {
    // Small valid transparent PNG; tray menu remains available without external assets.
    const png = Buffer.from("iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+jWQAAAABJRU5ErkJggg==", "base64");
    tray = new Tray(nativeImage.createFromBuffer(png));
    tray.setToolTip("Focus System");
    tray.setContextMenu(Menu.buildFromTemplate([
      { label: "Focus System öffnen", click: () => { ensureMainWindow().show(); ensureMainWindow().focus(); } },
      { label: "Focus-Modus beenden", click: stopFocus },
      { type: "separator" },
      { label: "Vollständig beenden", click: () => { if (lockSession) { notify("Bitte zuerst den Screen-Lock beenden."); return; } quitting = true; app.quit(); } }
    ]));
    tray.on("double-click", () => { ensureMainWindow().show(); ensureMainWindow().focus(); });
  } catch (e) { log(`Tray konnte nicht erstellt werden: ${e.message}`); }
}
function startEnforcement() {
  clearInterval(enforcementTimer);
  const interval = Math.max(500, Number(config.settings?.enforcementIntervalMs) || 1200);
  enforcementTimer = setInterval(() => {
    if (!session && !lockSession) return;
    enforceWindows();
  }, interval);
}
function powershell(scriptArgs) {
  const script = path.join(__dirname, "window-control.ps1");
  const unpacked = app.isPackaged ? path.join(process.resourcesPath, "app.asar.unpacked", "src", "window-control.ps1") : script;
  return new Promise((resolve) => {
    execFile("powershell.exe", ["-NoProfile", "-ExecutionPolicy", "Bypass", "-File", unpacked, ...scriptArgs], { windowsHide: true, timeout: 12000 }, (err, stdout) => resolve(err ? "" : String(stdout || "")));
  });
}
async function enforceWindows() {
  const allowed = new Set();
  if (session) {
    const category = config.categories.find(c => c.id === session.categoryId);
    for (const p of category?.programs || []) allowed.add(path.resolve(p).toLowerCase());
  }
  await powershell(["enforce", JSON.stringify([...allowed]), lockSession ? "lock" : "focus", String(process.pid)]);
}
function startFocus(categoryId, fromSchedule = false) {
  const category = config.categories.find(c => c.id === categoryId);
  if (!category) { notify("Die ausgewählte Kategorie existiert nicht."); return false; }
  if (session) stopFocus(false);
  let until = null;
  const now = Date.now();
  const schedule = config.schedule || {};
  if (fromSchedule || schedule.categoryId === categoryId) {
    const candidates = [];
    if (schedule.endAt) {
      const end = new Date(schedule.endAt).getTime();
      if (Number.isFinite(end)) candidates.push(end);
    }
    if (schedule.durationMinutes) candidates.push(now + Number(schedule.durationMinutes) * 60000);
    if (candidates.length) until = Math.min(...candidates);
  }
  session = { categoryId, startedAt: now, until };
  log(`Focus-Modus gestartet: ${category.name}`);
  notify(`Focus-Modus gestartet: ${category.name}`);
  broadcast();
  return true;
}
function stopFocus(markSchedule = true) {
  if (!session) return;
  log(`Focus-Modus beendet: ${config.categories.find(c => c.id === session.categoryId)?.name || "Kategorie"}`);
  session = null;
  if (markSchedule && config.schedule) { config.schedule.completed = true; saveConfig(); }
  notify("Focus-Modus wurde beendet.");
  broadcast();
}
function checkSchedule() {
  const s = config.schedule || {};
  if (!s.completed && s.startAt && !session) {
    const start = new Date(s.startAt).getTime();
    const remaining = start - Date.now();
    for (const mins of [5, 3, 2, 1]) {
      const threshold = mins * 60000;
      if (remaining > 0 && remaining <= threshold && remaining > threshold - 60000 && !(s.notified || []).includes(mins)) {
        s.notified = [...(s.notified || []), mins]; saveConfig();
        notify(`Dein Focus-Modus startet in ${mins} Minute${mins === 1 ? "" : "n"}.`);
      }
    }
    if (Number.isFinite(start) && remaining <= 0) {
      s.completed = true; saveConfig();
      if (!startFocus(s.categoryId, true)) notify("Der geplante Focus-Modus konnte nicht gestartet werden.");
    }
  }
  if (session?.until && Date.now() >= session.until) stopFocus();
}
function openLockWindow() {
  if (lockWindow && !lockWindow.isDestroyed()) return;
  const { width, height } = screen.getPrimaryDisplay().bounds;
  lockWindow = new BrowserWindow({
    x: 0, y: 0, width, height, fullscreen: true, kiosk: true, alwaysOnTop: true,
    frame: false, closable: false, minimizable: false, movable: false,
    backgroundColor: "#070b14",
    webPreferences: { preload: path.join(__dirname, "preload.js"), contextIsolation: true, nodeIntegration: false }
  });
  lockWindow.loadFile(path.join(__dirname, "index.html"), { query: { lock: "1" } });
  lockWindow.on("close", e => { if (lockSession) e.preventDefault(); });
}
function endLock() {
  if (!lockSession) return;
  lockSession.password = null;
  lockSession = null;
  if (lockWindow && !lockWindow.isDestroyed()) { lockWindow.destroy(); lockWindow = null; }
  log("Screen-Lock beendet.");
  notify("Screen-Lock wurde beendet.");
  broadcast();
}
app.whenReady().then(() => {
  ensureMainWindow(); createTray(); startEnforcement();
  schedulerTimer = setInterval(checkSchedule, 500);
  app.on("activate", () => ensureMainWindow().show());
});
app.on("before-quit", (event) => { if (lockSession && !quitting) event.preventDefault(); });
app.on("window-all-closed", () => {});

ipcMain.handle("state:get", () => publicState());
ipcMain.handle("password:setup", (_e, password) => {
  if (config.password) return { ok: false, message: "Ein Hauptpasswort ist bereits eingerichtet." };
  if (typeof password !== "string" || password.length < 1) return { ok: false, message: "Bitte ein Passwort eingeben." };
  config.password = password; saveConfig(); log("Hauptpasswort erstmalig eingerichtet."); return { ok: true };
});
ipcMain.handle("password:login", (_e, password) => ({ ok: password === config.password }));
ipcMain.handle("password:change", (_e, oldPassword, newPassword) => {
  if (oldPassword !== config.password) return { ok: false, message: "Das bisherige Passwort ist falsch." };
  if (typeof newPassword !== "string" || !newPassword.length) return { ok: false, message: "Neues Passwort fehlt." };
  config.password = newPassword; saveConfig(); log("Hauptpasswort geändert."); return { ok: true };
});
ipcMain.handle("categories:save", (_e, categories) => {
  if (!Array.isArray(categories)) return { ok: false };
  config.categories = categories.map(c => ({ id: String(c.id), name: String(c.name || "Neue Kategorie"), programs: Array.isArray(c.programs) ? c.programs.map(String) : [] }));
  saveConfig(); broadcast(); return { ok: true };
});
ipcMain.handle("focus:start", (_e, id) => ({ ok: startFocus(String(id)) }));
ipcMain.handle("focus:stop", () => { stopFocus(); return { ok: true }; });
ipcMain.handle("schedule:save", (_e, schedule) => {
  const startAt = schedule.startAt || null, endAt = schedule.endAt || null;
  if (startAt && endAt && new Date(endAt) <= new Date(startAt)) return { ok: false, message: "Die Endzeit muss nach der Startzeit liegen." };
  config.schedule = {
    categoryId: schedule.categoryId || null, startAt, endAt,
    durationMinutes: schedule.durationMinutes ? Math.max(1, Number(schedule.durationMinutes)) : null,
    completed: false, notified: []
  };
  saveConfig(); notify("Zeitplanung gespeichert."); broadcast(); return { ok: true };
});
ipcMain.handle("apps:running", async () => {
  const raw = await powershell(["list"]);
  try { return JSON.parse(raw || "[]"); } catch { return []; }
});
ipcMain.handle("program:add", (_e, categoryId, exePath) => {
  const c = config.categories.find(x => x.id === categoryId);
  if (!c || !exePath) return { ok: false };
  if (!c.programs.includes(exePath)) c.programs.push(exePath);
  saveConfig(); broadcast(); return { ok: true };
});
ipcMain.handle("program:remove", (_e, categoryId, exePath) => {
  const c = config.categories.find(x => x.id === categoryId);
  if (!c) return { ok: false };
  c.programs = c.programs.filter(x => x !== exePath); saveConfig(); broadcast(); return { ok: true };
});
ipcMain.handle("lock:start", (_e, password, minutes) => {
  if (!password) return { ok: false, message: "Bitte ein Sitzungs-Passwort festlegen." };
  const duration = Number(minutes) > 0 ? Number(minutes) * 60000 : null;
  lockSession = { password: String(password), until: duration ? Date.now() + duration : null };
  log("Screen-Lock gestartet."); openLockWindow(); broadcast(); return { ok: true };
});
ipcMain.handle("lock:unlock", (_e, password) => {
  if (!lockSession || password !== lockSession.password) return { ok: false, message: "Falsches Passwort." };
  endLock(); return { ok: true };
});
ipcMain.handle("lock:end", () => { endLock(); return { ok: true }; });
setInterval(() => { if (lockSession?.until && Date.now() >= lockSession.until) endLock(); }, 500);
ipcMain.on("window:minimize", () => win?.minimize());
ipcMain.on("window:hide", () => win?.hide());
