CORE NEXUS – EXE-BUILDPAKET

WICHTIGER TECHNISCHER HINWEIS
Diese Build-Variante verpackt die vorhandenen Python/Tkinter-Programme mit PyInstaller als eigenständige Windows-Programme. Auf Ziel-PCs muss dadurch kein Python installiert sein. Die vorhandene Oberfläche bleibt Tkinter; dies ist KEINE Electron-Neuentwicklung. Eine echte Electron-Oberfläche erfordert eine vollständige Portierung der drei Anwendungen und ist in den gelieferten Quellen noch nicht enthalten.

BUILD
1. Auf einem Windows-Build-PC Python 3.11/3.12 installieren.
2. Für jedes Programm den jeweiligen Ordner öffnen.
3. build.py ausführen (Doppelklick oder: py build.py).
4. Der fertige portable Programmordner liegt in release/CORE-Nexus-.../.
5. Den gesamten Ordner kopieren, nicht nur die EXE.

DATEN
Alle dauerhaften Daten liegen neben der EXE in data/. Bei Updates den Ordner data/ behalten. Bestehende Konfigurationsdateien im Programmordner werden beim Build in data/ übernommen, wenn sie lokal vorhanden sind. In diesem Quellpaket sind keine echten Token-Konfigurationsdateien enthalten. Lege deine vorhandenen relay_config.json / admin_config.json / connection_config.json lokal in den jeweiligen Quellordner, bevor du build.py ausführst; vorhandene Tokenwerte werden unverändert kopiert. Teile diese Dateien nicht öffentlich.

SERVER
Der Server verwendet Ports 47621 (Agent/Client), 47622 (Discovery) und 47623 (Adminserver). Windows-Firewallregeln müssen passend gesetzt werden.

AGENT
Bildschirmaufnahme, Maus/Tastatur, Zwischenablage und Tray benötigen die nativen Abhängigkeiten aus requirements.txt. Windows-Sicherheitssoftware kann die EXE wegen pynput/Screen-Capture-Funktionen prüfen oder blockieren. Nur auf eigenen bzw. ausdrücklich autorisierten Geräten einsetzen. Lokale Zustimmung und Serverfreigabe bleiben erforderlich.

ADMINSERVER
Der Adminserver erhält im fertigen Ordner zusätzlich Server/ als Quellvorlage, damit seine bisherige Funktion zum Erstellen von Server-Quellpaketen weiterhin Dateien findet. Die erzeugten Pakete sind weiterhin Quellpakete und nicht automatisch fertig kompilierte Server-EXEs.

RELAY
Der Relay-Ordner wurde nicht in dieses Buildpaket übernommen und wird nicht geändert.
