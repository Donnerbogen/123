CORE Nexus Server - HTML Desktop Design Paket
========================================

START / BUILD
-------------
Die Build-Datei ist auf launcher.py umgestellt. Nach dem Build startet die EXE die HTML/CSS-Oberfläche in pywebview.

Auf dem Build-PC:
  py build.py

Voraussetzung: Windows-PC für den Windows-EXE-Build empfohlen; Python 3.11/3.12 und pip.

ENTHALTEN
----------
- launcher.py: startet das HTML-Fenster via pywebview
- ui/index.html: Server-UI
- CORE-UI/styles.css und app.js: gemeinsame Gestaltung und UI-Interaktionen
- legacy_server.py: bisherige Tkinter-Anwendung (als Fallback separat aus dem UI startbar)
- build.py / requirements.txt / Konfigurationsbeispiele und Hilfsdateien

STATUS / LIMITATIONEN
---------------------
Die HTML-Oberfläche wird als Hauptfenster gestartet. Die Backend-Netzwerk- und Gerätefunktionen sind NICHT vollständig in die HTML-UI integriert. Der Button "Legacy-Funktionen öffnen" öffnet die bisherige Tkinter-Anwendung mit den vorhandenen Funktionen. WebView2 Runtime kann auf Windows erforderlich sein.
Relay-Dateien werden nicht geändert oder mitgeliefert.

