﻿@echo off
setlocal EnableExtensions
cd /d "%~dp0"
:menu
cls
echo ========================================
echo CORE Nexus Adminserver - Verwaltung
echo ========================================
echo 1. Abhaengigkeiten installieren
 echo 2. Autostart aktivieren
 echo 3. Autostart deaktivieren
 echo 4. Adminserver deinstallieren (Autostart entfernen)
 echo 5. Abbrechen
 echo.
set /p choice=Auswahl: 
if "%choice%"=="1" goto install
if "%choice%"=="2" goto enable
if "%choice%"=="3" goto disable
if "%choice%"=="4" goto uninstall
if "%choice%"=="5" exit /b 0
goto menu
:install
rem Use Python 3.15 only. Do not fall back to another Python version.
set "PY="
where py >nul 2>&1
if not errorlevel 1 (
  py -V:3.15 -c "import sys; print(sys.version); raise SystemExit(0 if sys.version_info[:2] == (3,15) else 1)" >nul 2>&1
  if not errorlevel 1 set "PY=py -V:3.15"
)
if not defined PY (
  where python >nul 2>&1
  if not errorlevel 1 (
    python -c "import sys; print(sys.version); raise SystemExit(0 if sys.version_info[:2] == (3,15) else 1)" >nul 2>&1
    if not errorlevel 1 set "PY=python"
  )
)
if not defined PY (
  echo FEHLER: Python 3.15 wurde nicht gefunden.
  echo Windows Server 2019: Python Install Manager per MSI installieren, danach "py install 3.15" ausfuehren. Python 3.15 x64 mit Tcl/Tk und pip benoetigt.
  echo Andere Python-Versionen werden absichtlich nicht verwendet.
  pause
  exit /b 1
)
%PY% --version
if errorlevel 1 (
  echo FEHLER: Python 3.15 konnte nicht gestartet werden.
  pause
  exit /b 1
)
%PY% -c "import tkinter; print('Tkinter OK')" >nul 2>&1
if errorlevel 1 (echo FEHLER: Tkinter fehlt. Python 3.15 mit Tcl/Tk installieren.& pause & goto menu)
%PY% -m pip install --upgrade --disable-pip-version-check pip
if errorlevel 1 (echo FEHLER: pip konnte nicht aktualisiert werden.& pause & goto menu)
%PY% -m pip install --upgrade --disable-pip-version-check -r requirements.txt
if errorlevel 1 (
  echo FEHLER: Abhaengigkeiten konnten nicht installiert werden.
  echo Pruefe Python, Tkinter und die Internetverbindung.
  pause
  goto menu
)
if not exist connection_config.json copy connection_config.example.json connection_config.json >nul
echo Verbindungseinstellungen: connection_config.json
echo Server werden nach Einrichtung der Tokens automatisch gefunden.
echo Erforderlich ist ausschliesslich Python 3.15.
pause
goto menu
:enable
powershell -NoProfile -ExecutionPolicy Bypass -Command "$s=(New-Object -ComObject WScript.Shell).CreateShortcut((Join-Path ([Environment]::GetFolderPath('Startup')) 'CORE Nexus Adminserver.lnk')); $s.TargetPath='%~dp0start.bat'; $s.WorkingDirectory='%~dp0'; $s.Save()"
echo Autostart eingerichtet.
pause
goto menu
:disable
powershell -NoProfile -ExecutionPolicy Bypass -Command "Remove-Item (Join-Path ([Environment]::GetFolderPath('Startup')) 'CORE Nexus Adminserver.lnk') -Force -ErrorAction SilentlyContinue"
echo Autostart entfernt.
pause
goto menu
:uninstall
powershell -NoProfile -ExecutionPolicy Bypass -Command "Remove-Item (Join-Path ([Environment]::GetFolderPath('Startup')) 'CORE Nexus Adminserver.lnk') -Force -ErrorAction SilentlyContinue"
echo Der Adminserver-Autostart wurde entfernt. Projektdateien und Einstellungen bleiben erhalten.
pause
goto menu
