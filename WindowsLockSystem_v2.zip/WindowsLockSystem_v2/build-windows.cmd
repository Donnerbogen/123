@echo off
setlocal
title Windows Lock System 2.0 - Build
where py >nul 2>nul
if %ERRORLEVEL% EQU 0 (set "PYTHON=py") else (
  where python >nul 2>nul
  if %ERRORLEVEL% EQU 0 (set "PYTHON=python") else (
    echo Python wurde nicht gefunden.
    echo Installiere Python und aktiviere "Add python.exe to PATH".
    pause
    exit /b 1
  )
)
%PYTHON% -m pip install --upgrade pyinstaller
if %ERRORLEVEL% NEQ 0 (pause & exit /b 1)
%PYTHON% -m PyInstaller --noconfirm --clean --onefile --windowed --name WindowsLockSystem main.py
if %ERRORLEVEL% NEQ 0 (pause & exit /b 1)
copy /Y config.json dist\config.json >nul
echo.
echo Fertig: dist\WindowsLockSystem.exe
echo config.json wurde ebenfalls nach dist kopiert.
pause