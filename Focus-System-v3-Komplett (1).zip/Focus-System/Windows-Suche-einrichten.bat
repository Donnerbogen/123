@echo off
setlocal
set "APP_EXE=%~dp0Focus System.exe"
set "LINK_DIR=%APPDATA%\Microsoft\Windows\Start Menu\Programs"
set "LINK_FILE=%LINK_DIR%\Focus System.lnk"
if not exist "%APP_EXE%" (echo Focus System.exe nicht gefunden. Diese BAT muss neben der EXE liegen.&pause&exit /b 1)
if not exist "%LINK_DIR%" mkdir "%LINK_DIR%" >nul 2>&1
powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='Stop';$s=New-Object -ComObject WScript.Shell;$l=$s.CreateShortcut($env:LINK_FILE);$l.TargetPath=$env:APP_EXE;$l.WorkingDirectory=(Split-Path -Parent $env:APP_EXE);$l.Description='Focus System starten';$l.IconLocation=$env:APP_EXE;$l.Save()"
if errorlevel 1 (echo Fehler beim Erstellen der Verknuepfung.&pause&exit /b 1)
echo Focus System ist ueber die Windows-Suche auffindbar. Es wurden keine Programmdateien kopiert.
pause
endlocal
