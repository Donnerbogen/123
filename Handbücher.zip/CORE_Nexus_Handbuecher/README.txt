CORE NEXUS – HANDBUCH-PAKET
Stand: 15.10.2026

Enthaltene Handbücher:
00_Gesamthandbuch.pdf / .docx
    Vollständige Gesamtdokumentation.
01_Installation_und_Render.pdf / .docx
    Installation, GitHub, Render und Konfiguration.
02_Server_und_Administration.pdf / .docx
    Server-Dashboard, Konten, Berechtigungen, Geräte, Fernsteuerung und Backups.
03_Agent_und_Zielgeraet.pdf / .docx
    Agent-Installation, lokale Zustimmung, Verbindungsstatus und Ziel-PC.
04_Fehlersuche_und_Sicherheit.pdf / .docx
    Netzwerkdiagnose, typische Fehler, Latenz, Sicherheit und Datenschutz.

Die PDF-Dateien eignen sich zum Lesen und Drucken. Die DOCX-Dateien sind editierbare Word-Dokumente.

WICHTIGE HINWEISE
- Diese Dokumentation wurde anhand von CORE_Nexus_Logout_Locks_Dashboard.zip erstellt.
- Die lokale relay_config.json dieser Paketversion enthält einen Token-Platzhalter. Vor Nutzung des Relays muss er durch den tatsächlichen Wert aus Render ersetzt werden.
- GitHub darf keine echten Relay- oder Dashboard-Tokens enthalten.
- Render-Kennzahlen erfassen nur Verbindungen, die tatsächlich über Render laufen; LAN-Verbindungen erscheinen dort nicht.
- Ein Syntax-/Dokumentationscheck ersetzt keinen Live-Test mit mehreren Windows-Geräten und dem tatsächlichen Render-Dienst.
