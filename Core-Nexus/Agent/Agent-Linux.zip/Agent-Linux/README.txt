CORE Nexus Agent

1. setup.bat: Menue fuer Installation/Reparatur, Deinstallation und Autostart.
2. start.bat: Startet die bereits installierte Anwendung sofort.

setup.bat fragt vor jeder Aktion nach deiner Auswahl. Bei der Deinstallation kannst du lokale Daten behalten oder loeschen.

3. Agent-Anmeldung und Gerätefernsteuerung
   - Im Agent-Fenster auf „Am Server anmelden“ klicken.
   - Nur Konten verwenden, die zuvor im Server-Menü „Konten & Rechte“ erstellt wurden.
   - Der Server prüft Kontoaktivität und Berechtigungen. Für die Geräteübersicht ist „Geräte anzeigen“ erforderlich; für Fernsteuerung sind „Bildschirm ansehen“ und „Maus und Tastatur steuern“ erforderlich.
   - Es werden nur serverseitig freigegebene Geräte mit gespeicherter lokaler Zustimmung zur Fernsteuerung angeboten.
   - Im LAN verbindet sich die Anmeldung direkt über TCP 47623. Wenn kein LAN-Server gefunden wird, nutzt sie das konfigurierte Render-Relay; dafür muss die aktualisierte Relay-Version mit Rolle „controller“ auf Render bereitgestellt sein.
   - Die Anmeldung verwendet Challenge-Response. Das Passwort wird nicht im Klartext an den Server gesendet.
   - Der Server hat Vorrang: Wenn eine Fernsteuerung im Server-Dashboard geöffnet wird oder der Server die Sitzung beendet, wird die vom Agenten gestartete Sitzung sofort beendet.


Neue Erweiterungen (Oktober 2026)
Details, Grenzen und Installation stehen in ERWEITERUNGEN_2026-10.txt im Paketstamm. Vor dem Update Server/data sichern. Dateiübertragung ist controller->Zielgerät (max. 2 MiB), Zwischenablage nur nach Bestätigung und Monitorwechsel schaltet die Bildschirmaufnahme um. Der Notfallmodus beendet aktive Sitzungen, nicht den Agenten.


LIZENZPFLICHT
Beim Start ist eine gültige, signierte Jahreslizenz erforderlich. Server und Agent verwenden getrennte Produktschlüssel. Das Lizenzfenster ermöglicht Aktivierung und Verlängerung. Der Schlüssel wird lokal unter data/license.json gespeichert. Die Signatur wird offline geprüft; der private Signaturschlüssel bleibt ausschließlich auf Render.
Lizenzportal: CORE_NEXUS_LICENSE_URL (Standard: https://core-nexus-license-website.onrender.com).
Erinnerungen: 30 Tage, 14 Tage, 7 Tage vor Ablauf und anschließend täglich. Läuft die Lizenz während des Betriebs ab, wird das Programm beendet.


HINWEIS LIZENZ: Die Standardadresse ist aus render.yaml abgeleitet. Wenn dein Render-Service einen anderen Namen bzw. eine andere onrender.com-Adresse hat, setze CORE_NEXUS_LICENSE_URL und CORE_NEXUS_LICENSE_API_URL entsprechend. CORE_NEXUS_LICENSE_PUBLIC_KEY muss exakt dem Feld public_key von /api/license/public-key entsprechen.


Render-Lizenzschalter:
Der Betreiber steuert die Lizenzpflicht über LICENSE_ENABLED am Lizenz-Webservice. true = Prüfung aktiv, false = Clients überspringen die Prüfung. Clients prüfen den Status ungefähr jede Minute; nach Reaktivierung wird eine gültige Lizenz verlangt.
