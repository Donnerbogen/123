@echo off
setlocal EnableExtensions
cd /d "%~dp0"
if not exist "%~dp0start.bat" (
  echo FEHLER: start.bat wurde nicht gefunden.
  pause
  exit /b 1
)
call "%~dp0start.bat"
