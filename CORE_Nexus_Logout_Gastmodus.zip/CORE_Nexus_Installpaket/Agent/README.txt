﻿CORE NEXUS AGENT – UPDATE
=========================

1. Diesen kompletten Agent-Ordner auf den Client-PC kopieren.
2. install.bat ausführen, falls Python-Abhängigkeiten fehlen.
3. start.bat starten. Der Agent sucht den Server automatisch im lokalen Netzwerk.
4. Lokale Zustimmung erteilen. Danach muss das Gerät zusätzlich im Server-Dashboard freigegeben werden.

Die Geräte-ID bleibt in device_id.json, die lokale Zustimmung in consent.json. Diese Dateien nicht löschen, außer du willst bewusst eine neue Geräteidentität bzw. erneute Zustimmung erzwingen.

Statusmeldungen unterscheiden jetzt klar: lokale Zustimmung fehlt, Serverfreigabe fehlt/wurde widerrufen, oder Gerät ist vollständig freigegeben. Der Agent bleibt bei fehlender Serverfreigabe geöffnet, aber Fernzugriff bleibt gesperrt.

Nur im vertrauenswürdigen privaten LAN nutzen; keine Router-Portweiterleitung.
