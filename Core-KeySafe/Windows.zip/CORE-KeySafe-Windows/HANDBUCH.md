# CORE KeySafe – Handbuch

Dieses Handbuch ist auch direkt in der Anwendung über die Schaltfläche **Handbuch** erreichbar.

## 1. Start und Lizenz
Starte CORE KeySafe und gib bei Aufforderung den gültigen Lizenzschlüssel ein. Die Lizenzprüfung benötigt normalerweise eine Internetverbindung. Ohne gültige Lizenz bleibt der Tresorbereich gesperrt.

## 2. Tresor erstellen oder öffnen
Wähle **Tresor öffnen / erstellen**. Beim ersten Start legst du ein Master-Passwort mit mindestens 12 Zeichen fest und bestätigst es. Bei späteren Starts öffnest du den Tresor mit diesem Passwort. Vergiss es nicht: Es gibt in dieser Version keine Funktion zum Zurücksetzen.

## 3. Einträge verwalten
**＋ Eintrag** erstellt einen Eintrag. Doppelklicke eine Tabellenzeile, um sie zu bearbeiten. Du kannst Titel, Benutzername, Passwort, Webseite, Kategorie, Notizen und Tags speichern. Über die Suche findest du Einträge. Mit **Speichern** wird der Tresor verschlüsselt und lokal gespeichert.

## 4. Passwörter generieren
Wähle **Passwort generieren** und eine Länge zwischen 12 und 128 Zeichen. Übertrage das Ergebnis sicher in den gewünschten Eintrag und teile es nicht.

## 5. Sperren
**Sperren** schließt den geöffneten Tresor in der Oberfläche. Nach einer konfigurierten Zeit ohne Aktivität erfolgt die Sperre automatisch. Zum Weiterarbeiten öffnest du den Tresor erneut.

## 6. Import
Öffne **Importordner öffnen** und lege eine vertrauenswürdige `.vault`-Datei in den Importordner. Folge der Abfrage in der App und gib das Master-Passwort der importierten Datei ein. Sichere wichtige Dateien vor einem Tresorwechsel separat.

## 7. Daten und Backups
Die Daten liegen im Benutzerprofil unter `Core Network/CORE KeySafe`. `vault/` enthält die verschlüsselte Tresordatei, `Import/` ist der Importordner und `state/` enthält Lizenz-/Statusinformationen. Sichere die verschlüsselte Tresordatei; bewahre das Master-Passwort getrennt auf.

## 8. Sicherheit
Gib Master-Passwort und Lizenzschlüssel nicht weiter. Schütze dein Betriebssystem und installiere Updates. Eine verschlüsselte Datei schützt nicht vor Schadsoftware auf einem bereits entsperrten Computer. Wenn du das Master-Passwort vergisst, kann der Tresor unzugänglich bleiben.

## 9. Häufige Probleme
- **Lizenzfehler:** Eingabe und Internetverbindung prüfen.
- **Tresor öffnet nicht:** Master-Passwort prüfen; Datei könnte beschädigt sein.
- **Import nicht sichtbar:** prüfen, ob eine `.vault`-Datei im Importordner liegt.
- **App startet nicht:** vollständige Fehlermeldung notieren. Niemals Master-Passwort oder echte Tresoreinträge an den Support senden.
