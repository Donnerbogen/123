"""CORE Nexus Cloud agent. Run with Python 3.15.0 exactly: python agent.py
Requires explicit local user consent and server-side device approval.
"""
from __future__ import annotations
import sys

_REQUIRED_PYTHON = (3, 15, 0)
if sys.version_info[:3] != _REQUIRED_PYTHON:
    _actual = ".".join(map(str, sys.version_info[:3]))
    print(f"FEHLER: CORE Nexus Agent benoetigt exakt Python 3.15.0. Erkannt: Python {_actual}.", file=sys.stderr)
    raise SystemExit(1)

import json, os, platform, queue, socket, threading, time, uuid, io, hashlib, hmac
import tkinter as tk
from tkinter import ttk, messagebox
import base64
try:
    import mss
    from PIL import Image
    from pynput.mouse import Controller as MouseController, Button
    from pynput.keyboard import Controller as KeyboardController, Key
    REMOTE_LIBS = True
except Exception:
    REMOTE_LIBS = False

APP='CORE Nexus Agent'; DISCOVERY_PORT=47622; DEFAULT_PORT=47621
BASE=os.path.dirname(os.path.abspath(__file__)); ID_FILE=os.path.join(BASE,'device_id.json')
HEARTBEAT=5; OFFLINE_TIMEOUT=18
REMOTE_HEARTBEAT_INTERVAL=0.065
REMOTE_FRAME_INTERVAL=0.16
REMOTE_FRAME_MAX_SIZE=(1152, 648)
REMOTE_JPEG_QUALITY=36

def get_device_id():
    try:
        with open(ID_FILE,'r',encoding='utf-8') as f: return json.load(f)['device_id']
    except Exception:
        did=str(uuid.uuid4())
        try:
            with open(ID_FILE,'w',encoding='utf-8') as f: json.dump({'device_id':did},f)
        except OSError: pass
        return did

def discover_server(timeout=3):
    sock=socket.socket(socket.AF_INET,socket.SOCK_DGRAM); sock.setsockopt(socket.SOL_SOCKET,socket.SO_BROADCAST,1); sock.settimeout(timeout)
    try:
        sock.sendto(b'CORE_NEXUS_DISCOVER_V1',('<broadcast>',DISCOVERY_PORT))
        end=time.time()+timeout
        while time.time()<end:
            try: data,addr=sock.recvfrom(4096)
            except socket.timeout: break
            try:
                item=json.loads(data.decode('utf-8'))
                if item.get('app')=='CORE Nexus' and item.get('port'): return item['host'],int(item['port'])
            except Exception: continue
    finally: sock.close()
    return None

def send_json(sock,obj):
    sock.sendall((json.dumps(obj,separators=(',',':'))+'\n').encode('utf-8'))

def recv_json(file):
    line=file.readline()
    if not line: raise ConnectionError('Server hat die Verbindung beendet.')
    if len(line)>8_000_000: raise ValueError('Antwort des Servers ist zu groß.')
    return json.loads(line.decode('utf-8'))

class RelayAgentSocket:
    """Adapts a WSS relay connection to the existing newline-JSON socket interface."""
    def __init__(self, ws, device_id): self.ws=ws; self.device_id=device_id; self.closed=False
    def settimeout(self, value): self.ws.settimeout(value)
    def makefile(self, mode): return self
    def sendall(self, data):
        obj=json.loads(data.decode('utf-8').strip())
        self.ws.send(json.dumps({'device_id':self.device_id,'payload':obj},separators=(',',':')))
    def readline(self):
        while not self.closed:
            raw=self.ws.recv()
            if not raw: return b''
            envelope=json.loads(raw)
            outer=envelope.get('payload') if envelope.get('type')=='message' else envelope
            if not isinstance(outer,dict): continue
            if outer.get('device_id') != self.device_id: continue
            payload=outer.get('payload')
            if isinstance(payload,dict): return (json.dumps(payload,separators=(',',':'))+'\n').encode('utf-8')
        return b''
    def close(self):
        self.closed=True
        try: self.ws.close()
        except Exception: pass

class Agent:
    def __init__(self):
        self.device_id=get_device_id(); self.sock=None; self.file=None; self.running=True; self.connected=False; self.connecting=False; self.uiq=queue.Queue(); self.remote_active=False; self.remote_mouse=MouseController() if REMOTE_LIBS else None; self.remote_keyboard=KeyboardController() if REMOTE_LIBS else None; self.remote_last_frame=None; self._mss_capture=None; self.frame_native_size=None; self.frame_encoded_size=None; self._last_frame_time=0.0; self.input_count=0; self.monitor_index=1; self.file_transfers={}; self.last_approved=None; self.last_server_approved=None; self.connection_mode='Noch nicht verbunden'; self.root=tk.Tk(); self.root.title(APP); self.root.geometry('650x470'); self.root.minsize(600,440); self.root.configure(bg='#060b16'); self.root.resizable(True,True)
        style=ttk.Style(); style.theme_use('clam'); style.configure('.',background='#0b1628',foreground='#eef6ff',fieldbackground='#101f34',font=('Segoe UI',10)); style.configure('TFrame',background='#0b1628'); style.configure('TLabel',background='#0b1628',foreground='#eef6ff',font=('Segoe UI',10)); style.configure('Title.TLabel',font=('Segoe UI',23,'bold'),foreground='#55d9ff'); style.configure('Sub.TLabel',foreground='#91a7c4',font=('Segoe UI',9)); style.configure('Hero.TLabel',font=('Segoe UI',12,'bold'),foreground='#d9efff'); style.configure('Card.TFrame',background='#0d1b2e',relief='solid',borderwidth=1); style.configure('TButton',background='#153657',foreground='white',padding=(13,9),borderwidth=1); style.map('TButton',background=[('active','#1e5b89'),('pressed','#16436a')]); style.configure('TEntry',padding=7,fieldbackground='#071322',foreground='#eef6ff')
        outer=ttk.Frame(self.root,padding=22); outer.pack(fill='both',expand=True)
        top=ttk.Frame(outer); top.pack(fill='x',pady=(0,18)); brand=ttk.Frame(top); brand.pack(side='left',fill='x',expand=True); ttk.Label(brand,text='CORE NEXUS',style='Title.TLabel').pack(anchor='w'); ttk.Label(brand,text='SECURE ENDPOINT  /  CROSS-PLATFORM AGENT',style='Sub.TLabel').pack(anchor='w',pady=(1,0))
        self.badge=ttk.Label(top,text='●  INITIALIZING',foreground='#ffca70',font=('Segoe UI',9,'bold')); self.badge.pack(side='right',anchor='center',padx=(8,0))
        card=ttk.Frame(outer,padding=18,style='Card.TFrame'); card.pack(fill='x',pady=(0,12)); ttk.Label(card,text='VERBINDUNGSSTATUS',style='Sub.TLabel').pack(anchor='w'); self.status=ttk.Label(card,text='Suche den CORE Nexus Server …',wraplength=540,style='Hero.TLabel'); self.status.pack(anchor='w',pady=(7,13)); ttk.Separator(card).pack(fill='x',pady=(0,10)); row=ttk.Frame(card); row.pack(fill='x'); ttk.Label(row,text='VERBINDUNGSWEG',style='Sub.TLabel').pack(side='left'); self.transport=ttk.Label(row,text='CORE Nexus Cloud',foreground='#55d9ff',font=('Segoe UI',9,'bold')); self.transport.pack(side='right')
        lower=ttk.Frame(outer); lower.pack(fill='both',expand=True); left=ttk.Frame(lower,padding=15,style='Card.TFrame'); left.pack(side='left',fill='both',expand=True,padx=(0,10)); ttk.Label(left,text='GERÄTEINFORMATION',style='Sub.TLabel').pack(anchor='w'); ttk.Label(left,text=f'Geräte-ID  {self.device_id[:18]}…',style='Hero.TLabel').pack(anchor='w',pady=(8,5)); ttk.Label(left,text=('Fernsteuerungsbibliotheken bereit' if REMOTE_LIBS else 'Fernsteuerungs-Abhängigkeiten fehlen'),foreground=('#47e0a0' if REMOTE_LIBS else '#ff7285'),wraplength=300).pack(anchor='w'); ttk.Label(left,text='Lokale Zustimmung und Serverfreigabe sind erforderlich.',style='Sub.TLabel',wraplength=300).pack(anchor='w',pady=(9,0))
        right=ttk.Frame(lower,padding=15,style='Card.TFrame'); right.pack(side='right',fill='y'); ttk.Label(right,text='AKTIONEN',style='Sub.TLabel').pack(anchor='w',pady=(0,9)); self.retry=ttk.Button(right,text='⟳  Erneut verbinden',command=self.start_connect); self.retry.pack(fill='x'); self.login_button=ttk.Button(right,text='🌐  Cloud-Dashboard öffnen',command=self.open_account_login); self.login_button.pack(fill='x',pady=(8,0)); ttk.Label(right,text='Status aktualisiert automatisch.\n\nAlle Geräte verbinden sich direkt mit dem CORE Nexus Cloud-Server.',style='Sub.TLabel',wraplength=190).pack(anchor='w',pady=(13,0))
        self.root.protocol('WM_DELETE_WINDOW',self.close); self.root.after(200,self.poll); self.root.after(60000,self.auto_reconnect_check); self.start_connect()

    def open_account_login(self):
        """Open the hosted dashboard; account management is performed in the website."""
        try:
            import webbrowser
            cfg_path=os.path.join(BASE,'relay_config.json')
            with open(cfg_path,'r',encoding='utf-8') as handle: cfg=json.load(handle)
            url=str(cfg.get('relay_url','')).strip()
            if url.startswith('wss://'):
                webbrowser.open('https://' + url[6:].split('/ws')[0])
            else:
                messagebox.showerror(APP,'Die Cloud-URL in relay_config.json ist ungültig.',parent=self.root)
        except Exception as exc:
            messagebox.showerror(APP,f'Cloud-Dashboard konnte nicht geöffnet werden: {exc}',parent=self.root)

    def set_status(self,text): self.uiq.put(('status',text))
    def start_connect(self, automatic=False):
        if not self.running or self.connected or self.connecting:
            return
        self.connecting=True
        self.retry.configure(state='disabled')
        if automatic:
            self.status.configure(text='Verbinde direkt mit dem CORE Nexus Cloud-Server …')
        else:
            self.status.configure(text='Verbinde direkt mit dem CORE Nexus Cloud-Server …')
        threading.Thread(target=self.connect_worker,daemon=True).start()

    def auto_reconnect_check(self):
        # If disconnected, perform a fresh LAN discovery and then try the configured relay.
        # The timer runs independently of connection attempts, but the guards prevent overlap.
        if self.running and not self.connected and not self.connecting:
            self.start_connect(automatic=True)
        if self.running:
            self.root.after(60000,self.auto_reconnect_check)

    def connect_worker(self):
        """Connect directly to the hosted CORE Nexus Cloud service; no local server is required."""
        sock = None
        file = None
        host = None
        try:
            # Cloud-only mode: intentionally do not discover or connect to a local server.
            if sock is None:
                cfg_path = os.path.join(BASE, 'relay_config.json')
                cfg = {}
                try:
                    with open(cfg_path, 'r', encoding='utf-8') as handle:
                        cfg = json.load(handle)
                except Exception:
                    cfg = {}
                if not cfg.get('enabled'):
                    raise ConnectionError('CORE Nexus Cloud-Verbindung ist deaktiviert. Prüfe relay_config.json.')
                import websocket
                relay_url = str(cfg.get('relay_url', '')).strip()
                room = str(cfg.get('room_id', '')).strip()
                token = (os.environ.get(cfg.get('relay_token_env', 'CORE_NEXUS_RELAY_TOKEN')) or cfg.get('relay_token') or '').strip()
                if not relay_url.startswith('wss://') or not room or not token or 'PASTE_' in token:
                    raise ConnectionError('Cloud-Konfiguration unvollständig: relay_url, room_id und relay_token prüfen.')
                ws = websocket.create_connection(relay_url, timeout=15, origin=relay_url.split('/ws')[0])
                ws.send(json.dumps({'type':'auth','token':token,'room_id':room,'client_id':self.device_id,'role':'agent'}))
                auth=json.loads(ws.recv())
                if auth.get('type')!='auth_ok':
                    ws.close(); raise ConnectionError('Relay-Authentifizierung fehlgeschlagen')
                sock = RelayAgentSocket(ws, self.device_id)
                sock.settimeout(OFFLINE_TIMEOUT)
                file = sock
                host = 'CORE Nexus Cloud'

            self.uiq.put(('transport', host))
            send_json(sock, {'type':'hello', 'device_id':self.device_id, 'name':platform.node() or (platform.system() + '-PC'), 'os':platform.platform(), 'boot_id':self._boot_id()})
            reply = recv_json(file)
            if not reply.get('ok'):
                raise ConnectionError('Der Server hat die Registrierung abgelehnt.')
            self.sock = sock
            self.file = file
            self.connected = True
            self.connecting = False
            # Local consent is requested once per installation unless the user explicitly revoked it.
            consent_file = os.path.join(BASE, 'consent.json')
            consent = None
            try:
                with open(consent_file, 'r', encoding='utf-8') as f:
                    consent = json.load(f).get('accepted')
            except Exception:
                pass
            if consent is None:
                self.uiq.put(('consent', None))
                return
            send_json(sock, {'type':'consent', 'accepted':bool(consent)})
            state = recv_json(file)
            if not consent:
                raise PermissionError('Lokale Zustimmung wurde verweigert. Der Agent bleibt geschlossen.')
            if not state.get('approved'):
                if state.get('server_approved') and not state.get('consent'):
                    self.set_status('Serverfreigabe vorhanden, aber die lokale Zustimmung fehlt. Bitte Zustimmung am Ziel-PC erneut erteilen.')
                else:
                    self.set_status('Lokal verbunden. Serverfreigabe fehlt oder wurde widerrufen. Öffne im Server-Dashboard die Geräteverwaltung und gib dieses Gerät frei.')
            else:
                self.uiq.put(('transport', host)); self.set_status(f'Verbunden über {host}. Gerät ist freigegeben; Fernsteuerung startet nur in einer ausdrücklich geöffneten Sitzung.')
            threading.Thread(target=self.heartbeat_loop, daemon=True).start()
        except Exception as e:
            self.connected = False
            self.connecting = False
            if self.sock is sock:
                self.sock = None
                self.file = None
            try:
                if sock: sock.close()
            except Exception:
                pass
            self.set_status(f'Verbindung fehlgeschlagen: {e}\nDer Agent sucht automatisch jede Minute erneut nach einem Server.')
            self.uiq.put(('offline', str(e)))

    @staticmethod
    def _boot_id():
        # A best-effort boot marker; no system changes are made.
        try: return str(int(time.time()-time.monotonic()))
        except Exception: return 'unknown'

    def heartbeat_loop(self):
        # Frequent small heartbeats keep input latency low. Screenshots are sent
        # less often and compressed cheaply so a slow uplink is not saturated.
        while self.running and self.sock:
            try:
                packet={'type':'heartbeat'}
                now=time.monotonic()
                if self.remote_active and REMOTE_LIBS and now-self._last_frame_time >= REMOTE_FRAME_INTERVAL:
                    try:
                        packet['frame']=self.capture_frame()
                        self._last_frame_time=now
                    except Exception as capture_error:
                        self.set_status(f'Bildschirm konnte nicht erfasst werden: {capture_error}')
                send_json(self.sock,packet)
                reply=recv_json(self.file)
                if reply.get('close_agent'):
                    self.set_status('Der Server hat das Schließen des Agenten angefordert.')
                    self.uiq.put(('close',None)); return
                approved=bool(reply.get('approved'))
                server_approved=bool(reply.get('server_approved'))
                consent=bool(reply.get('consent'))
                self.remote_active=bool(reply.get('remote_active')) and approved and REMOTE_LIBS
                for command in reply.get('commands',[]):
                    try:
                        self.perform_input(command)
                        self.input_count += 1
                    except Exception as command_error:
                        self.set_status(f'Eingabe konnte nicht ausgeführt werden: {command_error}')
                if approved != self.last_approved or server_approved != self.last_server_approved or consent != self.last_consent:
                    if approved:
                        self.set_status('Verbunden und freigegeben. Keine Fernsteuerung aktiv, bis eine Sitzung am Server geöffnet wird.')
                    elif not consent:
                        self.set_status('Lokale Zustimmung fehlt oder wurde widerrufen. Fernzugriff bleibt gesperrt.')
                    else:
                        self.set_status('Agent läuft und ist mit dem Server verbunden. Serverfreigabe fehlt oder wurde widerrufen; Fernzugriff bleibt gesperrt.')
                    self.last_approved=approved; self.last_server_approved=server_approved; self.last_consent=consent
                time.sleep(REMOTE_HEARTBEAT_INTERVAL if self.remote_active else 1.0)
            except Exception as e:
                self.remote_active=False
                self.set_status(f'Verbindung zum Server verloren: {e}\nDer Agent bleibt geöffnet. Prüfe das Netzwerk und klicke auf „Erneut verbinden“.')
                failed_sock=self.sock
                self.connected=False
                self.sock=None
                self.file=None
                try:
                    if failed_sock: failed_sock.close()
                except Exception:
                    pass
                self.uiq.put(('offline',str(e))); return

    def capture_frame(self):
        # Reuse one MSS capture handle and avoid expensive JPEG optimize passes.
        if self._mss_capture is None:
            self._mss_capture = mss.mss()
        monitors=self._mss_capture.monitors
        self.monitor_index=max(1,min(self.monitor_index,len(monitors)-1))
        monitor=monitors[self.monitor_index]
        shot=self._mss_capture.grab(monitor)
        native_w,native_h=shot.size
        image=Image.frombytes('RGB',shot.size,shot.rgb)
        image.thumbnail(REMOTE_FRAME_MAX_SIZE)
        self.frame_native_size=(native_w,native_h)
        self.frame_encoded_size=image.size
        import io
        buf=io.BytesIO()
        image.save(buf,format='JPEG',quality=REMOTE_JPEG_QUALITY,optimize=False,progressive=False)
        return base64.b64encode(buf.getvalue()).decode('ascii')

    def _input_position(self, command):
        x=int(command.get('x',0)); y=int(command.get('y',0))
        encoded=self.frame_encoded_size; native=self.frame_native_size
        if encoded and native and encoded[0]>0 and encoded[1]>0:
            x=round(x*native[0]/encoded[0]); y=round(y*native[1]/encoded[1])
        if native:
            x=max(0,min(native[0]-1,x)); y=max(0,min(native[1]-1,y))
        return (x,y)

    def perform_input(self, command):
        # Input is accepted only during an explicitly active, approved session.
        if not REMOTE_LIBS or not self.remote_active: return
        if self.remote_mouse is None or self.remote_keyboard is None:
            raise RuntimeError('Maus-/Tastaturcontroller ist nicht initialisiert. Bitte Agent neu installieren.')
        kind=command.get('kind')
        if kind=='monitor_next':
            if self._mss_capture is None: self._mss_capture=mss.mss()
            count=max(1,len(self._mss_capture.monitors)-1)
            self.monitor_index=(self.monitor_index % count)+1
            self.set_status(f'Fernsteuerung: Monitor {self.monitor_index} von {count} ausgewählt.')
        elif kind=='clipboard_text':
            text_value=str(command.get('text',''))[:20000]
            try:
                import pyperclip
                pyperclip.copy(text_value)
                self.set_status('Zwischenablage wurde über die freigegebene Sitzung aktualisiert.')
            except Exception as exc: self.set_status(f'Zwischenablage nicht verfügbar: {exc}')
        elif kind=='file_begin':
            tid=str(command.get('transfer_id',''))[:80]
            name=os.path.basename(str(command.get('name','datei.bin')))[:180]
            chunks=int(command.get('chunks',0))
            if tid and 0 <= chunks <= 120:
                self.file_transfers[tid]={'name':name,'chunks':chunks,'parts':{}}
        elif kind=='file_chunk':
            tid=str(command.get('transfer_id',''))[:80]; transfer=self.file_transfers.get(tid)
            if transfer:
                idx=int(command.get('index',-1)); data=str(command.get('data',''))
                if 0 <= idx < transfer['chunks'] and len(data)<=24000: transfer['parts'][idx]=data
        elif kind=='file_end':
            tid=str(command.get('transfer_id',''))[:80]; transfer=self.file_transfers.pop(tid,None)
            if transfer and len(transfer['parts'])==transfer['chunks']:
                try:
                    raw=base64.b64decode(''.join(transfer['parts'][i] for i in range(transfer['chunks'])),validate=True)
                    if len(raw)<=2*1024*1024:
                        outdir=os.path.join(os.path.expanduser('~'),'Downloads','CORE-Nexus-Received'); os.makedirs(outdir,exist_ok=True)
                        outpath=os.path.join(outdir,os.path.basename(transfer['name']))
                        with open(outpath,'wb') as handle: handle.write(raw)
                        self.set_status(f'Datei empfangen: {outpath}')
                    else: self.set_status('Dateiübertragung abgebrochen: Größenlimit überschritten.')
                except Exception as exc: self.set_status(f'Dateiübertragung fehlgeschlagen: {exc}')
            else: self.set_status('Dateiübertragung unvollständig; Datei wurde verworfen.')
        elif kind=='move': self.remote_mouse.position=self._input_position(command)
        elif kind=='click':
            self.remote_mouse.position=self._input_position(command)
            btn=Button.right if command.get('button')=='right' else Button.left
            self.remote_mouse.click(btn, 1)
        elif kind=='scroll':
            self.remote_mouse.position=self._input_position(command)
            self.remote_mouse.scroll(0, int(command.get('dy',0)))
        elif kind=='key':
            name=str(command.get('key',''))[:40]
            keymap={'enter':Key.enter,'tab':Key.tab,'esc':Key.esc,'backspace':Key.backspace,'delete':Key.delete,'space':Key.space,'up':Key.up,'down':Key.down,'left':Key.left,'right':Key.right,'shift':Key.shift,'ctrl':Key.ctrl,'alt':Key.alt,'win':Key.cmd,'f1':Key.f1,'f2':Key.f2,'f3':Key.f3,'f4':Key.f4,'f5':Key.f5,'f6':Key.f6,'f7':Key.f7,'f8':Key.f8,'f9':Key.f9,'f10':Key.f10,'f11':Key.f11,'f12':Key.f12}
            key=keymap.get(name.lower(), name if len(name)==1 else None)
            if key is not None:
                action=command.get('action','press')
                if action=='down': self.remote_keyboard.press(key)
                elif action=='up': self.remote_keyboard.release(key)
                else: self.remote_keyboard.press(key); self.remote_keyboard.release(key)
        elif kind=='text':
            self.remote_keyboard.type(str(command.get('text',''))[:200])

    def ask_consent(self):
        answer=messagebox.askyesno(APP,'CORE Nexus wurde auf diesem PC erkannt.\n\nErlaubst du diesem Gerät, nach Freigabe im Server-Dashboard für Fernansichten und Steuerung verfügbar zu sein? Du kannst die Zustimmung später durch Löschen von Agent/consent.json und erneute Einrichtung zurücksetzen.',parent=self.root)
        try:
            with open(os.path.join(BASE,'consent.json'),'w',encoding='utf-8') as f: json.dump({'accepted':answer},f)
            if self.sock:
                send_json(self.sock,{'type':'consent','accepted':answer}); reply=recv_json(self.file)
                if not answer: self.set_status('Du hast die Zustimmung verweigert. Agent bleibt geschlossen.'); self.close_after(1500); return
                if reply.get('approved'):
                    self.set_status('Zustimmung gespeichert. Gerät ist freigegeben und verbunden.')
                else:
                    self.set_status('Zustimmung gespeichert. Bitte gib dieses Gerät zusätzlich im Server-Dashboard frei.')
                threading.Thread(target=self.heartbeat_loop,daemon=True).start()
        except Exception as e: self.set_status(f'Zustimmung konnte nicht übermittelt werden: {e}')

    def poll(self):
        try:
            while True:
                kind,value=self.uiq.get_nowait()
                if kind=='status':
                    self.status.configure(text=value)
                    low=value.lower()
                    if 'verbunden' in low or 'zustimmung gespeichert' in low:
                        self.badge.configure(text='●  CONNECTED',foreground='#47e0a0')
                    elif 'fehlgeschlagen' in low or 'nicht erreichbar' in low or 'fehler' in low:
                        self.badge.configure(text='●  OFFLINE',foreground='#ff7285')
                    else:
                        self.badge.configure(text='●  CONNECTING',foreground='#ffca70')
                elif kind=='transport':
                    self.connection_mode=str(value)
                    self.transport.configure(text=('CLOUD SERVER' if 'Cloud' in str(value) or 'Render' in str(value) else str(value)))
                elif kind=='consent': self.root.after(100,self.ask_consent)
                elif kind=='offline': self.retry.configure(state='normal'); self.badge.configure(text='●  OFFLINE',foreground='#ff7285'); self.status.configure(text='Keine Cloud-Verbindung. Automatischer neuer Verbindungsversuch in spätestens 60 Sekunden; du kannst auch manuell erneut verbinden.')
                elif kind=='close': self.close_after(500)
        except queue.Empty: pass
        if self.running: self.root.after(250,self.poll)

    def close_after(self,ms): self.root.after(ms,self.close)
    def close(self):
        self.running=False
        try:
            if self.sock: self.sock.close()
        except OSError: pass
        try:
            if self._mss_capture is not None:
                self._mss_capture.close()
                self._mss_capture = None
        except Exception: pass
        try: self.root.destroy()
        except tk.TclError: pass

class AgentControlClient:
    """Authenticated account session to the server's controller endpoint."""
    def __init__(self, host, port, username, password, relay_fallback=False):
        self.relay=False; self.send_lock=threading.RLock(); self.pending={}; self.pending_lock=threading.RLock(); self.next_id=0; self.events=queue.Queue(); self.closed=False
        if host is not None:
            self.sock=socket.create_connection((host,port),timeout=8); self.sock.settimeout(10); self.file=self.sock.makefile('rwb')
        elif relay_fallback:
            cfg_path=os.path.join(BASE,'relay_config.json')
            try:
                with open(cfg_path,'r',encoding='utf-8') as handle: cfg=json.load(handle)
            except Exception: cfg={}
            token=(os.environ.get(cfg.get('relay_token_env','CORE_NEXUS_RELAY_TOKEN')) or cfg.get('relay_token') or '').strip()
            relay_url=str(cfg.get('relay_url','')).strip(); room=str(cfg.get('room_id','')).strip()
            if not cfg.get('enabled') or not relay_url.startswith('wss://') or not room or not token or 'PASTE_' in token:
                raise ConnectionError('Kein LAN-Server erreichbar und das Render-Relay ist nicht vollständig konfiguriert.')
            import websocket
            self.controller_id='controller-'+str(uuid.uuid4())
            ws=websocket.create_connection(relay_url,timeout=10,origin=relay_url.split('/ws')[0])
            ws.send(json.dumps({'type':'auth','token':token,'room_id':room,'client_id':self.controller_id,'role':'admin'}))
            auth=json.loads(ws.recv())
            if auth.get('type')!='auth_ok':
                ws.close(); raise ConnectionError('Relay-Authentifizierung fehlgeschlagen')
            self.sock=RelayAgentSocket(ws,self.controller_id); self.file=self.sock; self.relay=True
        else:
            raise ConnectionError('Kein Server-Endpunkt verfügbar.')
        self._send_raw({'type':'hello','client_role':'agent_user','username':username,**({'device_id':self.controller_id} if self.relay else {})})
        line=self.file.readline()
        if not line: self.close(); raise ConnectionError('Der Server hat die Anmeldung abgebrochen.')
        try: challenge=json.loads(line.decode('utf-8'))
        except Exception: self.close(); raise ConnectionError('Ungültige Serverantwort.')
        if not challenge.get('ok') or challenge.get('type') != 'auth_challenge':
            if not self.relay: self.sock.settimeout(None)
            self.close(); raise PermissionError('Anmeldung fehlgeschlagen. Prüfe Benutzername, Passwort und ob das Konto aktiv ist.')
        try:
            salt=base64.b64decode(challenge['salt'])
            derived=hashlib.pbkdf2_hmac('sha256',password.encode('utf-8'),salt,310_000)
            proof=hmac.new(derived,str(challenge['nonce']).encode('utf-8'),hashlib.sha256).hexdigest()
        except Exception:
            if not self.relay: self.sock.settimeout(None)
            self.close(); raise ConnectionError('Die Server-Anmeldeprüfung konnte nicht vorbereitet werden.')
        self._send_raw({'type':'agent_auth_proof','proof':proof})
        line=self.file.readline()
        if not self.relay: self.sock.settimeout(None)
        if not line: self.close(); raise ConnectionError('Der Server hat die Anmeldung abgebrochen.')
        try: reply=json.loads(line.decode('utf-8'))
        except Exception: self.close(); raise ConnectionError('Ungültige Serverantwort.')
        if not reply.get('ok') or reply.get('type') != 'agent_login_result':
            self.close(); raise PermissionError('Anmeldung fehlgeschlagen. Prüfe Benutzername, Passwort und ob das Konto aktiv ist.')
        self.username=reply.get('username',username)
        self.reader=threading.Thread(target=self._reader,daemon=True); self.reader.start()

    def _send_raw(self,obj):
        with self.send_lock:
            raw=(json.dumps(obj,separators=(',',':'))+'\n').encode('utf-8')
            if self.relay: self.sock.sendall(raw)
            else: self.file.write(raw); self.file.flush()

    def request(self,typ,timeout=8,**kwargs):
        with self.pending_lock:
            self.next_id+=1; rid=self.next_id; event=threading.Event(); holder={}; self.pending[rid]=(event,holder)
        self._send_raw({'type':typ,'request_id':rid,**kwargs})
        if not event.wait(timeout):
            with self.pending_lock: self.pending.pop(rid,None)
            raise TimeoutError('Der Server hat nicht rechtzeitig geantwortet.')
        result=holder.get('result',{})
        if not result.get('ok',False):
            errors={'permission_denied':'Dieses Konto besitzt nicht die erforderlichen Rechte.','device_offline':'Das Gerät ist offline.','device_not_approved_or_no_consent':'Das Gerät benötigt Serverfreigabe und lokale Zustimmung.','server_remote_session_busy':'Der Server verwendet die Fernsteuerung bereits.','another_admin_session_active':'Eine andere Controller-Sitzung ist aktiv.','device_not_assigned':'Dieses Gerät wurde diesem Konto nicht zugewiesen.'}
            raise PermissionError(errors.get(result.get('error'),result.get('error','Serveranfrage fehlgeschlagen.')))
        return result

    def send_input(self,device_id,command):
        if not self.closed: self._send_raw({'type':'remote_input','device_id':device_id,'command':command})

    def _reader(self):
        try:
            while not self.closed:
                line=self.file.readline()
                if not line: break
                msg=json.loads(line.decode('utf-8'))
                rid=msg.get('request_id')
                if rid is not None:
                    with self.pending_lock: pair=self.pending.pop(rid,None)
                    if pair: pair[1]['result']=msg; pair[0].set()
                else:
                    self.events.put(msg)
        except Exception as exc:
            if not self.closed: self.events.put({'type':'connection_lost','error':str(exc)})
        finally:
            if not self.closed: self.events.put({'type':'connection_lost','error':'Verbindung zum Server wurde beendet.'})

    def close(self):
        if self.closed: return
        self.closed=True
        try: self.sock.shutdown(socket.SHUT_RDWR)
        except Exception: pass
        try: self.sock.close()
        except Exception: pass


class AgentControlWindow:
    def __init__(self, agent, client, username):
        self.agent=agent; self.root=agent.root; self.client=client; self.username=username; self.device_id=None; self.remote_win=None; self.remote_label=None; self.photo=None; self.last_frame=None; self._frame_pending=False; self.frame_size=(1,1); self.display_size=(1,1); self._last_input_move=0.0; self._last_ping=time.monotonic()
        win=tk.Toplevel(self.root); self.win=win; win.title(f'CORE Nexus | Angemeldet als {username}'); win.geometry('760x520'); win.configure(bg='#060b16'); win.transient(self.root)
        body=ttk.Frame(win,padding=18); body.pack(fill='both',expand=True)
        ttk.Label(body,text='GERÄTEKONTROLLE',style='Title.TLabel').pack(anchor='w')
        ttk.Label(body,text=f'Angemeldet als {username} · Rechte werden vom Server geprüft.',style='Sub.TLabel').pack(anchor='w',pady=(2,12))
        bar=ttk.Frame(body); bar.pack(fill='x',pady=(0,8)); ttk.Button(bar,text='Geräteliste aktualisieren',command=self.refresh_devices).pack(side='left'); ttk.Button(bar,text='Fernsteuerung starten',command=self.start_remote).pack(side='left',padx=8); ttk.Button(bar,text='Fernsteuerung beenden',command=self.stop_remote).pack(side='left')
        self.status=ttk.Label(body,text='Lade freigegebene Geräte …',style='Sub.TLabel'); self.status.pack(anchor='w',pady=(0,8))
        self.tree=ttk.Treeview(body,columns=('name','online','os','ip'),show='headings',selectmode='browse')
        for col,label,width in [('name','Gerät',220),('online','Verbindung',100),('os','Betriebssystem',240),('ip','IP-Adresse',130)]: self.tree.heading(col,text=label); self.tree.column(col,width=width,anchor='w')
        self.tree.pack(fill='both',expand=True)
        win.protocol('WM_DELETE_WINDOW',self.close); self.refresh_devices(); self._poll_events()

    def refresh_devices(self):
        try:
            result=self.client.request('list_devices')
            for item in self.tree.get_children(): self.tree.delete(item)
            for d in result.get('devices',[]): self.tree.insert('', 'end', iid=d['id'], values=(d.get('name','PC'),'Online' if d.get('online') else 'Offline',d.get('os',''),d.get('ip','')))
            self.status.configure(text=f'{len(result.get("devices",[]))} freigegebene Geräte gefunden.')
        except Exception as exc: self.status.configure(text=str(exc))

    def start_remote(self):
        selected=self.tree.selection()
        if not selected: self.status.configure(text='Wähle zuerst ein Gerät aus.'); return
        did=str(selected[0])
        try:
            result=self.client.request('remote_start',device_id=did)
            self.device_id=did; self.last_frame=None; self._frame_pending=False
            self.remote_win=tk.Toplevel(self.win); self.remote_win.title('CORE Nexus | Fernsteuerung'); self.remote_win.geometry('1000x650'); self.remote_win.configure(bg='#050914')
            ttk.Label(self.remote_win,text=f'Fernsteuerung: {result.get("device_name",did)} · freigegebene Sitzung',style='Sub.TLabel').pack(anchor='w',padx=10,pady=8)
            controls=ttk.Frame(self.remote_win); controls.pack(fill='x',padx=10)
            ttk.Button(controls,text='Datei senden',command=self.send_file_to_remote).pack(side='left',padx=(0,5))
            ttk.Button(controls,text='Zwischenablage teilen',command=self.share_clipboard_to_remote).pack(side='left',padx=5)
            ttk.Button(controls,text='Nächster Monitor',command=lambda:self.client.send_input(self.device_id,{'kind':'monitor_next'})).pack(side='left',padx=5)
            self.quality_label=ttk.Label(controls,text='Verbindungsqualität: wird gemessen',style='Sub.TLabel'); self.quality_label.pack(side='left',padx=8)
            self._last_frame_at=0.0; self._frame_intervals=[]
            self.remote_label=tk.Label(self.remote_win,text='Warte auf Bildschirmbild …',bg='#050914',fg='#eaf2ff',takefocus=1,cursor='crosshair'); self.remote_label.pack(fill='both',expand=True,padx=10,pady=8)
            self.remote_label.bind('<Motion>',self.motion); self.remote_label.bind('<Button-1>',lambda e:self.click(e,'left')); self.remote_label.bind('<Button-3>',lambda e:self.click(e,'right')); self.remote_label.bind('<MouseWheel>',self.scroll); self.remote_label.bind('<KeyPress>',self.keydown); self.remote_label.bind('<KeyRelease>',self.keyup); self.remote_win.bind('<KeyPress>',self.keydown); self.remote_win.bind('<KeyRelease>',self.keyup)
            self.remote_win.protocol('WM_DELETE_WINDOW',self.stop_remote); self.remote_label.focus_set(); self.status.configure(text='Fernsteuerung aktiv. Der Server kann diese Sitzung jederzeit beenden.')
        except Exception as exc: self.status.configure(text=str(exc))

    def share_clipboard_to_remote(self):
        if not self.device_id: return
        try: content=self.agent.root.clipboard_get()
        except Exception:
            messagebox.showwarning(APP,'Die lokale Zwischenablage enthält keinen lesbaren Text.',parent=self.remote_win); return
        if len(content)>20000:
            messagebox.showwarning(APP,'Die Zwischenablage ist auf 20.000 Zeichen begrenzt.',parent=self.remote_win); return
        if not messagebox.askyesno(APP,f'{len(content)} Zeichen an das Zielgerät übertragen?',parent=self.remote_win): return
        self.client.send_input(self.device_id,{'kind':'clipboard_text','text':content})

    def send_file_to_remote(self):
        if not self.device_id: return
        from tkinter import filedialog
        import os
        path=filedialog.askopenfilename(parent=self.remote_win,title='Datei an Zielgerät senden')
        if not path: return
        try:
            size=os.path.getsize(path)
            if size>2*1024*1024:
                messagebox.showwarning(APP,'Maximal 2 MiB pro Datei.',parent=self.remote_win); return
            with open(path,'rb') as f: data=f.read()
            name=os.path.basename(path).replace('\\','_').replace('/','_')[:180]
            if not messagebox.askyesno(APP,f'Datei „{name}“ ({size} Bytes) senden?',parent=self.remote_win): return
            encoded=base64.b64encode(data).decode('ascii'); chunk_size=24000; tid=str(uuid.uuid4()); total=(len(encoded)+chunk_size-1)//chunk_size
            self.client.send_input(self.device_id,{'kind':'file_begin','transfer_id':tid,'name':name,'chunks':total})
            for i in range(total): self.client.send_input(self.device_id,{'kind':'file_chunk','transfer_id':tid,'index':i,'data':encoded[i*chunk_size:(i+1)*chunk_size]})
            self.client.send_input(self.device_id,{'kind':'file_end','transfer_id':tid})
            messagebox.showinfo(APP,'Dateiübertragung eingereiht. Zielgerät muss online bleiben.',parent=self.remote_win)
        except Exception as exc: messagebox.showerror(APP,f'Dateiübertragung fehlgeschlagen: {exc}',parent=self.remote_win)

    def stop_remote(self):
        if self.device_id:
            try: self.client.request('remote_stop',device_id=self.device_id,timeout=3)
            except Exception: pass
        self.device_id=None; self.photo=None; self.remote_label=None
        if self.remote_win is not None:
            try: self.remote_win.destroy()
            except tk.TclError: pass
            self.remote_win=None
        if hasattr(self,'status'):
            try: self.status.configure(text='Fernsteuerung beendet.')
            except tk.TclError: pass

    def _coords(self,e):
        w=max(1,self.remote_label.winfo_width()); h=max(1,self.remote_label.winfo_height()); sw,sh=self.display_size; iw,ih=self.frame_size
        ox=(w-sw)/2; oy=(h-sh)/2
        return (min(max(0,round((e.x-ox)*iw/max(1,sw))),iw-1),min(max(0,round((e.y-oy)*ih/max(1,sh))),ih-1))
    def motion(self,e):
        now=time.monotonic()
        if now-self._last_input_move<0.025:return
        self._last_input_move=now; x,y=self._coords(e); self.client.send_input(self.device_id,{'kind':'move','x':x,'y':y})
    def click(self,e,b):
        self.remote_label.focus_set(); x,y=self._coords(e); self.client.send_input(self.device_id,{'kind':'click','x':x,'y':y,'button':b})
    def scroll(self,e):
        x,y=self._coords(e); self.client.send_input(self.device_id,{'kind':'scroll','x':x,'y':y,'dy':1 if e.delta>0 else -1})
    def keydown(self,e):
        if not self.device_id:return
        names={'Return':'enter','Tab':'tab','Escape':'esc','BackSpace':'backspace','Delete':'delete','space':'space','Up':'up','Down':'down','Left':'left','Right':'right','Shift_L':'shift','Control_L':'ctrl','Alt_L':'alt','Super_L':'win'}
        key=names.get(e.keysym,e.keysym.lower() if e.keysym.lower().startswith('f') and e.keysym[1:].isdigit() else (e.char if e.char and e.char.isprintable() else ''))
        if key:self.client.send_input(self.device_id,{'kind':'key','key':key,'action':'down' if key in ('shift','ctrl','alt','win') else 'press'})
    def keyup(self,e):
        if not self.device_id:return
        names={'Shift_L':'shift','Control_L':'ctrl','Alt_L':'alt','Super_L':'win'}; key=names.get(e.keysym)
        if key:self.client.send_input(self.device_id,{'kind':'key','key':key,'action':'up'})

    def _poll_events(self):
        if not self.win.winfo_exists(): return
        if time.monotonic()-self._last_ping >= 8:
            try: self.client._send_raw({'type':'ping'})
            except Exception: pass
            self._last_ping=time.monotonic()
        try:
            while True:
                msg=self.client.events.get_nowait(); typ=msg.get('type')
                if typ=='frame' and self.device_id and msg.get('device_id')==self.device_id:
                    now=time.monotonic()
                    if self._last_frame_at:
                        self._frame_intervals.append(now-self._last_frame_at); self._frame_intervals=self._frame_intervals[-12:]
                        avg=sum(self._frame_intervals)/len(self._frame_intervals); quality='Gut' if avg<0.35 else ('Mittel' if avg<0.8 else 'Schwach')
                        try: self.quality_label.configure(text=f'Bildrate: {1/max(avg,0.01):.1f} FPS · Qualität: {quality}')
                        except Exception: pass
                    self._last_frame_at=now
                    try:
                        self.last_frame=base64.b64decode(msg.get('frame',''))
                        self._frame_pending=True
                    except Exception: pass
                elif typ=='remote_forced_stop': self.stop_remote(); self.status.configure(text='Die Fernsteuerung wurde durch den Server beendet.')
                elif typ=='connection_lost': self.stop_remote(); self.status.configure(text='Serververbindung verloren: '+str(msg.get('error','')))
        except queue.Empty: pass
        if self.remote_label is not None and self.last_frame and self._frame_pending:
            try:
                from PIL import Image, ImageTk
                im=Image.open(io.BytesIO(self.last_frame)); self.frame_size=im.size
                im.thumbnail((max(1,self.remote_label.winfo_width()),max(1,self.remote_label.winfo_height())))
                self.display_size=im.size; self.photo=ImageTk.PhotoImage(im); self.remote_label.configure(image=self.photo,text=''); self._frame_pending=False
            except Exception as exc: self.remote_label.configure(text=f'Bild konnte nicht angezeigt werden: {exc}'); self._frame_pending=False
        self.win.after(80,self._poll_events)

    def close(self):
        self.stop_remote(); self.client.close()
        try:self.win.destroy()
        except tk.TclError:pass


if __name__=='__main__':
    app = Agent()
    app.root.mainloop()
