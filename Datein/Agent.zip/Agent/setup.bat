﻿@echo off
setlocal EnableExtensions
chcp 65001 >nul
cd /d "%~dp0"
title CORE Nexus Agent - Verwaltung

rem Dieses Menue fragt zuerst nach einer Aktion. Bis zur Auswahl werden keine Aenderungen vorgenommen.
:menu
cls
echo ============================================
echo       CORE Nexus Agent - VERWALTUNG
echo ============================================
echo.
echo Was moechtest du machen?
echo.
echo   [1] Installieren / reparieren + Autostart aktivieren
echo   [2] Deinstallieren
echo   [3] Nur Autostart aktivieren
echo   [4] Nur Autostart deaktivieren
echo   [5] Abbrechen
echo.
choice /C 12345 /N /M "Bitte Auswahl treffen [1-5]: "
if errorlevel 5 goto cancel
if errorlevel 4 goto disable_startup
if errorlevel 3 goto enable_startup
if errorlevel 2 goto uninstall
if errorlevel 1 goto install

:install
cls
title CORE Nexus Agent - Installation
echo ============================================
echo       CORE Nexus Agent - INSTALLATION
echo ============================================
echo.
rem Use Python 3.15 only. Do not fall back to another Python version.
set "PY="
where py >nul 2>&1
if not errorlevel 1 (
  py -V:3.15 -c "import sys; print(sys.version); raise SystemExit(0 if sys.version_info[:2] == (3,15) else 1)" >nul 2>&1
  if not errorlevel 1 set "PY=py -V:3.15"
)
if not defined PY (
  where python >nul 2>&1
  if not errorlevel 1 (
    python -c "import sys; print(sys.version); raise SystemExit(0 if sys.version_info[:2] == (3,15) else 1)" >nul 2>&1
    if not errorlevel 1 set "PY=python"
  )
)
if not defined PY (
  echo FEHLER: Python 3.15 wurde nicht gefunden.
  echo Windows Server 2019: Python Install Manager per MSI installieren, danach "py install 3.15" ausfuehren. Python 3.15 x64 mit Tcl/Tk und pip benoetigt.
  echo Andere Python-Versionen werden absichtlich nicht verwendet.
  pause
  exit /b 1
)
%PY% --version
if errorlevel 1 (
  echo FEHLER: Python 3.15 konnte nicht gestartet werden.
  pause
  exit /b 1
)
%PY% -c "import tkinter; print('Tkinter OK')" >nul 2>&1
if errorlevel 1 (
  echo FEHLER: Tkinter fehlt. Python 3.15 mit Tcl/Tk-Unterstuetzung installieren.
  pause
  exit /b 1
)
%PY% -m pip install --upgrade --disable-pip-version-check pip
if errorlevel 1 (
  echo FEHLER: pip konnte nicht aktualisiert werden.
  pause
  exit /b 1
)
%PY% -m pip install --upgrade --disable-pip-version-check pillow mss pynput websocket-client
if errorlevel 1 (
  echo FEHLER: Abhaengigkeiten konnten nicht installiert werden.
  echo Pruefe Internetzugang und ob passende Pakete fuer Python 3.15 verfuegbar sind.
  pause
  exit /b 1
)
%PY% -m py_compile agent.py
if errorlevel 1 (
  echo FEHLER: agent.py hat einen Syntaxfehler. Installation abgebrochen.
  pause
  exit /b 1
)
if not exist "data" mkdir "data"
>"installed.flag" echo CORE Nexus installiert am %DATE% %TIME%
echo.
echo Installation erfolgreich. Aktiviere den Autostart...
call :enable_startup_action
if errorlevel 1 (
  echo WARNUNG: Installation abgeschlossen, aber der Autostart konnte nicht aktiviert werden.
  pause
  exit /b 1
)
echo.
echo Fertig. CORE Nexus Agent startet ab der naechsten Windows-Anmeldung automatisch.
echo Zum sofortigen Start weiterhin start.bat verwenden.
echo.
pause
exit /b 0

:enable_startup
if not exist "installed.flag" (
  echo.
  echo CORE Nexus Agent ist noch nicht installiert. Bitte zuerst Option 1 auswaehlen.
  pause
  goto menu
)
call :enable_startup_action
if errorlevel 1 (pause & exit /b 1)
echo.
pause
goto menu

:enable_startup_action
set "START_FILE=%~dp0start.bat"
set "STARTUP_DIR=%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup"
if not exist "%STARTUP_DIR%" mkdir "%STARTUP_DIR%"
powershell -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='Stop'; $ws=New-Object -ComObject WScript.Shell; $link=$ws.CreateShortcut((Join-Path $env:APPDATA 'Microsoft\Windows\Start Menu\Programs\Startup\CORE Nexus Agent.lnk')); $link.TargetPath=$env:START_FILE; $link.WorkingDirectory=(Split-Path -Parent $env:START_FILE); $link.WindowStyle=7; $link.Description='CORE Nexus Agent automatisch beim Windows-Anmelden starten'; $link.Save()"
if errorlevel 1 (
  echo FEHLER: Autostart konnte nicht eingerichtet werden.
  exit /b 1
)
echo Autostart aktiviert.
exit /b 0

:disable_startup
set "LINK=%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup\CORE Nexus Agent.lnk"
if exist "%LINK%" (
  del /q "%LINK%"
  echo Autostart wurde deaktiviert.
) else (
  echo Kein Autostart-Eintrag gefunden.
)
echo.
pause
goto menu

:uninstall
cls
title CORE Nexus Agent - Deinstallation
echo ============================================
echo       CORE Nexus Agent - DEINSTALLATION
echo ============================================
echo.
echo Die Autostart-Verknuepfung und die Installationsmarkierung werden entfernt.
echo.
choice /C JN /N /M "Sollen auch lokale Anwendungsdaten geloescht werden? [J/N] "
if errorlevel 2 goto keepdata
if errorlevel 1 goto deletedata

goto cleanup
:deletedata
if exist "data" rmdir /s /q "data"
if exist "device_id.json" del /q "device_id.json"
if exist "consent.json" del /q "consent.json"
goto cleanup
:keepdata
echo Lokale Daten bleiben erhalten.
:cleanup
set "LINK=%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup\CORE Nexus Agent.lnk"
if exist "%LINK%" del /q "%LINK%"
if exist "__pycache__" rmdir /s /q "__pycache__"
if exist "installed.flag" del /q "installed.flag"
echo.
echo Deinstallation abgeschlossen.
echo Der Programmordner und die Python-Dateien bleiben erhalten, damit du sie manuell entfernen kannst.
pause
exit /b 0

:cancel
echo.
echo Abgebrochen. Es wurden keine Aenderungen vorgenommen.
pause
exit /b 0
