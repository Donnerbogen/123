"""CORE Nexus LAN agent. Run with: python agent.py
Requires explicit local user consent and server-side device approval.
"""
from __future__ import annotations
import json, os, platform, queue, socket, threading, time, uuid
import tkinter as tk
from tkinter import ttk, messagebox
import base64
try:
    import mss
    from PIL import Image
    from pynput.mouse import Controller as MouseController, Button
    from pynput.keyboard import Controller as KeyboardController, Key
    REMOTE_LIBS = True
except Exception:
    REMOTE_LIBS = False

APP='CORE Nexus Agent'; DISCOVERY_PORT=47622; DEFAULT_PORT=47621
BASE=os.path.dirname(os.path.abspath(__file__)); ID_FILE=os.path.join(BASE,'device_id.json')
HEARTBEAT=5; OFFLINE_TIMEOUT=18
REMOTE_HEARTBEAT_INTERVAL=0.055
REMOTE_FRAME_INTERVAL=0.24
REMOTE_FRAME_MAX_SIZE=(1024, 576)
REMOTE_JPEG_QUALITY=34

def get_device_id():
    try:
        with open(ID_FILE,'r',encoding='utf-8') as f: return json.load(f)['device_id']
    except Exception:
        did=str(uuid.uuid4())
        try:
            with open(ID_FILE,'w',encoding='utf-8') as f: json.dump({'device_id':did},f)
        except OSError: pass
        return did

def discover_server(timeout=3):
    sock=socket.socket(socket.AF_INET,socket.SOCK_DGRAM); sock.setsockopt(socket.SOL_SOCKET,socket.SO_BROADCAST,1); sock.settimeout(timeout)
    try:
        sock.sendto(b'CORE_NEXUS_DISCOVER_V1',('<broadcast>',DISCOVERY_PORT))
        end=time.time()+timeout
        while time.time()<end:
            try: data,addr=sock.recvfrom(4096)
            except socket.timeout: break
            try:
                item=json.loads(data.decode('utf-8'))
                if item.get('app')=='CORE Nexus' and item.get('port'): return item['host'],int(item['port'])
            except Exception: continue
    finally: sock.close()
    return None

def send_json(sock,obj):
    sock.sendall((json.dumps(obj,separators=(',',':'))+'\n').encode('utf-8'))

def recv_json(file):
    line=file.readline()
    if not line: raise ConnectionError('Server hat die Verbindung beendet.')
    if len(line)>8_000_000: raise ValueError('Antwort des Servers ist zu groß.')
    return json.loads(line.decode('utf-8'))

class RelayAgentSocket:
    """Adapts a WSS relay connection to the existing newline-JSON socket interface."""
    def __init__(self, ws, device_id): self.ws=ws; self.device_id=device_id; self.closed=False
    def settimeout(self, value): self.ws.settimeout(value)
    def makefile(self, mode): return self
    def sendall(self, data):
        obj=json.loads(data.decode('utf-8').strip())
        self.ws.send(json.dumps({'device_id':self.device_id,'payload':obj},separators=(',',':')))
    def readline(self):
        while not self.closed:
            raw=self.ws.recv()
            if not raw: return b''
            envelope=json.loads(raw)
            if envelope.get('device_id') != self.device_id: continue
            payload=envelope.get('payload')
            if isinstance(payload,dict): return (json.dumps(payload,separators=(',',':'))+'\n').encode('utf-8')
        return b''
    def close(self):
        self.closed=True
        try: self.ws.close()
        except Exception: pass

class Agent:
    def __init__(self):
        self.device_id=get_device_id(); self.sock=None; self.file=None; self.running=True; self.connected=False; self.connecting=False; self.uiq=queue.Queue(); self.remote_active=False; self.remote_mouse=MouseController() if REMOTE_LIBS else None; self.remote_keyboard=KeyboardController() if REMOTE_LIBS else None; self.remote_last_frame=None; self._mss_capture=None; self.frame_native_size=None; self.frame_encoded_size=None; self._last_frame_time=0.0; self.input_count=0; self.last_approved=None; self.last_server_approved=None; self.connection_mode='Noch nicht verbunden'; self.root=tk.Tk(); self.root.title(APP); self.root.geometry('650x470'); self.root.minsize(600,440); self.root.configure(bg='#060b16'); self.root.resizable(True,True)
        style=ttk.Style(); style.theme_use('clam'); style.configure('.',background='#0b1628',foreground='#eef6ff',fieldbackground='#101f34',font=('Segoe UI',10)); style.configure('TFrame',background='#0b1628'); style.configure('TLabel',background='#0b1628',foreground='#eef6ff',font=('Segoe UI',10)); style.configure('Title.TLabel',font=('Segoe UI',23,'bold'),foreground='#55d9ff'); style.configure('Sub.TLabel',foreground='#91a7c4',font=('Segoe UI',9)); style.configure('Hero.TLabel',font=('Segoe UI',12,'bold'),foreground='#d9efff'); style.configure('Card.TFrame',background='#0d1b2e',relief='solid',borderwidth=1); style.configure('TButton',background='#153657',foreground='white',padding=(13,9),borderwidth=1); style.map('TButton',background=[('active','#1e5b89'),('pressed','#16436a')]); style.configure('TEntry',padding=7,fieldbackground='#071322',foreground='#eef6ff')
        outer=ttk.Frame(self.root,padding=22); outer.pack(fill='both',expand=True)
        top=ttk.Frame(outer); top.pack(fill='x',pady=(0,18)); brand=ttk.Frame(top); brand.pack(side='left',fill='x',expand=True); ttk.Label(brand,text='CORE NEXUS',style='Title.TLabel').pack(anchor='w'); ttk.Label(brand,text='SECURE ENDPOINT  /  WINDOWS AGENT',style='Sub.TLabel').pack(anchor='w',pady=(1,0))
        self.badge=ttk.Label(top,text='●  INITIALIZING',foreground='#ffca70',font=('Segoe UI',9,'bold')); self.badge.pack(side='right',anchor='center',padx=(8,0))
        card=ttk.Frame(outer,padding=18,style='Card.TFrame'); card.pack(fill='x',pady=(0,12)); ttk.Label(card,text='VERBINDUNGSSTATUS',style='Sub.TLabel').pack(anchor='w'); self.status=ttk.Label(card,text='Suche den CORE Nexus Server …',wraplength=540,style='Hero.TLabel'); self.status.pack(anchor='w',pady=(7,13)); ttk.Separator(card).pack(fill='x',pady=(0,10)); row=ttk.Frame(card); row.pack(fill='x'); ttk.Label(row,text='VERBINDUNGSWEG',style='Sub.TLabel').pack(side='left'); self.transport=ttk.Label(row,text='LAN → Render-Fallback',foreground='#55d9ff',font=('Segoe UI',9,'bold')); self.transport.pack(side='right')
        lower=ttk.Frame(outer); lower.pack(fill='both',expand=True); left=ttk.Frame(lower,padding=15,style='Card.TFrame'); left.pack(side='left',fill='both',expand=True,padx=(0,10)); ttk.Label(left,text='GERÄTEINFORMATION',style='Sub.TLabel').pack(anchor='w'); ttk.Label(left,text=f'Geräte-ID  {self.device_id[:18]}…',style='Hero.TLabel').pack(anchor='w',pady=(8,5)); ttk.Label(left,text=('Fernsteuerungsbibliotheken bereit' if REMOTE_LIBS else 'Fernsteuerungs-Abhängigkeiten fehlen'),foreground=('#47e0a0' if REMOTE_LIBS else '#ff7285'),wraplength=300).pack(anchor='w'); ttk.Label(left,text='Lokale Zustimmung und Serverfreigabe sind erforderlich.',style='Sub.TLabel',wraplength=300).pack(anchor='w',pady=(9,0))
        right=ttk.Frame(lower,padding=15,style='Card.TFrame'); right.pack(side='right',fill='y'); ttk.Label(right,text='AKTIONEN',style='Sub.TLabel').pack(anchor='w',pady=(0,9)); self.retry=ttk.Button(right,text='⟳  Erneut verbinden',command=self.start_connect); self.retry.pack(fill='x'); ttk.Label(right,text='Status aktualisiert automatisch.\n\nIm LAN wird Render nicht benötigt.\nBei externen Netzwerken wird der Relay verwendet.',style='Sub.TLabel',wraplength=190).pack(anchor='w',pady=(13,0))
        self.root.protocol('WM_DELETE_WINDOW',self.close); self.root.after(200,self.poll); self.root.after(60000,self.auto_reconnect_check); self.start_connect()

    def set_status(self,text): self.uiq.put(('status',text))
    def start_connect(self, automatic=False):
        if not self.running or self.connected or self.connecting:
            return
        self.connecting=True
        self.retry.configure(state='disabled')
        if automatic:
            self.status.configure(text='Automatische Serversuche: Prüfe LAN und anschließend das konfigurierte Render-Relay …')
        else:
            self.status.configure(text='Suche den Server und prüfe die Verbindung …')
        threading.Thread(target=self.connect_worker,daemon=True).start()

    def auto_reconnect_check(self):
        # If disconnected, perform a fresh LAN discovery and then try the configured relay.
        # The timer runs independently of connection attempts, but the guards prevent overlap.
        if self.running and not self.connected and not self.connecting:
            self.start_connect(automatic=True)
        if self.running:
            self.root.after(60000,self.auto_reconnect_check)

    def connect_worker(self):
        """Prefer direct LAN; use the Render relay only when LAN discovery/connect fails."""
        sock = None
        file = None
        host = None
        local_error = None
        try:
            # First try the existing direct LAN path. This keeps same-network traffic
            # off Render and avoids needing an Internet connection on the LAN.
            server = discover_server()
            if server:
                lan_host, lan_port = server
                try:
                    sock = socket.create_connection((lan_host, lan_port), timeout=5)
                    sock.settimeout(OFFLINE_TIMEOUT)
                    file = sock.makefile('rwb')
                    host = f'LAN ({lan_host})'
                except Exception as exc:
                    local_error = exc
                    try:
                        if sock: sock.close()
                    except Exception: pass
                    sock = None
                    file = None
            else:
                local_error = ConnectionError('Kein LAN-Server gefunden')

            # Render is only used as a fallback when no reachable LAN server exists.
            if sock is None:
                cfg_path = os.path.join(BASE, 'relay_config.json')
                cfg = {}
                try:
                    with open(cfg_path, 'r', encoding='utf-8') as handle:
                        cfg = json.load(handle)
                except Exception:
                    cfg = {}
                if not cfg.get('enabled'):
                    raise ConnectionError(f'Kein LAN-Server erreichbar und Render-Relay ist deaktiviert. LAN-Fehler: {local_error}')
                import websocket
                relay_url = str(cfg.get('relay_url', '')).strip()
                room = str(cfg.get('room_id', '')).strip()
                token = (os.environ.get(cfg.get('relay_token_env', 'CORE_NEXUS_RELAY_TOKEN')) or cfg.get('relay_token') or '').strip()
                if not relay_url.startswith('wss://') or not room or not token or 'PASTE_' in token:
                    raise ConnectionError(f'Kein LAN-Server erreichbar; die Render-Relay-Konfiguration ist unvollständig. LAN-Fehler: {local_error}')
                # Use the certifi CA bundle explicitly. This keeps TLS certificate
                # verification enabled while avoiding missing/outdated Windows CA stores.
                try:
                    import certifi
                except ImportError as exc:
                    raise ConnectionError(
                        'Das Paket certifi fehlt. Bitte setup.bat ausführen, damit die '
                        'TLS-Zertifikate installiert werden.'
                    ) from exc

                ws = websocket.create_connection(
                    relay_url,
                    timeout=15,
                    header=[f'Authorization: Bearer {token}', 'X-Core-Role: agent', f'X-Core-Room: {room}'],
                    origin=relay_url.split('/ws')[0],
                    sslopt={
                        'ca_certs': certifi.where(),
                        'cert_reqs': ssl.CERT_REQUIRED
                    }
                )
                sock = RelayAgentSocket(ws, self.device_id)
                sock.settimeout(OFFLINE_TIMEOUT)
                file = sock
                host = 'Render-Relay'

            self.uiq.put(('transport', host))
            send_json(sock, {'type':'hello', 'device_id':self.device_id, 'name':platform.node() or 'Windows-PC', 'os':platform.platform(), 'boot_id':self._boot_id()})
            reply = recv_json(file)
            if not reply.get('ok'):
                raise ConnectionError('Der Server hat die Registrierung abgelehnt.')
            self.sock = sock
            self.file = file
            self.connected = True
            self.connecting = False
            # Local consent is requested once per installation unless the user explicitly revoked it.
            consent_file = os.path.join(BASE, 'consent.json')
            consent = None
            try:
                with open(consent_file, 'r', encoding='utf-8') as f:
                    consent = json.load(f).get('accepted')
            except Exception:
                pass
            if consent is None:
                self.uiq.put(('consent', None))
                return
            send_json(sock, {'type':'consent', 'accepted':bool(consent)})
            state = recv_json(file)
            if not consent:
                raise PermissionError('Lokale Zustimmung wurde verweigert. Der Agent bleibt geschlossen.')
            if not state.get('approved'):
                if state.get('server_approved') and not state.get('consent'):
                    self.set_status('Serverfreigabe vorhanden, aber die lokale Zustimmung fehlt. Bitte Zustimmung am Ziel-PC erneut erteilen.')
                else:
                    self.set_status('Lokal verbunden. Serverfreigabe fehlt oder wurde widerrufen. Öffne im Server-Dashboard die Geräteverwaltung und gib dieses Gerät frei.')
            else:
                self.uiq.put(('transport', host)); self.set_status(f'Verbunden über {host}. Gerät ist freigegeben; Fernsteuerung startet nur in einer ausdrücklich geöffneten Sitzung.')
            threading.Thread(target=self.heartbeat_loop, daemon=True).start()
        except Exception as e:
            self.connected = False
            self.connecting = False
            if self.sock is sock:
                self.sock = None
                self.file = None
            try:
                if sock: sock.close()
            except Exception:
                pass
            self.set_status(f'Verbindung fehlgeschlagen: {e}\nDer Agent sucht automatisch jede Minute erneut nach einem Server.')
            self.uiq.put(('offline', str(e)))

    @staticmethod
    def _boot_id():
        # A best-effort boot marker; no system changes are made.
        try: return str(int(time.time()-time.monotonic()))
        except Exception: return 'unknown'

    def heartbeat_loop(self):
        # Frequent small heartbeats keep input latency low. Screenshots are sent
        # less often and compressed cheaply so a slow uplink is not saturated.
        while self.running and self.sock:
            try:
                packet={'type':'heartbeat'}
                now=time.monotonic()
                if self.remote_active and REMOTE_LIBS and now-self._last_frame_time >= REMOTE_FRAME_INTERVAL:
                    try:
                        packet['frame']=self.capture_frame()
                        self._last_frame_time=now
                    except Exception as capture_error:
                        self.set_status(f'Bildschirm konnte nicht erfasst werden: {capture_error}')
                send_json(self.sock,packet)
                reply=recv_json(self.file)
                if reply.get('close_agent'):
                    self.set_status('Der Server hat das Schließen des Agenten angefordert.')
                    self.uiq.put(('close',None)); return
                approved=bool(reply.get('approved'))
                server_approved=bool(reply.get('server_approved'))
                consent=bool(reply.get('consent'))
                self.remote_active=bool(reply.get('remote_active')) and approved and REMOTE_LIBS
                for command in reply.get('commands',[]):
                    try:
                        self.perform_input(command)
                        self.input_count += 1
                    except Exception as command_error:
                        self.set_status(f'Eingabe konnte nicht ausgeführt werden: {command_error}')
                if approved != self.last_approved or server_approved != self.last_server_approved or consent != self.last_consent:
                    if approved:
                        self.set_status('Verbunden und freigegeben. Keine Fernsteuerung aktiv, bis eine Sitzung am Server geöffnet wird.')
                    elif not consent:
                        self.set_status('Lokale Zustimmung fehlt oder wurde widerrufen. Fernzugriff bleibt gesperrt.')
                    else:
                        self.set_status('Agent läuft und ist mit dem Server verbunden. Serverfreigabe fehlt oder wurde widerrufen; Fernzugriff bleibt gesperrt.')
                    self.last_approved=approved; self.last_server_approved=server_approved; self.last_consent=consent
                time.sleep(REMOTE_HEARTBEAT_INTERVAL if self.remote_active else 1.0)
            except Exception as e:
                self.remote_active=False
                self.set_status(f'Verbindung zum Server verloren: {e}\nDer Agent bleibt geöffnet. Prüfe das Netzwerk und klicke auf „Erneut verbinden“.')
                failed_sock=self.sock
                self.connected=False
                self.sock=None
                self.file=None
                try:
                    if failed_sock: failed_sock.close()
                except Exception:
                    pass
                self.uiq.put(('offline',str(e))); return

    def capture_frame(self):
        # Reuse one MSS capture handle and avoid expensive JPEG optimize passes.
        if self._mss_capture is None:
            self._mss_capture = mss.mss()
        monitor=self._mss_capture.monitors[1]
        shot=self._mss_capture.grab(monitor)
        native_w,native_h=shot.size
        image=Image.frombytes('RGB',shot.size,shot.rgb)
        image.thumbnail(REMOTE_FRAME_MAX_SIZE)
        self.frame_native_size=(native_w,native_h)
        self.frame_encoded_size=image.size
        import io
        buf=io.BytesIO()
        image.save(buf,format='JPEG',quality=REMOTE_JPEG_QUALITY,optimize=False,progressive=False)
        return base64.b64encode(buf.getvalue()).decode('ascii')

    def _input_position(self, command):
        x=int(command.get('x',0)); y=int(command.get('y',0))
        encoded=self.frame_encoded_size; native=self.frame_native_size
        if encoded and native and encoded[0]>0 and encoded[1]>0:
            x=round(x*native[0]/encoded[0]); y=round(y*native[1]/encoded[1])
        if native:
            x=max(0,min(native[0]-1,x)); y=max(0,min(native[1]-1,y))
        return (x,y)

    def perform_input(self, command):
        # Input is accepted only during an explicitly active, approved session.
        if not REMOTE_LIBS or not self.remote_active: return
        if self.remote_mouse is None or self.remote_keyboard is None:
            raise RuntimeError('Maus-/Tastaturcontroller ist nicht initialisiert. Bitte Agent neu installieren.')
        kind=command.get('kind')
        if kind=='move': self.remote_mouse.position=self._input_position(command)
        elif kind=='click':
            self.remote_mouse.position=self._input_position(command)
            btn=Button.right if command.get('button')=='right' else Button.left
            self.remote_mouse.click(btn, 1)
        elif kind=='scroll':
            self.remote_mouse.position=self._input_position(command)
            self.remote_mouse.scroll(0, int(command.get('dy',0)))
        elif kind=='key':
            name=str(command.get('key',''))[:40]
            keymap={'enter':Key.enter,'tab':Key.tab,'esc':Key.esc,'backspace':Key.backspace,'delete':Key.delete,'space':Key.space,'up':Key.up,'down':Key.down,'left':Key.left,'right':Key.right,'shift':Key.shift,'ctrl':Key.ctrl,'alt':Key.alt,'win':Key.cmd,'f1':Key.f1,'f2':Key.f2,'f3':Key.f3,'f4':Key.f4,'f5':Key.f5,'f6':Key.f6,'f7':Key.f7,'f8':Key.f8,'f9':Key.f9,'f10':Key.f10,'f11':Key.f11,'f12':Key.f12}
            key=keymap.get(name.lower(), name if len(name)==1 else None)
            if key is not None:
                action=command.get('action','press')
                if action=='down': self.remote_keyboard.press(key)
                elif action=='up': self.remote_keyboard.release(key)
                else: self.remote_keyboard.press(key); self.remote_keyboard.release(key)
        elif kind=='text':
            self.remote_keyboard.type(str(command.get('text',''))[:200])

    def ask_consent(self):
        answer=messagebox.askyesno(APP,'CORE Nexus wurde auf diesem PC erkannt.\n\nErlaubst du diesem Gerät, nach Freigabe im Server-Dashboard für Fernansichten und Steuerung verfügbar zu sein? Du kannst die Zustimmung später durch Löschen von Agent/consent.json und erneute Einrichtung zurücksetzen.',parent=self.root)
        try:
            with open(os.path.join(BASE,'consent.json'),'w',encoding='utf-8') as f: json.dump({'accepted':answer},f)
            if self.sock:
                send_json(self.sock,{'type':'consent','accepted':answer}); reply=recv_json(self.file)
                if not answer: self.set_status('Du hast die Zustimmung verweigert. Agent bleibt geschlossen.'); self.close_after(1500); return
                if reply.get('approved'):
                    self.set_status('Zustimmung gespeichert. Gerät ist freigegeben und verbunden.')
                else:
                    self.set_status('Zustimmung gespeichert. Bitte gib dieses Gerät zusätzlich im Server-Dashboard frei.')
                threading.Thread(target=self.heartbeat_loop,daemon=True).start()
        except Exception as e: self.set_status(f'Zustimmung konnte nicht übermittelt werden: {e}')

    def poll(self):
        try:
            while True:
                kind,value=self.uiq.get_nowait()
                if kind=='status':
                    self.status.configure(text=value)
                    low=value.lower()
                    if 'verbunden' in low or 'zustimmung gespeichert' in low:
                        self.badge.configure(text='●  CONNECTED',foreground='#47e0a0')
                    elif 'fehlgeschlagen' in low or 'nicht erreichbar' in low or 'fehler' in low:
                        self.badge.configure(text='●  OFFLINE',foreground='#ff7285')
                    else:
                        self.badge.configure(text='●  CONNECTING',foreground='#ffca70')
                elif kind=='transport':
                    self.connection_mode=str(value)
                    self.transport.configure(text=('DIRECT LAN' if 'LAN (' in str(value) else 'RENDER RELAY'))
                elif kind=='consent': self.root.after(100,self.ask_consent)
                elif kind=='offline': self.retry.configure(state='normal'); self.badge.configure(text='●  OFFLINE',foreground='#ff7285'); self.status.configure(text=f'Verbindung fehlgeschlagen: {value}\nAutomatische neue Suche in spätestens 60 Sekunden; du kannst auch manuell erneut verbinden.')
                elif kind=='close': self.close_after(500)
        except queue.Empty: pass
        if self.running: self.root.after(250,self.poll)

    def close_after(self,ms): self.root.after(ms,self.close)
    def close(self):
        self.running=False
        try:
            if self.sock: self.sock.close()
        except OSError: pass
        try:
            if self._mss_capture is not None:
                self._mss_capture.close()
                self._mss_capture = None
        except Exception: pass
        try: self.root.destroy()
        except tk.TclError: pass

if __name__=='__main__': Agent().root.mainloop()
