﻿@echo off
setlocal
chcp 65001 >nul
cd /d "%~dp0"
title CORE Nexus Agent - TLS-Reparatur
echo ============================================
echo       CORE Nexus Agent - TLS-Reparatur
echo ============================================
echo.
py -V:3.15 -m pip install --upgrade --disable-pip-version-check certifi websocket-client
if errorlevel 1 (
  echo.
  echo FEHLER: Pakete konnten nicht installiert werden.
  echo Pruefe Internetzugang und Python 3.15.
  pause
  exit /b 1
)
py -V:3.15 -c "import certifi; print('CA-Bundle:', certifi.where())"
if errorlevel 1 (
  echo FEHLER: certifi konnte nicht geladen werden.
  pause
  exit /b 1
)
echo.
echo TLS-Zertifikatsbundle erfolgreich eingerichtet.
echo Starte jetzt start.bat erneut.
pause
