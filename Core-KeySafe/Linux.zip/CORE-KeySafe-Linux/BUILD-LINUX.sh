#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT"

if ! command -v python3 >/dev/null 2>&1; then
  echo "FEHLER: Python 3 wurde nicht gefunden. Bitte Python 3.11 oder 3.12 installieren."
  exit 1
fi
PY_MINOR="$(python3 -c 'import sys; print(f"{sys.version_info.major}.{sys.version_info.minor}")')"
if [[ "$PY_MINOR" != "3.11" && "$PY_MINOR" != "3.12" && "$PY_MINOR" != "3.13" ]]; then
  echo "HINWEIS: Gefunden wurde Python $PY_MINOR. Empfohlen sind Python 3.11 oder 3.12."
fi

python3 -m venv .venv
# shellcheck disable=SC1091
source .venv/bin/activate
python -m pip install --upgrade pip wheel
python -m pip install -r desktop/requirements.txt pyinstaller

if grep -q 'REPLACE-WITH-YOUR-RENDER-SERVICE\|REPLACE_WITH_ED25519_PUBLIC_KEY' desktop/core_keysafe/config.py; then
  echo
  echo "WARNUNG: desktop/core_keysafe/config.py enthält noch Platzhalter."
  echo "Trage vor einer nutzbaren Veröffentlichung Render-URL und öffentlichen Ed25519-Schlüssel ein."
  echo
fi

rm -rf build dist
pyinstaller --noconfirm --clean --windowed --onedir \
  --name "CORE KeySafe" \
  --paths desktop \
  --collect-all argon2 \
  --collect-all PySide6 \
  desktop/main.py

mkdir -p dist/"CORE KeySafe"/Import
cat > dist/"CORE KeySafe"/README-FIRST-START.txt <<'TXT'
CORE KeySafe – erster Start

1. Prüfe, ob Render-URL und öffentlicher Signaturschlüssel vor dem Build konfiguriert wurden.
2. Starte die Anwendung mit ./"CORE KeySafe".
3. Die App benötigt für Lizenzprüfung und Aktivierung eine Internetverbindung.
4. Vault-Dateien gehören nicht in GitHub oder in öffentliche Ordner.
5. Der private Lizenzsignaturschlüssel gehört ausschließlich in die geheimen Umgebungsvariablen des Lizenzservers.
TXT
chmod +x "dist/CORE KeySafe/CORE KeySafe"

cat > dist/"CORE KeySafe.desktop" <<EOF2
[Desktop Entry]
Type=Application
Name=CORE KeySafe
Comment=Lokaler verschlüsselter Passwortsafe
Exec="$ROOT/dist/CORE KeySafe/CORE KeySafe"
Path="$ROOT/dist/CORE KeySafe"
Terminal=false
Categories=Utility;Security;
EOF2
chmod 755 dist/"CORE KeySafe.desktop"

echo
echo "Build abgeschlossen: $ROOT/dist/CORE KeySafe/"
echo "Zum Starten: ./dist/\"CORE KeySafe\"/\"CORE KeySafe\""
echo "Optionaler Desktop-Starter: dist/CORE-KeySafe.desktop"
