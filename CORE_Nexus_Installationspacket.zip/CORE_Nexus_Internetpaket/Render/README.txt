CORE Nexus – Render-Dateien

Die render.yaml ist die Bereitstellungskonfiguration für Render. Eine identische Datei liegt im GitHub-Ordner, damit Render sie beim Blueprint-Deploy automatisch findet.

Render-Bereitstellung:
1. Inhalte des Ordners GitHub in ein GitHub-Repository hochladen.
2. In Render: New + -> Blueprint -> das Repository auswählen.
3. Render erzeugt CORE_NEXUS_RELAY_TOKEN als geheime Umgebungsvariable. Den Token nicht in GitHub veröffentlichen.
4. Nach dem Deploy /health aufrufen; erwartet wird {"status":"ok", ...}.

HINWEIS: Der Relay-Dienst ist vorbereitet, die mitgelieferten bestehenden Windows-Programme sprechen aktuell noch ihr altes LAN-Protokoll. Die Programme müssen noch auf den WebSocket-Relay umgestellt werden. Bis dahin funktioniert die Internetweiterleitung noch nicht vollständig. Diese Datei allein kann das nicht aktivieren.
