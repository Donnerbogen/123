# CORE Nexus – Complete System Upgrade

Native Windows LAN dashboard and separately deployable Agent.

## Included improvements
- Overview cards for registered, online, approved and pending devices
- Auto-refresh every five seconds and device status filters
- Clearer distinction between local consent and server approval
- CSV export of recent audit records
- SQLite online backup to `Server/backups`
- System and maintenance page
- Improved agent status messages

## Update without losing data
1. Stop the server.
2. Back up `Server/data/`.
3. Replace the application files with the files in this package.
4. Restore the previous `Server/data/` directory.
5. Start `Server/start.bat` and sign in as Owner.

## Device approval
A device needs both local user consent and server-side approval. If the agent says server approval is missing, select the device in the server dashboard and click **Gerät freigeben**.

## Security
LAN-only development version. Traffic is not TLS-encrypted. Do not configure router port forwarding; use only on a trusted private LAN. Remote control is limited to explicitly approved devices and a visible session. Windows secure desktop is not bypassed.

## Validation
Python syntax and archive integrity were checked. Full Windows runtime testing was not performed.
