﻿"""CORE Nexus LAN agent. Run with: python agent.py
Requires explicit local user consent and server-side device approval.
"""
from __future__ import annotations
import json, os, platform, queue, socket, threading, time, uuid
import tkinter as tk
from tkinter import ttk, messagebox
import base64
try:
    import mss
    from PIL import Image
    from pynput.mouse import Controller as MouseController, Button
    from pynput.keyboard import Controller as KeyboardController, Key
    REMOTE_LIBS = True
except Exception:
    REMOTE_LIBS = False

APP='CORE Nexus Agent'; DISCOVERY_PORT=47622; DEFAULT_PORT=47621
BASE=os.path.dirname(os.path.abspath(__file__)); ID_FILE=os.path.join(BASE,'device_id.json')
HEARTBEAT=5; OFFLINE_TIMEOUT=18

def get_device_id():
    try:
        with open(ID_FILE,'r',encoding='utf-8') as f: return json.load(f)['device_id']
    except Exception:
        did=str(uuid.uuid4())
        try:
            with open(ID_FILE,'w',encoding='utf-8') as f: json.dump({'device_id':did},f)
        except OSError: pass
        return did

def discover_server(timeout=3):
    sock=socket.socket(socket.AF_INET,socket.SOCK_DGRAM); sock.setsockopt(socket.SOL_SOCKET,socket.SO_BROADCAST,1); sock.settimeout(timeout)
    try:
        sock.sendto(b'CORE_NEXUS_DISCOVER_V1',('<broadcast>',DISCOVERY_PORT))
        end=time.time()+timeout
        while time.time()<end:
            try: data,addr=sock.recvfrom(4096)
            except socket.timeout: break
            try:
                item=json.loads(data.decode('utf-8'))
                if item.get('app')=='CORE Nexus' and item.get('port'): return item['host'],int(item['port'])
            except Exception: continue
    finally: sock.close()
    return None

def send_json(sock,obj):
    sock.sendall((json.dumps(obj,separators=(',',':'))+'\n').encode('utf-8'))

def recv_json(file):
    line=file.readline()
    if not line: raise ConnectionError('Server hat die Verbindung beendet.')
    if len(line)>8_000_000: raise ValueError('Antwort des Servers ist zu groß.')
    return json.loads(line.decode('utf-8'))

class Agent:
    def __init__(self):
        self.device_id=get_device_id(); self.sock=None; self.file=None; self.running=True; self.uiq=queue.Queue(); self.remote_active=False; self.remote_mouse=MouseController() if REMOTE_LIBS else None; self.remote_keyboard=KeyboardController() if REMOTE_LIBS else None; self.remote_last_frame=None; self.last_approved=None; self.last_server_approved=None; self.root=tk.Tk(); self.root.title(APP); self.root.geometry('480x270'); self.root.configure(bg='#080e1b'); self.root.resizable(False,False)
        style=ttk.Style(); style.theme_use('clam'); style.configure('.',background='#0d1728',foreground='#eaf2ff',fieldbackground='#111f34'); style.configure('TFrame',background='#0d1728'); style.configure('TLabel',background='#0d1728',foreground='#eaf2ff',font=('Segoe UI',10)); style.configure('Title.TLabel',font=('Segoe UI',18,'bold'),foreground='#58baff'); style.configure('TButton',background='#183454',foreground='white',padding=8)
        box=ttk.Frame(self.root,padding=22); box.pack(fill='both',expand=True); ttk.Label(box,text='CORE NEXUS',style='Title.TLabel').pack(anchor='w'); ttk.Label(box,text='SICHERER LAN-AGENT',foreground='#91a8c6').pack(anchor='w',pady=(0,15))
        self.status=ttk.Label(box,text='Suche den CORE Nexus Server im lokalen Netzwerk …',wraplength=420); self.status.pack(anchor='w',pady=6)
        self.retry=ttk.Button(box,text='Erneut verbinden',command=self.start_connect); self.retry.pack(anchor='w',pady=8); ttk.Label(box,text=('Fernzugriff nur nach lokaler Zustimmung und Serverfreigabe.' if REMOTE_LIBS else 'Fernsteuerungs-Abhängigkeiten fehlen. Bitte install.bat erneut ausführen.' ),foreground='#91a8c6',wraplength=420).pack(anchor='w',pady=(8,0))
        self.root.protocol('WM_DELETE_WINDOW',self.close); self.root.after(200,self.poll); self.start_connect()

    def set_status(self,text): self.uiq.put(('status',text))
    def start_connect(self):
        self.retry.configure(state='disabled'); self.status.configure(text='Suche den Server und prüfe die Verbindung …'); threading.Thread(target=self.connect_worker,daemon=True).start()

    def connect_worker(self):
        try:
            server=discover_server()
            if not server: raise ConnectionError('CORE Nexus Server ist im lokalen Netzwerk nicht erreichbar.')
            host,port=server; sock=socket.create_connection((host,port),timeout=5); sock.settimeout(OFFLINE_TIMEOUT); file=sock.makefile('rwb')
            send_json(sock,{'type':'hello','device_id':self.device_id,'name':platform.node() or 'Windows-PC','os':platform.platform(),'boot_id':self._boot_id()})
            reply=recv_json(file)
            if not reply.get('ok'): raise ConnectionError('Der Server hat die Registrierung abgelehnt.')
            self.sock=sock; self.file=file
            # Local consent is requested once per installation unless the user explicitly revoked it.
            consent_file=os.path.join(BASE,'consent.json')
            consent=None
            try:
                with open(consent_file,'r',encoding='utf-8') as f: consent=json.load(f).get('accepted')
            except Exception: pass
            if consent is None:
                self.uiq.put(('consent',None)); return
            send_json(sock,{'type':'consent','accepted':bool(consent)}); state=recv_json(file)
            if not consent: raise PermissionError('Lokale Zustimmung wurde verweigert. Der Agent bleibt geschlossen.')
            if not state.get('approved'):
                if state.get('server_approved') and not state.get('consent'):
                    self.set_status('Serverfreigabe vorhanden, aber die lokale Zustimmung fehlt. Bitte Zustimmung am Ziel-PC erneut erteilen.')
                else:
                    self.set_status('Lokale Zustimmung gespeichert. Serverfreigabe fehlt oder wurde widerrufen. Öffne im Server-Dashboard die Geräteverwaltung und gib dieses Gerät frei.')
            else: self.set_status(f'Verbunden mit {host}. Gerät ist freigegeben; Fernsteuerung startet nur in einer ausdrücklich geöffneten Sitzung.')
            threading.Thread(target=self.heartbeat_loop,daemon=True).start()
        except Exception as e:
            self.set_status(f'Server nicht verfügbar: {e}\nDer Agent bleibt ohne Serververbindung deaktiviert.'); self.uiq.put(('offline',str(e)))

    @staticmethod
    def _boot_id():
        # A best-effort boot marker; no system changes are made.
        try: return str(int(time.time()-time.monotonic()))
        except Exception: return 'unknown'

    def heartbeat_loop(self):
        while self.running and self.sock:
            try:
                packet={'type':'heartbeat'}
                if self.remote_active and REMOTE_LIBS:
                    try: packet['frame']=self.capture_frame()
                    except Exception as capture_error:
                        self.set_status(f'Bildschirm konnte nicht erfasst werden: {capture_error}')
                send_json(self.sock,packet)
                reply=recv_json(self.file)
                if reply.get('close_agent'):
                    self.set_status('Der Server hat das Schließen des Agenten angefordert.')
                    self.uiq.put(('close',None)); return
                approved=bool(reply.get('approved'))
                server_approved=bool(reply.get('server_approved'))
                consent=bool(reply.get('consent'))
                self.remote_active=bool(reply.get('remote_active')) and approved and REMOTE_LIBS
                for command in reply.get('commands',[]):
                    try: self.perform_input(command)
                    except Exception as command_error:
                        self.set_status(f'Eingabe konnte nicht ausgeführt werden: {command_error}')
                if approved != self.last_approved or server_approved != self.last_server_approved or consent != self.last_consent:
                    if approved:
                        self.set_status('Verbunden und freigegeben. Keine Fernsteuerung aktiv, bis eine Sitzung am Server geöffnet wird.')
                    elif not consent:
                        self.set_status('Lokale Zustimmung fehlt oder wurde widerrufen. Fernzugriff bleibt gesperrt.')
                    else:
                        self.set_status('Agent läuft und ist mit dem Server verbunden. Serverfreigabe fehlt oder wurde widerrufen; Fernzugriff bleibt gesperrt.')
                    self.last_approved=approved; self.last_server_approved=server_approved; self.last_consent=consent
                time.sleep(0.16 if self.remote_active else HEARTBEAT)
            except Exception as e:
                self.remote_active=False
                self.set_status(f'Verbindung zum Server verloren: {e}\nDer Agent bleibt geöffnet. Prüfe das Netzwerk und klicke auf „Erneut verbinden“.')
                self.uiq.put(('offline',str(e))); return

    def capture_frame(self):
        # Compressed JPEG frame; capture only while an approved remote session is active.
        with mss.mss() as cap:
            monitor=cap.monitors[1]
            shot=cap.grab(monitor)
            image=Image.frombytes('RGB', shot.size, shot.rgb)
            image.thumbnail((1280, 720))
            import io
            buf=io.BytesIO(); image.save(buf, format='JPEG', quality=45, optimize=True)
            return base64.b64encode(buf.getvalue()).decode('ascii')

    def perform_input(self, command):
        if not REMOTE_LIBS or not self.remote_active: return
        kind=command.get('kind')
        if kind=='move': self.remote_mouse.position=(int(command.get('x',0)), int(command.get('y',0)))
        elif kind=='click':
            self.remote_mouse.position=(int(command.get('x',0)), int(command.get('y',0)))
            btn=Button.right if command.get('button')=='right' else Button.left
            self.remote_mouse.click(btn, 1)
        elif kind=='scroll':
            self.remote_mouse.position=(int(command.get('x',0)), int(command.get('y',0)))
            self.remote_mouse.scroll(0, int(command.get('dy',0)))
        elif kind=='key':
            name=str(command.get('key',''))[:40]
            keymap={'enter':Key.enter,'tab':Key.tab,'esc':Key.esc,'backspace':Key.backspace,'delete':Key.delete,'space':Key.space,'up':Key.up,'down':Key.down,'left':Key.left,'right':Key.right,'shift':Key.shift,'ctrl':Key.ctrl,'alt':Key.alt,'win':Key.cmd,'f1':Key.f1,'f2':Key.f2,'f3':Key.f3,'f4':Key.f4,'f5':Key.f5,'f6':Key.f6,'f7':Key.f7,'f8':Key.f8,'f9':Key.f9,'f10':Key.f10,'f11':Key.f11,'f12':Key.f12}
            key=keymap.get(name.lower(), name if len(name)==1 else None)
            if key is not None:
                action=command.get('action','press')
                if action=='down': self.remote_keyboard.press(key)
                elif action=='up': self.remote_keyboard.release(key)
                else: self.remote_keyboard.press(key); self.remote_keyboard.release(key)
        elif kind=='text':
            self.remote_keyboard.type(str(command.get('text',''))[:200])

    def ask_consent(self):
        answer=messagebox.askyesno(APP,'CORE Nexus wurde auf diesem PC erkannt.\n\nErlaubst du diesem Gerät, nach Freigabe im Server-Dashboard für Fernansichten und Steuerung verfügbar zu sein? Du kannst die Zustimmung später durch Löschen von Agent/consent.json und erneute Einrichtung zurücksetzen.',parent=self.root)
        try:
            with open(os.path.join(BASE,'consent.json'),'w',encoding='utf-8') as f: json.dump({'accepted':answer},f)
            if self.sock:
                send_json(self.sock,{'type':'consent','accepted':answer}); reply=recv_json(self.file)
                if not answer: self.set_status('Du hast die Zustimmung verweigert. Agent bleibt geschlossen.'); self.close_after(1500); return
                if state.get('approved'):
                    self.set_status('Zustimmung gespeichert. Gerät ist freigegeben und verbunden.')
                else:
                    self.set_status('Zustimmung gespeichert. Bitte gib dieses Gerät zusätzlich im Server-Dashboard frei.')
                threading.Thread(target=self.heartbeat_loop,daemon=True).start()
        except Exception as e: self.set_status(f'Zustimmung konnte nicht übermittelt werden: {e}')

    def poll(self):
        try:
            while True:
                kind,value=self.uiq.get_nowait()
                if kind=='status': self.status.configure(text=value)
                elif kind=='consent': self.root.after(100,self.ask_consent)
                elif kind=='offline': self.retry.configure(state='normal'); messagebox.showwarning(APP,'CORE Nexus Server ist nicht erreichbar. Der Agent bleibt deaktiviert.\n\nPrüfe, ob Server-PC und dieser PC im selben lokalen Netzwerk sind und die Windows-Firewall CORE Nexus erlaubt.',parent=self.root)
                elif kind=='close': self.close_after(500)
        except queue.Empty: pass
        if self.running: self.root.after(250,self.poll)

    def close_after(self,ms): self.root.after(ms,self.close)
    def close(self):
        self.running=False
        try:
            if self.sock: self.sock.close()
        except OSError: pass
        try: self.root.destroy()
        except tk.TclError: pass

if __name__=='__main__': Agent().root.mainloop()
