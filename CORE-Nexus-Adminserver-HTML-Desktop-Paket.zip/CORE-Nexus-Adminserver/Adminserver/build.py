from pathlib import Path
import subprocess, sys, shutil, os
ROOT=Path(__file__).resolve().parent
NAME="CORE-Nexus-Adminserver"
ENTRY=ROOT/"launcher.py"
DIST=ROOT/"release"/NAME

def run(cmd):
    print("\n>"," ".join(map(str,cmd)),flush=True)
    subprocess.check_call(list(map(str,cmd)),cwd=ROOT)

def main():
    run([sys.executable,"-m","pip","install","--upgrade","pip","pyinstaller"])
    run([sys.executable,"-m","pip","install","-r",str(ROOT/"requirements.txt")])
    if DIST.exists(): shutil.rmtree(DIST)
    cmd=[sys.executable,"-m","PyInstaller","--noconfirm","--clean","--onedir","--windowed","--name",NAME,
         "--distpath",str(ROOT/"release"),"--workpath",str(ROOT/"build"),"--specpath",str(ROOT/"spec"),
         "--collect-all","webview",
         "--add-data",f"{ROOT/'ui'}:ui",
         "--add-data",f"{ROOT/'CORE-UI'}:CORE-UI",
         "--add-data",f"{ROOT/'legacy_adminserver.py'}:.",str(ENTRY)]
    run(cmd)
    (DIST/"data").mkdir(parents=True,exist_ok=True)
    if (ROOT / "connection_config.json").exists() and not (DIST / "data" / "connection_config.json").exists(): shutil.copy2(ROOT / "connection_config.json", DIST / "data" / "connection_config.json")
    server_src = ROOT.parent / "Server"
    server_dst = DIST / "Server"
    if server_src.exists():
        if server_dst.exists(): shutil.rmtree(server_dst)
        shutil.copytree(server_src, server_dst, ignore=shutil.ignore_patterns("__pycache__", "*.pyc", "data", "relay_config.json", "admin_config.json"))
    print("Build fertig:",DIST)
    print("Den gesamten Release-Ordner kopieren. data/ bei Updates beibehalten.")
if __name__=="__main__": main()
