CORE NEXUS SERVER – INTERNET-RELAY
1. Server-Ordner auf den Server-PC kopieren. Behalte Server/data bei Updates.
2. In relay_config.json relay_url, relay_token und room_id setzen; enabled muss true sein. Gleiche Werte wie im Agent verwenden.
3. install.bat ausführen, dann start.bat. Der Server verbindet sich ausgehend zu Render; keine Router-Portfreigabe erforderlich.
4. Agenten müssen lokale Zustimmung erteilen und im Dashboard freigegeben werden. Fernsteuerung nur in ausdrücklich geöffneter Sitzung.
5. Das Token nicht in GitHub hochladen.
6. Abmelden sperrt nur das Dashboard und zeigt wieder den Login. TCP-Listener, LAN-Erkennung, Render-Relay und Agent-Verbindungen laufen weiter, solange das Serverprogramm nicht beendet wird.
7. Nach der Abmeldung sind Dashboard-Funktionen gesperrt. Zum Verwalten von Geräten oder zum Fernsteuern erneut anmelden.
