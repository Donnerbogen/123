# CORE KeySafe – Windows-Paket

## Enthalten
- `desktop/`: App-Quellcode und Python-Abhängigkeiten
- `BUILD-WINDOWS.bat`: erstellt auf einem Windows-PC einen PyInstaller-Build

## Vor dem Build
1. Python 3.11 oder 3.12 (64-bit) installieren und beim Setup „Add Python to PATH“ aktivieren.
2. In `desktop/core_keysafe/config.py` die eigene Render-URL und den öffentlichen Ed25519-Schlüssel eintragen.
3. `BUILD-WINDOWS.bat` per Doppelklick starten.
4. Ausgabe befindet sich in `dist\CORE KeySafe\`. Zum Testen `CORE KeySafe.exe` daraus starten.

## Hinweise
- Diese ZIP enthält keinen vorgefertigten `.exe`, weil ein verlässlicher Windows-Build auf einem Windows-System erzeugt und getestet werden muss.
- Für eine signierte Installation/MSI, automatische Updates und eine saubere Deinstallation ist später ein eigener Installer nötig.
- Niemals den privaten Lizenzsignaturschlüssel in diese App kopieren. Nur den öffentlichen Schlüssel verwenden.
- Zum lokalen Entwickeln kann die App aus `desktop\main.py` gestartet werden; `KEYSAFE_DEV_MODE=1` darf nicht in eine veröffentlichte Version gelangen.

## Benutzerhandbuch
Das ausführliche, bewusst einfach gehaltene Handbuch liegt in `HANDBUCH.md` und ist nach dem Start auch über die Schaltfläche **Handbuch** in der Anwendung erreichbar.
