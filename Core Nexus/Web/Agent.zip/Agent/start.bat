@echo off
setlocal EnableExtensions
chcp 65001 >nul
pushd "%~dp0" || (echo ERROR: Cannot open Agent folder.& pause & exit /b 1)
title CORE Nexus Agent
if not exist "%~dp0installed.flag" (
  echo CORE Nexus Agent has not been installed yet.
  echo Run setup.bat and choose option 1 first.
  pause
  exit /b 1
)
if not exist "%~dp0agent.py" (
  echo ERROR: agent.py was not found in %CD%.
  pause
  exit /b 1
)
where py >nul 2>&1
if not errorlevel 1 (
  py -3.15 -c "import sys; raise SystemExit(0 if sys.version_info[:3] == (3,15,0) else 1)"
  if errorlevel 1 (
    echo ERROR: Python 3.15.0 exactly is required. Other Python versions are not supported.
    pause
    exit /b 1
  )
  where pyw >nul 2>&1
  if errorlevel 1 (
    echo ERROR: pyw launcher was not found. Repair the Python 3.15.0 installation.
    pause
    exit /b 1
  )
  start "" /B pyw -3.15 "%~dp0agent.py"
  exit /b 0
)
echo ERROR: Python Launcher was not found. Install Python 3.15.0 exactly from https://www.python.org/downloads/release/python-3150/
pause
exit /b 1
