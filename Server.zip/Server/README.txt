CORE Nexus Server

1. setup.bat: Menue fuer Installation/Reparatur, Deinstallation und Autostart.
2. start.bat: Startet die bereits installierte Anwendung sofort.
3. Adminserver-Zugriff: admin_config.example.json wird bei der Installation bei Bedarf nach admin_config.json kopiert. Dort einen langen geheimen admin_token setzen und exakt denselben Token in der Adminserver-Konfiguration hinterlegen.
4. Adminserver-LAN-Port: TCP 47623. Falls Windows-Firewall eingehende Verbindungen blockiert, diesen Port nur im vertrauenswuerdigen Netzwerk freigeben.
5. Externe Verbindung: Server und Adminserver muessen dieselbe Render-Relay-URL, den Relay-Token und dieselbe Raum-ID verwenden.

setup.bat fragt vor jeder Aktion nach deiner Auswahl. Bei der Deinstallation kannst du lokale Daten behalten oder loeschen.

ADMINSERVER-AUTOMATISCHE ERKENNUNG
Wenn der Server im Adminserver automatisch erscheinen soll, muss er mit Render verbunden sein. Verwende auf allen Servern denselben geheimen admin_token in admin_config.json. Die room_id bleibt pro Serverraum eindeutig. Aktualisiere das Render-Relay mit der neuen GitHub/relay/main.py.

ZENTRALE SERVERERSTELLUNG
Wenn das Serverpaket vom angemeldeten CORE Nexus Root-Admin erstellt wurde, sind Raum-ID, Relay-Konfiguration, Service-Admin-Token und Owner-Benutzername bereits eingerichtet. Beim ersten Start wird der Owner aus einem Passwort-Hash in die lokale Datenbank übernommen; das Klartext-Passwort befindet sich nicht im Paket.

NEUE MENÜSTRUKTUR
Die Serveroberfläche besitzt jetzt eine linke Navigation mit getrennten Bereichen:
- Übersicht: Status, Kennzahlen und Schnellaktionen
- Geräte: Suche, Statusfilter, Freigaben, Mehrfachauswahl und Geräteverwaltung
- Fernsteuerung: Sitzung öffnen/beenden; das Zielgerät wird im Menü „Geräte“ ausgewählt
- Konten & Rechte: Benutzerkonten und Berechtigungen (nur mit passender Berechtigung)
- Aktivitätsprotokoll: Ereignisse anzeigen und CSV exportieren (nur mit passender Berechtigung)
- System & Wartung: lokale Informationen, Sicherungen und Diagnose
Die Menüaufteilung ändert weder die erforderlichen Zustimmungen noch die serverseitigen Rechteprüfungen.

6. Agent-Anmeldung / Controller
   Agenten können über „Am Server anmelden“ auf den Server-Controller zugreifen. Konten und Rechte werden ausschließlich hier im Server-Menü „Konten & Rechte“ erstellt bzw. geändert. Der Controller authentifiziert sich über Challenge-Response; Berechtigungen werden serverseitig geprüft. Fernsteuerung ist nur für online befindliche, freigegebene Geräte mit lokaler Zustimmung möglich. Eine aktive Controller-Sitzung kann vom Server-Dashboard jederzeit beendet werden; eine vom Server geöffnete Sitzung hat Vorrang.
   Für Anmeldung aus fremden Netzwerken muss die aktualisierte Datei GitHub/relay/main.py in das Render-Relay-Repository übernommen und neu deployt werden. Die neue Relay-Rolle „controller“ muss vorhanden sein. Im LAN wird weiterhin TCP 47623 verwendet; diesen Port nur in vertrauenswürdigen Netzwerken freigeben.


KONTO-SPEZIFISCHE GERÄTEZUWEISUNG
Im Menü „Konten & Rechte“ zuerst ein Konto markieren und dann „Geräte zuweisen“ öffnen. Nur angehakte Geräte werden diesem Konto zugewiesen. Bei nicht zugewiesenen Geräten wird die Liste ausgeblendet und ein direkter Steuerungsversuch serverseitig verweigert. Zusätzlich müssen die allgemeinen Kontorechte für Geräteanzeige und Fernsteuerung gesetzt sein; auch Serverfreigabe und lokale Zustimmung bleiben erforderlich. Entfernt man eine Zuweisung während einer aktiven Sitzung, beendet der Server diese Sitzung. Das Owner-Konto hat automatisch Zugriff auf alle freigegebenen Geräte. Bestehende Konten erhalten absichtlich keine automatische Gerätezuweisung.


Neue Erweiterungen (Oktober 2026)
Details, Grenzen und Installation stehen in ERWEITERUNGEN_2026-10.txt im Paketstamm. Vor dem Update Server/data sichern. Dateiübertragung ist controller->Zielgerät (max. 2 MiB), Zwischenablage nur nach Bestätigung und Monitorwechsel schaltet die Bildschirmaufnahme um. Der Notfallmodus beendet aktive Sitzungen, nicht den Agenten.
