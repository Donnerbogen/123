const { contextBridge, ipcRenderer } = require("electron");

contextBridge.exposeInMainWorld("focusAPI", {
  getState: () => ipcRenderer.invoke("state:get"),
  setupPassword: (password) => ipcRenderer.invoke("password:setup", password),
  login: (password) => ipcRenderer.invoke("password:login", password),
  changePassword: (oldPassword, newPassword) => ipcRenderer.invoke("password:change", oldPassword, newPassword),
  saveCategories: (categories) => ipcRenderer.invoke("categories:save", categories),
  startFocus: (categoryId) => ipcRenderer.invoke("focus:start", categoryId),
  stopFocus: () => ipcRenderer.invoke("focus:stop"),
  saveSchedule: (schedule) => ipcRenderer.invoke("schedule:save", schedule),
  startLock: (password, minutes) => ipcRenderer.invoke("lock:start", password, minutes),
  unlock: (password) => ipcRenderer.invoke("lock:unlock", password),
  endLock: () => ipcRenderer.invoke("lock:end"),
  minimize: () => ipcRenderer.send("window:minimize"),
  hide: () => ipcRenderer.send("window:hide"),
  getRunningApps: () => ipcRenderer.invoke("apps:running"),
  addProgram: (categoryId, exePath) => ipcRenderer.invoke("program:add", categoryId, exePath),
  removeProgram: (categoryId, exePath) => ipcRenderer.invoke("program:remove", categoryId, exePath),
  onUpdate: (callback) => ipcRenderer.on("state:update", (_event, state) => callback(state)),
  onNotice: (callback) => ipcRenderer.on("notice", (_event, message) => callback(message))
});
