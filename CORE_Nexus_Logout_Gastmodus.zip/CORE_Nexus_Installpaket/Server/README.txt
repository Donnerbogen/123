﻿CORE NEXUS – KOMPLETTES SYSTEM-UPDATE
=====================================

Diese Version erweitert das native Windows-Dashboard und verbessert die Statusanzeige des Agenten. Server und Agent bleiben getrennte, kopierbare Ordner.

NEU IM SERVER
- Übersicht mit Kennzahlen für Geräte, Online-Geräte, freigegebene Geräte und ausstehende Freigaben
- Automatische Aktualisierung der Geräteübersicht alle 5 Sekunden
- Gerätefilter: Alle, Online, Offline, Freigabe ausstehend, Freigegeben
- Deutlichere Freigabe- und Online-Statusfarben
- Aktivitätsprotokoll als CSV exportieren (bis zu 5.000 Einträge)
- Datenbank-Sicherung direkt aus dem Dashboard; Sicherungen landen in Server/backups
- Systemseite mit Ports, Datenbankpfad und Wartungsaktionen
- Verbesserte Statusdiagnose im Agenten; erklärt den Unterschied zwischen lokaler Zustimmung und Serverfreigabe

UPDATE / DATENERHALT
1. Server beenden.
2. Den Ordner Server/data vollständig sichern.
3. Neue Server- und Agent-Programmdateien aus diesem Paket übernehmen.
4. Den bisherigen Server/data-Ordner zurückkopieren. Nicht die Datenbank löschen.
5. Server/start.bat starten und als Owner anmelden.
6. Auf der Seite Übersicht die Kennzahlen prüfen. Auf Geräte kann nach Status gefiltert werden.
7. Falls ein Gerät als „Serverfreigabe fehlt“ angezeigt wird, Gerät auswählen und „Gerät freigeben“ anklicken. Lokale Zustimmung UND Serverfreigabe sind erforderlich.

SICHERHEIT
- Nur in einem vertrauenswürdigen privaten LAN verwenden. Keine Router-Portweiterleitung.
- Diese Entwicklungsfassung verschlüsselt den LAN-Verkehr nicht mit TLS.
- Fernsteuerung bleibt an lokale Zustimmung und Serverfreigabe gebunden. Windows-Sicherheitsbildschirm wird nicht umgangen.
- Vor größeren Änderungen immer die Server/data-Datenbank sichern.

TESTSTATUS
Python-Syntax und ZIP-Integrität wurden geprüft. Ein vollständiger Laufzeittest auf Windows mit mehreren echten PCs konnte hier nicht durchgeführt werden.
