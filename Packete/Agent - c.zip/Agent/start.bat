﻿@echo off
setlocal EnableExtensions
chcp 65001 >nul
cd /d "%~dp0"
title CORE Nexus Agent
if not exist "installed.flag" (
  echo CORE Nexus Agent wurde noch nicht installiert.
  echo Bitte zuerst install.bat ausfuehren.
  pause
  exit /b 1
)
rem Starte die GUI mit pythonw/pyw, damit sich dieses Konsolenfenster schliessen kann.
where pyw >nul 2>&1
if not errorlevel 1 (
  start "" /B pyw -3 "%~dp0agent.py"
  exit /b 0
)
set "PYW="
for /f "delims=" %%P in ('where pythonw 2^>nul') do if not defined PYW set "PYW=%%P"
if defined PYW (
  start "" "%PYW%" "%~dp0agent.py"
  exit /b 0
)
echo FEHLER: pythonw/pyw wurde nicht gefunden.
echo Bitte Python erneut installieren und den Python Launcher aktivieren.
pause
exit /b 1
