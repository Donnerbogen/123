@echo off
setlocal EnableExtensions
chcp 65001 >nul
pushd "%~dp0"
title CORE Nexus Agent - Installation

echo ============================================
echo       CORE NEXUS AGENT - INSTALLATION
echo ============================================
echo.

set "PY="
where py >nul 2>&1
if not errorlevel 1 (
  set "PY=py -3"
) else (
  where python >nul 2>&1
  if not errorlevel 1 set "PY=python"
)
if not defined PY (
  echo FEHLER: Python 3 wurde nicht gefunden.
  echo Installiere Python von https://www.python.org/downloads/windows/
  echo Aktiviere "Add Python to PATH" und installiere Tcl/Tk.
  pause
  popd
  exit /b 1
)
%PY% --version
if errorlevel 1 goto :error
%PY% -c "import tkinter" >nul 2>&1
if errorlevel 1 (
  echo FEHLER: Tkinter fehlt. Python mit Tcl/Tk installieren.
  pause
  popd
  exit /b 1
)

echo.
echo [1/4] Installiere Python-Abhaengigkeiten...
%PY% -m pip install --disable-pip-version-check --upgrade -r requirements.txt
if errorlevel 1 goto :error

echo.
echo [2/4] Pruefe agent.py...
%PY% -m py_compile agent.py
if errorlevel 1 goto :error

echo.
echo [3/4] Erstelle benoetigte lokale Daten...
if not exist "data" mkdir "data"
if not exist "relay_config.json" if exist "relay_config.example.json" copy /y "relay_config.example.json" "relay_config.json" >nul

echo.
echo [4/4] Markiere Installation...
>"installed.flag" echo CORE Nexus Agent installiert am %DATE% %TIME%
echo.
echo INSTALLATION ERFOLGREICH.
echo Beim ersten Start fragt der Agent nach der Raum-ID des Servers.
echo Starte den Agenten anschliessend mit start.bat.
echo.
pause
popd
exit /b 0

:error
echo.
echo FEHLER: Installation fehlgeschlagen. Pruefe Python und Internetverbindung.
pause
popd
exit /b 1
