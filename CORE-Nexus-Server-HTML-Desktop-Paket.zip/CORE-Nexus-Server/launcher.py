from pathlib import Path
import sys, runpy, webview
ROOT = Path(__file__).resolve().parent

def resource(*parts):
    base = Path(getattr(sys, "_MEIPASS", ROOT))
    return base.joinpath(*parts)

LEGACY = resource("legacy_server.py")
HTML = resource("ui", "index.html")

class Bridge:
    def launch_legacy(self):
        # Explicit opt-in to the legacy Python/Tk interface. In frozen mode, run
        # bundled source in this same process; in source mode, execute local script.
        runpy.run_path(str(LEGACY), run_name="__main__")
        return "Legacy interface launched"
    def backend_status(self):
        return {"connected": False, "message": "HTML interface is not yet wired to the backend."}

if __name__ == "__main__":
    if "--legacy" in sys.argv:
        runpy.run_path(str(LEGACY), run_name="__main__")
    else:
        webview.create_window("CORE Nexus Server", str(HTML), width=1180, height=760, min_size=(900, 600), background_color="#070b13", js_api=Bridge())
        webview.start(debug=False)
