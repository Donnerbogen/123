#!/usr/bin/env bash
set -Eeuo pipefail
cd "$(dirname "$(readlink -f "$0")")/.."
PYTHON="${PYTHON:-python3}"
command -v "$PYTHON" >/dev/null || { echo "Python 3 fehlt. Installiere python3, python3-venv, python3-tk und python3-pip."; exit 1; }
"$PYTHON" -c 'import tkinter' 2>/dev/null || { echo "Tkinter fehlt. Debian/Ubuntu: sudo apt install python3-tk python3-venv python3-pip."; exit 1; }
if [[ -z "${VIRTUAL_ENV:-}" ]]; then
  "$PYTHON" -m venv .venv || { echo "Virtuelle Umgebung konnte nicht erstellt werden. Debian/Ubuntu: sudo apt install python3-venv"; exit 1; }
  PIP=".venv/bin/python -m pip"
else PIP="$PYTHON -m pip"; fi
# shellcheck disable=SC2086
$PIP install --upgrade pip
# shellcheck disable=SC2086
$PIP install -r requirements-linux.txt
"${PYTHON}" -m py_compile agent.py
mkdir -p data
cp -n relay_config.example.json relay_config.json 2>/dev/null || true
chmod +x Linux/start.sh
printf '
Installation fertig. Starte mit ./start-linux.sh
Hinweis: Bildschirmsteuerung benötigt unter Linux eine X11-Sitzung; Wayland kann Capture/Eingabe blockieren.
'
