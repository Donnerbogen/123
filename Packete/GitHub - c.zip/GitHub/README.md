# CORE Nexus Relay für Render

## Bereitstellung
1. Lade den Inhalt dieses Ordners in das Stammverzeichnis deines privaten GitHub-Repositories.
2. Erstelle in Render über **New + → Blueprint** einen Blueprint aus dem Repository oder synchronisiere den bestehenden Blueprint.
3. Render erstellt einen Web-Service mit `render.yaml`.
4. Unter **Environment** müssen `CORE_NEXUS_RELAY_TOKEN` und `CORE_NEXUS_DASHBOARD_TOKEN` gesetzt sein. Beide Werte müssen geheim bleiben und sind getrennte Tokens. Wenn Render sie nicht automatisch erzeugt hat, erstelle lange zufällige Werte.
5. Öffne `https://DEIN-DIENST.onrender.com/health` zum technischen Health-Check.
6. Öffne `https://DEIN-DIENST.onrender.com/` für das CORE-Nexus-Relay-Dashboard und gib dort den Wert von `CORE_NEXUS_DASHBOARD_TOKEN` ein.

## Dashboard
Das Dashboard zeigt aktuell verbundene Server und Agenten, Nachrichten seit dem letzten Dienststart, Fehler-/Abbruchzähler und die letzten Relay-Ereignisse. Ereignisse und Zähler werden nur im Arbeitsspeicher gehalten und nach einem Neustart zurückgesetzt. Das Dashboard ist durch das separate Dashboard-Token geschützt.

## Windows-Programme
Der Agent versucht zuerst eine direkte LAN-Verbindung. Nur wenn die LAN-Erkennung/Verbindung nicht gelingt, nutzt er den Relay. Server und Agent benötigen für den Relay dieselbe Raum-ID und das passende Relay-Token. Die Server-Datenbank bleibt lokal.

## Sicherheit
- Tokens niemals in GitHub hochladen oder öffentlich teilen.
- Relay verwendet TLS via `wss://`; es ist keine Ende-zu-Ende-Verschlüsselung der Anwendungsnachrichten.
- Lokale Zustimmung am Zielgerät, Serverfreigabe und eine ausdrücklich geöffnete Fernsteuerungssitzung bleiben erforderlich.
- Keine Router-Portfreigabe einrichten.


## Automatische Adminserver-Erkennung
Die aktuelle `relay/main.py` unterstützt eine authentifizierte Admin-Registry-Verbindung (`X-Core-Role: admin`, Raum `__registry__`). Der Adminserver kann damit alle aktuell verbundenen Serverräume automatisch auflisten, ohne Serveradressen oder Raum-IDs manuell einzutragen. Nach dem Ändern von `relay/main.py` muss der Render-Webservice neu bereitgestellt werden.

Für automatische Fernverwaltung wird auf allen normalen Servern derselbe geheime `admin_token` verwendet. Die Raum-ID bleibt pro Serverraum eindeutig. Der Adminserver benötigt in `connection_config.json` nur die Render-WebSocket-URL, den Render-Relay-Token und diesen gemeinsamen Admin-Token. Diese lokalen Konfigurationsdateien dürfen nicht ins GitHub-Repository hochgeladen werden.
