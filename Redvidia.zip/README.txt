REDVIDIA – ECHTE VERKAUFSPOSTER (Fabric 1.21.11)

ResourcePack: CIT Resewn Continuation / kein OptiFine erforderlich.
Poster werden über umbenanntes Papier im Item-Frame angezeigt.

INSTALLATION:
1) Installiere Fabric 1.21.11, Fabric API und CIT Resewn Continuation passend zu 1.21.11.
2) ZIP unverändert in .minecraft/resourcepacks legen und im Spiel aktivieren.
3) Papier am Amboss auf einen der exakten Namen unten umbenennen.
4) Papier in Item-Frame setzen.

NAMEN (exakt):
- Redvidia-Poster-Activator-Rail  |  Activator Rail
- Redvidia-Poster-Calibrated-Sculk-Sensor  |  Calibrated Sculk Sensor
- Redvidia-Poster-Comparator  |  Comparator
- Redvidia-Poster-Copper-Bulb  |  Copper Bulb
- Redvidia-Poster-Crafter  |  Crafter
- Redvidia-Poster-Detector-Rail  |  Detector Rail
- Redvidia-Poster-Dispenser  |  Dispenser
- Redvidia-Poster-Dropper  |  Dropper
- Redvidia-Poster-Honey-Block  |  Honey Block
- Redvidia-Poster-Hopper  |  Hopper
- Redvidia-Poster-Lever  |  Lever
- Redvidia-Poster-Lightning-Rod  |  Lightning Rod
- Redvidia-Poster-Minecart-Chest  |  Minecart Chest
- Redvidia-Poster-Minecart-Hopper  |  Minecart Hopper
- Redvidia-Poster-Note-Block  |  Note Block
- Redvidia-Poster-Observer  |  Observer
- Redvidia-Poster-Piston  |  Piston
- Redvidia-Poster-Powered-Rail  |  Powered Rail
- Redvidia-Poster-Pressure-Plate  |  Pressure Plate
- Redvidia-Poster-Redstone-Block  |  Redstone Block
- Redvidia-Poster-Redstone-Dust  |  Redstone Dust
- Redvidia-Poster-Redstone-Lamp  |  Redstone Lamp
- Redvidia-Poster-Redstone-Torch  |  Redstone Torch
- Redvidia-Poster-Repeater  |  Repeater
- Redvidia-Poster-Sculk-Sensor  |  Sculk Sensor
- Redvidia-Poster-Slime-Block  |  Slime Block
- Redvidia-Poster-Sticky-Piston  |  Sticky Piston
- Redvidia-Poster-Stone-Button  |  Stone Button
- Redvidia-Poster-Target  |  Target
- Redvidia-Poster-Tnt  |  Tnt
- Redvidia-Poster-Trapped-Chest  |  Trapped Chest
- Redvidia-Poster-Tripwire-Hook  |  Tripwire Hook
- Redvidia-Poster-Weighted-Plate-Heavy  |  Weighted Plate Heavy
- Redvidia-Poster-Weighted-Plate-Light  |  Weighted Plate Light
- Redvidia-Poster-Wooden-Button  |  Wooden Button

Hinweis: Poster werden als Item-CIT-Modelle dargestellt. OptiFine ist nicht erforderlich; CIT Resewn Continuation wird benötigt.
- Redvidia-logo  |  Redvidia Logo


ORIGINAL MINECRAFT ITEM TEXTURES (PNG)
Die aus dem vom Nutzer bereitgestellten 1.21.11-Template extrahierten Original-PNGs liegen zusätzlich unter:
assets/redvidia/textures/items/originals/
Diese Dateien sind ergänzende Assets und ändern keine Poster-CIT-Zuweisungen.


UPDATE: Selected poster designs were refreshed with clearer layouts and pixel-art product displays; piston posters show pistons vertically extended upward.caling.
