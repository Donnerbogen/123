CORE NEXUS CLOUD AGENT
======================

This is an endpoint agent, not a server. The CORE Nexus server and website run together on Render.

SETUP
1. Deploy the CloudServer folder with the root render.yaml (see README_WEB_EDITION.txt).
2. In Agent/relay_config.json, set relay_url to wss://YOUR-RENDER-SERVICE.onrender.com/ws.
3. Copy CORE_NEXUS_RELAY_TOKEN from the Render Environment page into the relay_token field in relay_config.json.
4. Keep room_id equal to CORE_NEXUS_ROOM_ID (default: core-nexus-main).
5. On Windows, run setup.bat and choose option 1, then run start.bat.
6. The first run asks the local user for permission. Then sign into the website and approve the device.

The device needs outbound Internet access to the Render HTTPS/WSS endpoint. No inbound port forwarding is required. Do not publish the device token or relay_config.json containing the token.

The agent requires Python 3.15.0 exactly (not 3.15.1 or any other version). The installer and application reject all other interpreter versions. It uses Pillow, mss, pynput, pyperclip and websocket-client. Screen capture/input control requires the relevant dependencies and a user session.
