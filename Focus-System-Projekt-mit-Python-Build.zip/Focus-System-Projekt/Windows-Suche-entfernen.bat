@echo off
setlocal
title Focus System - Windows-Suche entfernen
set "LINK=%APPDATA%\Microsoft\Windows\Start Menu\Programs\Focus System.lnk"
if exist "%LINK%" (
  del "%LINK%"
  echo Focus System wurde aus dem Startmenue entfernt.
) else (
  echo Es wurde keine Focus-System-Verknuepfung gefunden.
)
echo Die Anwendung und ihre Dateien bleiben unveraendert.
pause
