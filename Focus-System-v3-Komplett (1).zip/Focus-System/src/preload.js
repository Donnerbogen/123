const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('focusAPI', {
  getInitial: () => ipcRenderer.invoke('app:get-initial'),
  setupPassword: p => ipcRenderer.invoke('auth:setup', p),
  authenticate: p => ipcRenderer.invoke('auth:login', p),
  changePassword: (oldPassword, newPassword) => ipcRenderer.invoke('auth:change-password', {oldPassword,newPassword}),
  getRunningPrograms: () => ipcRenderer.invoke('programs:list-running'),
  saveConfig: c => ipcRenderer.invoke('config:save', c),
  getState: () => ipcRenderer.invoke('focus:get-state'),
  startFocus: id => ipcRenderer.invoke('focus:start', id),
  stopFocus: () => ipcRenderer.invoke('focus:stop'),
  startLock: (password, durationMinutes) => ipcRenderer.invoke('lock:start', {password,durationMinutes}),
  unlock: p => ipcRenderer.invoke('lock:unlock', p),
  getLogs: () => ipcRenderer.invoke('logs:get'),
  openDataFolder: () => ipcRenderer.invoke('app:open-data-folder'),
  onState: cb => { const f=(_e,s)=>cb(s); ipcRenderer.on('focus:state',f); return ()=>ipcRenderer.removeListener('focus:state',f); },
  onNotification: cb => { const f=(_e,x)=>cb(x); ipcRenderer.on('app:notification',f); return ()=>ipcRenderer.removeListener('app:notification',f); }
});
