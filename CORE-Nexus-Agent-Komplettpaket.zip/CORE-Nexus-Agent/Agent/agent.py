"""CORE Nexus Agent. All server communication uses the central relay.
Requires explicit local user consent and server-side device approval.
"""
from __future__ import annotations
import json, os, platform, queue, socket, threading, time, uuid, io, hashlib, hmac, sys, shutil
import tkinter as tk
from tkinter import ttk, messagebox
import base64
try:
    import pystray
    from PIL import Image, ImageDraw
    TRAY_AVAILABLE = True
except Exception:
    pystray = None
    ImageDraw = None
    TRAY_AVAILABLE = False
try:
    import mss
    from PIL import Image
    from pynput.mouse import Controller as MouseController, Button
    from pynput.keyboard import Controller as KeyboardController, Key
    REMOTE_LIBS = True
except Exception:
    REMOTE_LIBS = False

APP='CORE Nexus Agent'
APP_ROOT = os.path.dirname(sys.executable) if getattr(sys, 'frozen', False) else os.path.dirname(os.path.abspath(__file__))
BASE=os.path.join(APP_ROOT,'data'); os.makedirs(BASE,exist_ok=True)
def migrate_legacy(name):
    old=os.path.join(APP_ROOT,name); new=os.path.join(BASE,name)
    if os.path.isfile(old) and not os.path.isfile(new): shutil.copy2(old,new)
    return new
ID_FILE=os.path.join(BASE,'device_id.json')
migrate_legacy('device_id.json'); migrate_legacy('consent.json')
HEARTBEAT=5; OFFLINE_TIMEOUT=18
REMOTE_HEARTBEAT_INTERVAL=0.065
REMOTE_FRAME_INTERVAL=0.16
REMOTE_FRAME_MAX_SIZE=(1152, 648)
REMOTE_JPEG_QUALITY=36

def ensure_room_id():
    """Require a room ID once on first start and persist it locally."""
    cfg_path = migrate_legacy('relay_config.json')
    try:
        with open(cfg_path, 'r', encoding='utf-8') as f:
            cfg = json.load(f)
    except Exception:
        cfg = {'transport': 'websocket-relay', 'relay_url': 'wss://core-nexus-relay.onrender.com/ws',
               'relay_token_env': 'CORE_NEXUS_RELAY_TOKEN', 'relay_token': '', 'enabled': True}
    room = str(cfg.get('room_id', '')).strip()
    if room:
        return True
    dialog = tk.Tk()
    dialog.withdraw()
    dialog.attributes('-topmost', True)
    try:
        messagebox.showinfo('CORE Nexus – Server zuordnen',
            'Gib die Raum-ID ein, die bei der Erstinstallation deines CORE Nexus Servers angezeigt wurde.\n\n'
            'Der Agent wird diesem Server-Raum zugeordnet.', parent=dialog)
        from tkinter import simpledialog
        while True:
            value = simpledialog.askstring('CORE Nexus – Raum-ID', 'Raum-ID des Servers:', parent=dialog)
            if value is None:
                return False
            value = value.strip().upper()
            if 6 <= len(value) <= 80 and all(ch.isalnum() or ch in '-_' for ch in value):
                cfg['room_id'] = value
                with open(cfg_path, 'w', encoding='utf-8') as f:
                    json.dump(cfg, f, ensure_ascii=False, indent=2)
                    f.write('\n')
                messagebox.showinfo('CORE Nexus', 'Raum-ID gespeichert. Sie muss auf diesem Gerät nicht erneut eingegeben werden.', parent=dialog)
                return True
            messagebox.showerror('Ungültige Raum-ID', 'Bitte gib eine gültige Raum-ID ein (6–80 Zeichen, Buchstaben, Zahlen, - oder _).', parent=dialog)
    finally:
        dialog.destroy()

def get_device_id():
    try:
        with open(ID_FILE,'r',encoding='utf-8') as f: return json.load(f)['device_id']
    except Exception:
        did=str(uuid.uuid4())
        try:
            with open(ID_FILE,'w',encoding='utf-8') as f: json.dump({'device_id':did},f)
        except OSError: pass
        return did

def send_json(sock,obj):
    sock.sendall((json.dumps(obj,separators=(',',':'))+'\n').encode('utf-8'))

def recv_json(file):
    line=file.readline()
    if not line: raise ConnectionError('Server hat die Verbindung beendet.')
    if len(line)>8_000_000: raise ValueError('Antwort des Servers ist zu groß.')
    return json.loads(line.decode('utf-8'))

class RelayAgentSocket:
    """Adapts a WSS relay connection to the existing newline-JSON socket interface."""
    def __init__(self, ws, device_id): self.ws=ws; self.device_id=device_id; self.closed=False
    def settimeout(self, value): self.ws.settimeout(value)
    def makefile(self, mode): return self
    def sendall(self, data):
        obj=json.loads(data.decode('utf-8').strip())
        self.ws.send(json.dumps({'device_id':self.device_id,'payload':obj},separators=(',',':')))
    def readline(self):
        while not self.closed:
            raw=self.ws.recv()
            if not raw: return b''
            envelope=json.loads(raw)
            if envelope.get('device_id') != self.device_id: continue
            payload=envelope.get('payload')
            if isinstance(payload,dict): return (json.dumps(payload,separators=(',',':'))+'\n').encode('utf-8')
        return b''
    def close(self):
        self.closed=True
        try: self.ws.close()
        except Exception: pass

class Agent:
    def __init__(self):
        self.device_id=get_device_id(); self.sock=None; self.file=None; self.running=True; self.connected=False; self.connecting=False; self.uiq=queue.Queue(); self.remote_active=False; self.remote_mouse=MouseController() if REMOTE_LIBS else None; self.remote_keyboard=KeyboardController() if REMOTE_LIBS else None; self.remote_last_frame=None; self._mss_capture=None; self.frame_native_size=None; self.frame_encoded_size=None; self._last_frame_time=0.0; self.input_count=0; self.monitor_index=1; self.file_transfers={}; self.last_approved=None; self.last_server_approved=None; self.connection_mode='Noch nicht verbunden'; self.managed_mode='normal'; self.agent_mode_status='normal'; self.tray_icon=None; self.tray_thread=None; self._tray_running=False; self.root=tk.Tk(); self.root.title(APP); self.root.geometry('650x470'); self.root.minsize(600,440); self.root.configure(bg='#060b16'); self.root.resizable(True,True)
        style=ttk.Style(); style.theme_use('clam'); style.configure('.',background='#0b1628',foreground='#eef6ff',fieldbackground='#101f34',font=('Segoe UI',10)); style.configure('TFrame',background='#0b1628'); style.configure('TLabel',background='#0b1628',foreground='#eef6ff',font=('Segoe UI',10)); style.configure('Title.TLabel',font=('Segoe UI',23,'bold'),foreground='#55d9ff'); style.configure('Sub.TLabel',foreground='#91a7c4',font=('Segoe UI',9)); style.configure('Hero.TLabel',font=('Segoe UI',12,'bold'),foreground='#d9efff'); style.configure('Card.TFrame',background='#0d1b2e',relief='solid',borderwidth=1); style.configure('TButton',background='#153657',foreground='white',padding=(13,9),borderwidth=1); style.map('TButton',background=[('active','#1e5b89'),('pressed','#16436a')]); style.configure('TEntry',padding=7,fieldbackground='#071322',foreground='#eef6ff')
        outer=ttk.Frame(self.root,padding=22); outer.pack(fill='both',expand=True)
        top=ttk.Frame(outer); top.pack(fill='x',pady=(0,18)); brand=ttk.Frame(top); brand.pack(side='left',fill='x',expand=True); ttk.Label(brand,text='CORE NEXUS',style='Title.TLabel').pack(anchor='w'); ttk.Label(brand,text='SECURE ENDPOINT  /  CROSS-PLATFORM AGENT',style='Sub.TLabel').pack(anchor='w',pady=(1,0))
        self.badge=ttk.Label(top,text='●  INITIALIZING',foreground='#ffca70',font=('Segoe UI',9,'bold')); self.badge.pack(side='right',anchor='center',padx=(8,0))
        card=ttk.Frame(outer,padding=18,style='Card.TFrame'); card.pack(fill='x',pady=(0,12)); ttk.Label(card,text='VERBINDUNGSSTATUS',style='Sub.TLabel').pack(anchor='w'); self.status=ttk.Label(card,text='Verbinde mit dem CORE Nexus Relay …',wraplength=540,style='Hero.TLabel'); self.status.pack(anchor='w',pady=(7,13)); ttk.Separator(card).pack(fill='x',pady=(0,10)); row=ttk.Frame(card); row.pack(fill='x'); ttk.Label(row,text='VERBINDUNGSWEG',style='Sub.TLabel').pack(side='left'); self.transport=ttk.Label(row,text='CORE NEXUS RELAY',foreground='#55d9ff',font=('Segoe UI',9,'bold')); self.transport.pack(side='right')
        lower=ttk.Frame(outer); lower.pack(fill='both',expand=True); left=ttk.Frame(lower,padding=15,style='Card.TFrame'); left.pack(side='left',fill='both',expand=True,padx=(0,10)); ttk.Label(left,text='GERÄTEINFORMATION',style='Sub.TLabel').pack(anchor='w'); ttk.Label(left,text=f'Geräte-ID  {self.device_id[:18]}…',style='Hero.TLabel').pack(anchor='w',pady=(8,5)); ttk.Label(left,text=('Fernsteuerungsbibliotheken bereit' if REMOTE_LIBS else 'Fernsteuerungs-Abhängigkeiten fehlen'),foreground=('#47e0a0' if REMOTE_LIBS else '#ff7285'),wraplength=300).pack(anchor='w'); ttk.Label(left,text='Lokale Zustimmung und Serverfreigabe sind erforderlich.',style='Sub.TLabel',wraplength=300).pack(anchor='w',pady=(9,0))
        right=ttk.Frame(lower,padding=15,style='Card.TFrame'); right.pack(side='right',fill='y'); ttk.Label(right,text='AKTIONEN',style='Sub.TLabel').pack(anchor='w',pady=(0,9)); self.retry=ttk.Button(right,text='⟳  Erneut verbinden',command=self.start_connect); self.retry.pack(fill='x'); self.login_button=ttk.Button(right,text='🔐  Am Server anmelden',command=self.open_account_login); self.login_button.pack(fill='x',pady=(8,0)); self.background_button=ttk.Button(right,text='Fenster minimieren',command=self.minimize_window); self.background_button.pack(fill='x',pady=(8,0)); ttk.Label(right,text='Status aktualisiert automatisch.\n\nAlle Verbindungen laufen ausschließlich über den zentralen Relay.\nKeine direkte Verbindung zum Webserver oder LAN-Server.\n\nHintergrundbetrieb bleibt über Tray oder Taskleiste erkennbar.',style='Sub.TLabel',wraplength=190).pack(anchor='w',pady=(13,0))
        self.root.protocol('WM_DELETE_WINDOW',self.close); self.root.after(200,self.poll); self.root.after(60000,self.auto_reconnect_check); self.start_connect()

    def open_account_login(self):
        dlg=tk.Toplevel(self.root); dlg.title('CORE Nexus | Agent-Anmeldung'); dlg.configure(bg='#0b1628'); dlg.transient(self.root); dlg.grab_set(); dlg.resizable(False,False)
        body=ttk.Frame(dlg,padding=22); body.pack(fill='both',expand=True)
        ttk.Label(body,text='SERVER-ANMELDUNG',style='Title.TLabel').pack(anchor='w',pady=(0,6))
        ttk.Label(body,text='Verwende ein Konto, das im CORE-Nexus-Server angelegt wurde.',style='Sub.TLabel',wraplength=350).pack(anchor='w',pady=(0,14))
        ttk.Label(body,text='Benutzername').pack(anchor='w'); username=ttk.Entry(body,width=38); username.pack(fill='x',pady=(3,10))
        ttk.Label(body,text='Passwort').pack(anchor='w'); password=ttk.Entry(body,show='*',width=38); password.pack(fill='x',pady=(3,10))
        status=ttk.Label(body,text='',foreground='#ff8585',wraplength=350); status.pack(anchor='w',pady=(0,8))
        buttons=ttk.Frame(body); buttons.pack(fill='x')
        login=ttk.Button(buttons,text='Anmelden'); login.pack(side='right')
        ttk.Button(buttons,text='Abbrechen',command=dlg.destroy).pack(side='right',padx=(0,8))
        def attempt():
            u=username.get().strip(); pw=password.get()
            if not u or not pw: status.configure(text='Bitte Benutzername und Passwort eingeben.'); return
            login.configure(state='disabled'); status.configure(text='Verbinde sicher mit dem Server …',foreground='#55d9ff')
            def worker():
                client=None; error=None
                try:
                    client=AgentControlClient(None,None,u,pw,relay_fallback=True)
                except Exception as exc: error=str(exc)
                def finish():
                    if not dlg.winfo_exists():
                        if client: client.close()
                        return
                    if error:
                        login.configure(state='normal'); status.configure(text=error,foreground='#ff8585')
                    else:
                        dlg.destroy(); AgentControlWindow(self,client,u)
                self.root.after(0,finish)
            threading.Thread(target=worker,daemon=True).start()
        login.configure(command=attempt); password.bind('<Return>',lambda _e:attempt()); username.focus_set()

    def set_status(self,text): self.uiq.put(('status',text))
    def start_connect(self, automatic=False):
        if not self.running or self.connected or self.connecting:
            return
        self.connecting=True
        self.retry.configure(state='disabled')
        if automatic:
            self.status.configure(text='Verbinde ausschließlich mit dem konfigurierten CORE Nexus Relay …')
        else:
            self.status.configure(text='Verbinde mit dem CORE Nexus Relay …')
        threading.Thread(target=self.connect_worker,daemon=True).start()

    def auto_reconnect_check(self):
        # If disconnected, reconnect only to the configured central relay.
        if self.running and not self.connected and not self.connecting:
            self.start_connect(automatic=True)
        if self.running:
            self.root.after(60000,self.auto_reconnect_check)

    def connect_worker(self):
        """Connect exclusively to the configured central CORE Nexus Relay."""
        sock = None
        file = None
        host = 'CORE Nexus Relay'
        try:
            cfg_path = migrate_legacy('relay_config.json')
            try:
                with open(cfg_path, 'r', encoding='utf-8') as handle:
                    cfg = json.load(handle)
            except Exception:
                cfg = {}
            if not cfg.get('enabled'):
                raise ConnectionError('CORE Nexus Relay ist deaktiviert. Bitte relay_config.json prüfen.')
            import websocket
            relay_url = str(cfg.get('relay_url', '')).strip()
            room = str(cfg.get('room_id', '')).strip()
            token = (os.environ.get(cfg.get('relay_token_env', 'CORE_NEXUS_RELAY_TOKEN')) or cfg.get('relay_token') or '').strip()
            if not relay_url.startswith('wss://') or not room or not token or 'PASTE_' in token:
                raise ConnectionError('Relay-Konfiguration unvollständig: relay_url, room_id und CORE_NEXUS_RELAY_TOKEN prüfen.')
            ws = websocket.create_connection(
                relay_url,
                timeout=15,
                header=[f'Authorization: Bearer {token}', 'X-Core-Role: agent', f'X-Core-Room: {room}'],
                origin=relay_url.split('/ws')[0]
            )
            sock = RelayAgentSocket(ws, self.device_id)
            sock.settimeout(OFFLINE_TIMEOUT)
            file = sock
            self.uiq.put(('transport', host))
            send_json(sock, {'type':'hello', 'device_id':self.device_id, 'name':platform.node() or (platform.system() + '-PC'), 'os':platform.platform(), 'boot_id':self._boot_id()})
            reply = recv_json(file)
            if not reply.get('ok'):
                raise ConnectionError('Der Server hat die Registrierung abgelehnt.')
            self.sock = sock
            self.file = file
            self.connected = True
            self.connecting = False
            consent_file = os.path.join(BASE, 'consent.json')
            consent = None
            try:
                with open(consent_file, 'r', encoding='utf-8') as f:
                    consent = json.load(f).get('accepted')
            except Exception:
                pass
            if consent is None:
                self.uiq.put(('consent', None))
                return
            send_json(sock, {'type':'consent', 'accepted':bool(consent)})
            state = recv_json(file)
            if not consent:
                raise PermissionError('Lokale Zustimmung wurde verweigert. Der Agent bleibt geschlossen.')
            if not state.get('approved'):
                if state.get('server_approved') and not state.get('consent'):
                    self.set_status('Serverfreigabe vorhanden, aber die lokale Zustimmung fehlt. Bitte Zustimmung am Ziel-PC erneut erteilen.')
                else:
                    self.set_status('Relay verbunden. Serverfreigabe fehlt oder wurde widerrufen. Öffne im Server-Dashboard die Geräteverwaltung und gib dieses Gerät frei.')
            else:
                self.uiq.put(('transport', host))
                self.set_status('Verbunden über den zentralen Relay. Fernsteuerung startet nur in einer ausdrücklich geöffneten Sitzung.')
            threading.Thread(target=self.heartbeat_loop, daemon=True).start()
        except Exception as e:
            self.connected = False
            self.connecting = False
            if self.sock is sock:
                self.sock = None
                self.file = None
            try:
                if sock: sock.close()
            except Exception:
                pass
            self.set_status(f'Verbindung zum CORE Nexus Relay fehlgeschlagen: {e}\nDer Agent versucht automatisch erneut, den Relay zu erreichen.')
            self.uiq.put(('offline', str(e)))

    @staticmethod
    def _boot_id():
        # A best-effort boot marker; no system changes are made.
        try: return str(int(time.time()-time.monotonic()))
        except Exception: return 'unknown'

    def heartbeat_loop(self):
        # Frequent small heartbeats keep input latency low. Screenshots are sent
        # less often and compressed cheaply so a slow uplink is not saturated.
        while self.running and self.sock:
            try:
                packet={'type':'heartbeat','agent_mode_status':self.agent_mode_status}
                now=time.monotonic()
                if self.remote_active and REMOTE_LIBS and now-self._last_frame_time >= REMOTE_FRAME_INTERVAL:
                    try:
                        packet['frame']=self.capture_frame()
                        self._last_frame_time=now
                    except Exception as capture_error:
                        self.set_status(f'Bildschirm konnte nicht erfasst werden: {capture_error}')
                send_json(self.sock,packet)
                reply=recv_json(self.file)
                if reply.get('close_agent'):
                    self.set_status('Der Server hat das Schließen des Agenten angefordert.')
                    self.uiq.put(('close',None)); return
                managed_mode=str(reply.get('managed_mode','normal'))
                if managed_mode not in ('normal','background','maintenance'): managed_mode='normal'
                if managed_mode != self.managed_mode:
                    self.uiq.put(('managed_mode',managed_mode))
                approved=bool(reply.get('approved'))
                server_approved=bool(reply.get('server_approved'))
                consent=bool(reply.get('consent'))
                self.remote_active=bool(reply.get('remote_active')) and approved and REMOTE_LIBS and managed_mode!='maintenance'
                for command in (reply.get('commands',[]) if managed_mode!='maintenance' else []):
                    try:
                        self.perform_input(command)
                        self.input_count += 1
                    except Exception as command_error:
                        self.set_status(f'Eingabe konnte nicht ausgeführt werden: {command_error}')
                if approved != self.last_approved or server_approved != self.last_server_approved or consent != self.last_consent:
                    if approved:
                        self.set_status('Verbunden und freigegeben. Keine Fernsteuerung aktiv, bis eine Sitzung am Server geöffnet wird.')
                    elif not consent:
                        self.set_status('Lokale Zustimmung fehlt oder wurde widerrufen. Fernzugriff bleibt gesperrt.')
                    else:
                        self.set_status('Agent läuft und ist mit dem Server verbunden. Serverfreigabe fehlt oder wurde widerrufen; Fernzugriff bleibt gesperrt.')
                    self.last_approved=approved; self.last_server_approved=server_approved; self.last_consent=consent
                time.sleep(REMOTE_HEARTBEAT_INTERVAL if self.remote_active else 1.0)
            except Exception as e:
                self.remote_active=False
                self.set_status(f'Verbindung zum Server verloren: {e}\nDer Agent bleibt geöffnet. Prüfe das Netzwerk und klicke auf „Erneut verbinden“.')
                failed_sock=self.sock
                self.connected=False
                self.sock=None
                self.file=None
                try:
                    if failed_sock: failed_sock.close()
                except Exception:
                    pass
                self.uiq.put(('offline',str(e))); return

    def capture_frame(self):
        # Reuse one MSS capture handle and avoid expensive JPEG optimize passes.
        if self._mss_capture is None:
            self._mss_capture = mss.mss()
        monitors=self._mss_capture.monitors
        self.monitor_index=max(1,min(self.monitor_index,len(monitors)-1))
        monitor=monitors[self.monitor_index]
        shot=self._mss_capture.grab(monitor)
        native_w,native_h=shot.size
        image=Image.frombytes('RGB',shot.size,shot.rgb)
        image.thumbnail(REMOTE_FRAME_MAX_SIZE)
        self.frame_native_size=(native_w,native_h)
        self.frame_encoded_size=image.size
        import io
        buf=io.BytesIO()
        image.save(buf,format='JPEG',quality=REMOTE_JPEG_QUALITY,optimize=False,progressive=False)
        return base64.b64encode(buf.getvalue()).decode('ascii')

    def _input_position(self, command):
        x=int(command.get('x',0)); y=int(command.get('y',0))
        encoded=self.frame_encoded_size; native=self.frame_native_size
        if encoded and native and encoded[0]>0 and encoded[1]>0:
            x=round(x*native[0]/encoded[0]); y=round(y*native[1]/encoded[1])
        if native:
            x=max(0,min(native[0]-1,x)); y=max(0,min(native[1]-1,y))
        return (x,y)

    def perform_input(self, command):
        # Input is accepted only during an explicitly active, approved session.
        if not REMOTE_LIBS or not self.remote_active: return
        if self.remote_mouse is None or self.remote_keyboard is None:
            raise RuntimeError('Maus-/Tastaturcontroller ist nicht initialisiert. Bitte Agent neu installieren.')
        kind=command.get('kind')
        if kind=='monitor_next':
            if self._mss_capture is None: self._mss_capture=mss.mss()
            count=max(1,len(self._mss_capture.monitors)-1)
            self.monitor_index=(self.monitor_index % count)+1
            self.set_status(f'Fernsteuerung: Monitor {self.monitor_index} von {count} ausgewählt.')
        elif kind=='clipboard_text':
            text_value=str(command.get('text',''))[:20000]
            try:
                import pyperclip
                pyperclip.copy(text_value)
                self.set_status('Zwischenablage wurde über die freigegebene Sitzung aktualisiert.')
            except Exception as exc: self.set_status(f'Zwischenablage nicht verfügbar: {exc}')
        elif kind=='file_begin':
            tid=str(command.get('transfer_id',''))[:80]
            name=os.path.basename(str(command.get('name','datei.bin')))[:180]
            chunks=int(command.get('chunks',0))
            if tid and 0 <= chunks <= 120:
                self.file_transfers[tid]={'name':name,'chunks':chunks,'parts':{}}
        elif kind=='file_chunk':
            tid=str(command.get('transfer_id',''))[:80]; transfer=self.file_transfers.get(tid)
            if transfer:
                idx=int(command.get('index',-1)); data=str(command.get('data',''))
                if 0 <= idx < transfer['chunks'] and len(data)<=24000: transfer['parts'][idx]=data
        elif kind=='file_end':
            tid=str(command.get('transfer_id',''))[:80]; transfer=self.file_transfers.pop(tid,None)
            if transfer and len(transfer['parts'])==transfer['chunks']:
                try:
                    raw=base64.b64decode(''.join(transfer['parts'][i] for i in range(transfer['chunks'])),validate=True)
                    if len(raw)<=2*1024*1024:
                        outdir=os.path.join(os.path.expanduser('~'),'Downloads','CORE-Nexus-Received'); os.makedirs(outdir,exist_ok=True)
                        outpath=os.path.join(outdir,os.path.basename(transfer['name']))
                        with open(outpath,'wb') as handle: handle.write(raw)
                        self.set_status(f'Datei empfangen: {outpath}')
                    else: self.set_status('Dateiübertragung abgebrochen: Größenlimit überschritten.')
                except Exception as exc: self.set_status(f'Dateiübertragung fehlgeschlagen: {exc}')
            else: self.set_status('Dateiübertragung unvollständig; Datei wurde verworfen.')
        elif kind=='move': self.remote_mouse.position=self._input_position(command)
        elif kind=='click':
            self.remote_mouse.position=self._input_position(command)
            btn=Button.right if command.get('button')=='right' else Button.left
            self.remote_mouse.click(btn, 1)
        elif kind=='scroll':
            self.remote_mouse.position=self._input_position(command)
            self.remote_mouse.scroll(0, int(command.get('dy',0)))
        elif kind=='key':
            name=str(command.get('key',''))[:40]
            keymap={'enter':Key.enter,'tab':Key.tab,'esc':Key.esc,'backspace':Key.backspace,'delete':Key.delete,'space':Key.space,'up':Key.up,'down':Key.down,'left':Key.left,'right':Key.right,'shift':Key.shift,'ctrl':Key.ctrl,'alt':Key.alt,'win':Key.cmd,'f1':Key.f1,'f2':Key.f2,'f3':Key.f3,'f4':Key.f4,'f5':Key.f5,'f6':Key.f6,'f7':Key.f7,'f8':Key.f8,'f9':Key.f9,'f10':Key.f10,'f11':Key.f11,'f12':Key.f12}
            key=keymap.get(name.lower(), name if len(name)==1 else None)
            if key is not None:
                action=command.get('action','press')
                if action=='down': self.remote_keyboard.press(key)
                elif action=='up': self.remote_keyboard.release(key)
                else: self.remote_keyboard.press(key); self.remote_keyboard.release(key)
        elif kind=='text':
            self.remote_keyboard.type(str(command.get('text',''))[:200])

    def ask_consent(self):
        answer=messagebox.askyesno(APP,'CORE Nexus wurde auf diesem PC erkannt.\n\nErlaubst du diesem Gerät, nach Freigabe im Server-Dashboard für Fernansichten und Steuerung verfügbar zu sein? Du kannst die Zustimmung später durch Löschen von Agent/consent.json und erneute Einrichtung zurücksetzen.',parent=self.root)
        try:
            with open(os.path.join(BASE,'consent.json'),'w',encoding='utf-8') as f: json.dump({'accepted':answer},f)
            if self.sock:
                send_json(self.sock,{'type':'consent','accepted':answer}); reply=recv_json(self.file)
                if not answer: self.set_status('Du hast die Zustimmung verweigert. Agent bleibt geschlossen.'); self.close_after(1500); return
                if reply.get('approved'):
                    self.set_status('Zustimmung gespeichert. Gerät ist freigegeben und verbunden.')
                else:
                    self.set_status('Zustimmung gespeichert. Bitte gib dieses Gerät zusätzlich im Server-Dashboard frei.')
                threading.Thread(target=self.heartbeat_loop,daemon=True).start()
        except Exception as e: self.set_status(f'Zustimmung konnte nicht übermittelt werden: {e}')

    def poll(self):
        try:
            while True:
                kind,value=self.uiq.get_nowait()
                if kind=='status':
                    self.status.configure(text=value)
                    low=value.lower()
                    if 'verbunden' in low or 'zustimmung gespeichert' in low:
                        self.badge.configure(text='●  CONNECTED',foreground='#47e0a0')
                    elif 'fehlgeschlagen' in low or 'nicht erreichbar' in low or 'fehler' in low:
                        self.badge.configure(text='●  OFFLINE',foreground='#ff7285')
                    else:
                        self.badge.configure(text='●  CONNECTING',foreground='#ffca70')
                elif kind=='transport':
                    self.connection_mode=str(value)
                    self.transport.configure(text='CORE NEXUS RELAY')
                elif kind=='consent': self.root.after(100,self.ask_consent)
                elif kind=='managed_mode': self.apply_managed_mode(str(value))
                elif kind=='offline': self.retry.configure(state='normal'); self.badge.configure(text='●  OFFLINE',foreground='#ff7285'); self.status.configure(text='Kein Server verbunden. Automatische neue Suche in spätestens 60 Sekunden; du kannst auch manuell erneut verbinden.')
                elif kind=='close': self.close_after(500)
        except queue.Empty: pass
        if self.running: self.root.after(250,self.poll)

    def minimize_window(self):
        """Minimize the visible window without changing the server-managed mode."""
        try: self.root.iconify()
        except Exception: pass

    def _tray_image(self):
        if not TRAY_AVAILABLE: return None
        image=Image.new('RGBA',(64,64),(6,11,22,255))
        draw=ImageDraw.Draw(image)
        draw.rounded_rectangle((5,5,59,59),radius=12,fill=(13,35,57,255),outline=(85,217,255,255),width=3)
        draw.text((17,18),'CN',fill=(85,217,255,255))
        return image

    def _ensure_tray(self):
        if not TRAY_AVAILABLE or self.tray_icon is not None: return bool(self.tray_icon)
        try:
            menu=pystray.Menu(
                pystray.MenuItem('CORE Nexus Agent – Fenster öffnen', lambda icon,item: self.root.after(0,self.restore_window), default=True),
                pystray.MenuItem('Status anzeigen', lambda icon,item: self.root.after(0,self.show_agent_status)),
                pystray.MenuItem('Agent beenden', lambda icon,item: self.root.after(0,self.close))
            )
            self.tray_icon=pystray.Icon('core_nexus_agent',self._tray_image(),'CORE Nexus Agent – Hintergrundbetrieb',menu)
            self.tray_thread=threading.Thread(target=self.tray_icon.run,daemon=True)
            self.tray_thread.start(); self._tray_running=True
            return True
        except Exception as exc:
            self.tray_icon=None; self.set_status(f'Tray konnte nicht gestartet werden: {exc}. Fenster bleibt sichtbar/minimiert.')
            return False

    def _stop_tray(self):
        icon=self.tray_icon; self.tray_icon=None; self._tray_running=False
        if icon:
            try: icon.stop()
            except Exception: pass

    def restore_window(self):
        try:
            self.root.deiconify(); self.root.state('normal'); self.root.lift(); self.root.focus_force()
        except Exception: pass

    def show_agent_status(self):
        self.restore_window()
        self.set_status(f'Modus: {self.managed_mode}. Verbindungsstatus: {"verbunden" if self.connected else "offline"}.')

    def apply_managed_mode(self, mode):
        if mode not in ('normal','background','maintenance'): mode='normal'
        previous=self.managed_mode; self.managed_mode=mode; self.agent_mode_status=mode
        if mode=='background':
            if self._ensure_tray():
                try: self.root.withdraw()
                except Exception: pass
            else:
                # Never withdraw the only visible window when tray support is missing.
                try: self.root.deiconify(); self.root.iconify()
                except Exception: pass
            self.set_status('Hintergrundbetrieb aktiv. CORE Nexus bleibt über das Tray-Symbol bzw. die Taskleiste sichtbar erreichbar.')
        elif mode=='maintenance':
            self._stop_tray(); self.restore_window()
            self.set_status('Wartungsmodus aktiv. Fernsteuerung ist pausiert; der Agent bleibt sichtbar und verbunden.')
        else:
            self._stop_tray(); self.restore_window()
            self.set_status('Normalbetrieb aktiv. Der Agent ist im normalen Fensterbetrieb.')
        if previous != mode:
            try: self.root.title(f'CORE Nexus Agent – { {"normal":"Normalbetrieb","background":"Hintergrundbetrieb","maintenance":"Wartungsmodus"}[mode] }')
            except Exception: pass

    def close_after(self,ms): self.root.after(ms,self.close)
    def close(self):
        self.running=False
        self._stop_tray()
        try:
            if self.sock: self.sock.close()
        except OSError: pass
        try:
            if self._mss_capture is not None:
                self._mss_capture.close()
                self._mss_capture = None
        except Exception: pass
        try: self.root.destroy()
        except tk.TclError: pass

class AgentControlClient:
    """Authenticated account session to the server's controller endpoint."""
    def __init__(self, host, port, username, password, relay_fallback=False):
        self.relay=False; self.send_lock=threading.RLock(); self.pending={}; self.pending_lock=threading.RLock(); self.next_id=0; self.events=queue.Queue(); self.closed=False
        if host is not None:
            raise ValueError('Direkte Serververbindungen sind deaktiviert. CORE Nexus Agent verwendet ausschließlich den zentralen Relay.')
        if relay_fallback:
            cfg_path=migrate_legacy('relay_config.json')
            try:
                with open(cfg_path,'r',encoding='utf-8') as handle: cfg=json.load(handle)
            except Exception: cfg={}
            token=(os.environ.get(cfg.get('relay_token_env','CORE_NEXUS_RELAY_TOKEN')) or cfg.get('relay_token') or '').strip()
            relay_url=str(cfg.get('relay_url','')).strip(); room=str(cfg.get('room_id','')).strip()
            if not cfg.get('enabled') or not relay_url.startswith('wss://') or not room or not token or 'PASTE_' in token:
                raise ConnectionError('Die Verbindung zum zentralen CORE Nexus Relay ist nicht vollständig konfiguriert.')
            import websocket
            self.controller_id='controller-'+str(uuid.uuid4())
            ws=websocket.create_connection(relay_url,timeout=10,header=[f'Authorization: Bearer {token}','X-Core-Role: controller',f'X-Core-Room: {room}'],origin=relay_url.split('/ws')[0])
            self.sock=RelayAgentSocket(ws,self.controller_id); self.file=self.sock; self.relay=True
        else:
            raise ConnectionError('CORE Nexus Relay ist nicht aktiviert.')
        self._send_raw({'type':'hello','client_role':'agent_user','username':username,**({'device_id':self.controller_id} if self.relay else {})})
        line=self.file.readline()
        if not line: self.close(); raise ConnectionError('Der Server hat die Anmeldung abgebrochen.')
        try: challenge=json.loads(line.decode('utf-8'))
        except Exception: self.close(); raise ConnectionError('Ungültige Serverantwort.')
        if not challenge.get('ok') or challenge.get('type') != 'auth_challenge':
            if not self.relay: self.sock.settimeout(None)
            self.close(); raise PermissionError('Anmeldung fehlgeschlagen. Prüfe Benutzername, Passwort und ob das Konto aktiv ist.')
        try:
            salt=base64.b64decode(challenge['salt'])
            derived=hashlib.pbkdf2_hmac('sha256',password.encode('utf-8'),salt,310_000)
            proof=hmac.new(derived,str(challenge['nonce']).encode('utf-8'),hashlib.sha256).hexdigest()
        except Exception:
            if not self.relay: self.sock.settimeout(None)
            self.close(); raise ConnectionError('Die Server-Anmeldeprüfung konnte nicht vorbereitet werden.')
        self._send_raw({'type':'agent_auth_proof','proof':proof})
        line=self.file.readline()
        if not self.relay: self.sock.settimeout(None)
        if not line: self.close(); raise ConnectionError('Der Server hat die Anmeldung abgebrochen.')
        try: reply=json.loads(line.decode('utf-8'))
        except Exception: self.close(); raise ConnectionError('Ungültige Serverantwort.')
        if not reply.get('ok') or reply.get('type') != 'agent_login_result':
            self.close(); raise PermissionError('Anmeldung fehlgeschlagen. Prüfe Benutzername, Passwort und ob das Konto aktiv ist.')
        self.username=reply.get('username',username)
        self.reader=threading.Thread(target=self._reader,daemon=True); self.reader.start()

    def _send_raw(self,obj):
        with self.send_lock:
            raw=(json.dumps(obj,separators=(',',':'))+'\n').encode('utf-8')
            if self.relay: self.sock.sendall(raw)
            else: self.file.write(raw); self.file.flush()

    def request(self,typ,timeout=8,**kwargs):
        with self.pending_lock:
            self.next_id+=1; rid=self.next_id; event=threading.Event(); holder={}; self.pending[rid]=(event,holder)
        self._send_raw({'type':typ,'request_id':rid,**kwargs})
        if not event.wait(timeout):
            with self.pending_lock: self.pending.pop(rid,None)
            raise TimeoutError('Der Server hat nicht rechtzeitig geantwortet.')
        result=holder.get('result',{})
        if not result.get('ok',False):
            errors={'permission_denied':'Dieses Konto besitzt nicht die erforderlichen Rechte.','device_offline':'Das Gerät ist offline.','device_not_approved_or_no_consent':'Das Gerät benötigt Serverfreigabe und lokale Zustimmung.','server_remote_session_busy':'Der Server verwendet die Fernsteuerung bereits.','another_admin_session_active':'Eine andere Controller-Sitzung ist aktiv.','device_not_assigned':'Dieses Gerät wurde diesem Konto nicht zugewiesen.'}
            raise PermissionError(errors.get(result.get('error'),result.get('error','Serveranfrage fehlgeschlagen.')))
        return result

    def send_input(self,device_id,command):
        if not self.closed: self._send_raw({'type':'remote_input','device_id':device_id,'command':command})

    def _reader(self):
        try:
            while not self.closed:
                line=self.file.readline()
                if not line: break
                msg=json.loads(line.decode('utf-8'))
                rid=msg.get('request_id')
                if rid is not None:
                    with self.pending_lock: pair=self.pending.pop(rid,None)
                    if pair: pair[1]['result']=msg; pair[0].set()
                else:
                    self.events.put(msg)
        except Exception as exc:
            if not self.closed: self.events.put({'type':'connection_lost','error':str(exc)})
        finally:
            if not self.closed: self.events.put({'type':'connection_lost','error':'Verbindung zum Server wurde beendet.'})

    def close(self):
        if self.closed: return
        self.closed=True
        try: self.sock.shutdown(socket.SHUT_RDWR)
        except Exception: pass
        try: self.sock.close()
        except Exception: pass


class AgentControlWindow:
    def __init__(self, agent, client, username):
        self.agent=agent; self.root=agent.root; self.client=client; self.username=username; self.device_id=None; self.remote_win=None; self.remote_label=None; self.photo=None; self.last_frame=None; self._frame_pending=False; self.frame_size=(1,1); self.display_size=(1,1); self._last_input_move=0.0; self._last_ping=time.monotonic()
        win=tk.Toplevel(self.root); self.win=win; win.title(f'CORE Nexus | Angemeldet als {username}'); win.geometry('760x520'); win.configure(bg='#060b16'); win.transient(self.root)
        body=ttk.Frame(win,padding=18); body.pack(fill='both',expand=True)
        ttk.Label(body,text='GERÄTEKONTROLLE',style='Title.TLabel').pack(anchor='w')
        ttk.Label(body,text=f'Angemeldet als {username} · Rechte werden vom Server geprüft.',style='Sub.TLabel').pack(anchor='w',pady=(2,12))
        bar=ttk.Frame(body); bar.pack(fill='x',pady=(0,8)); ttk.Button(bar,text='Geräteliste aktualisieren',command=self.refresh_devices).pack(side='left'); ttk.Button(bar,text='Fernsteuerung starten',command=self.start_remote).pack(side='left',padx=8); ttk.Button(bar,text='Fernsteuerung beenden',command=self.stop_remote).pack(side='left')
        self.status=ttk.Label(body,text='Lade freigegebene Geräte …',style='Sub.TLabel'); self.status.pack(anchor='w',pady=(0,8))
        self.tree=ttk.Treeview(body,columns=('name','online','os','ip'),show='headings',selectmode='browse')
        for col,label,width in [('name','Gerät',220),('online','Verbindung',100),('os','Betriebssystem',240),('ip','IP-Adresse',130)]: self.tree.heading(col,text=label); self.tree.column(col,width=width,anchor='w')
        self.tree.pack(fill='both',expand=True)
        win.protocol('WM_DELETE_WINDOW',self.close); self.refresh_devices(); self._poll_events()

    def refresh_devices(self):
        try:
            result=self.client.request('list_devices')
            for item in self.tree.get_children(): self.tree.delete(item)
            for d in result.get('devices',[]): self.tree.insert('', 'end', iid=d['id'], values=(d.get('name','PC'),'Online' if d.get('online') else 'Offline',d.get('os',''),d.get('ip','')))
            self.status.configure(text=f'{len(result.get("devices",[]))} freigegebene Geräte gefunden.')
        except Exception as exc: self.status.configure(text=str(exc))

    def start_remote(self):
        selected=self.tree.selection()
        if not selected: self.status.configure(text='Wähle zuerst ein Gerät aus.'); return
        did=str(selected[0])
        try:
            result=self.client.request('remote_start',device_id=did)
            self.device_id=did; self.last_frame=None; self._frame_pending=False
            self.remote_win=tk.Toplevel(self.win); self.remote_win.title('CORE Nexus | Fernsteuerung'); self.remote_win.geometry('1000x650'); self.remote_win.configure(bg='#050914')
            ttk.Label(self.remote_win,text=f'Fernsteuerung: {result.get("device_name",did)} · freigegebene Sitzung',style='Sub.TLabel').pack(anchor='w',padx=10,pady=8)
            controls=ttk.Frame(self.remote_win); controls.pack(fill='x',padx=10)
            ttk.Button(controls,text='Datei senden',command=self.send_file_to_remote).pack(side='left',padx=(0,5))
            ttk.Button(controls,text='Zwischenablage teilen',command=self.share_clipboard_to_remote).pack(side='left',padx=5)
            ttk.Button(controls,text='Nächster Monitor',command=lambda:self.client.send_input(self.device_id,{'kind':'monitor_next'})).pack(side='left',padx=5)
            self.quality_label=ttk.Label(controls,text='Verbindungsqualität: wird gemessen',style='Sub.TLabel'); self.quality_label.pack(side='left',padx=8)
            self._last_frame_at=0.0; self._frame_intervals=[]
            self.remote_label=tk.Label(self.remote_win,text='Warte auf Bildschirmbild …',bg='#050914',fg='#eaf2ff',takefocus=1,cursor='crosshair'); self.remote_label.pack(fill='both',expand=True,padx=10,pady=8)
            self.remote_label.bind('<Motion>',self.motion); self.remote_label.bind('<Button-1>',lambda e:self.click(e,'left')); self.remote_label.bind('<Button-3>',lambda e:self.click(e,'right')); self.remote_label.bind('<MouseWheel>',self.scroll); self.remote_label.bind('<KeyPress>',self.keydown); self.remote_label.bind('<KeyRelease>',self.keyup); self.remote_win.bind('<KeyPress>',self.keydown); self.remote_win.bind('<KeyRelease>',self.keyup)
            self.remote_win.protocol('WM_DELETE_WINDOW',self.stop_remote); self.remote_label.focus_set(); self.status.configure(text='Fernsteuerung aktiv. Der Server kann diese Sitzung jederzeit beenden.')
        except Exception as exc: self.status.configure(text=str(exc))

    def share_clipboard_to_remote(self):
        if not self.device_id: return
        try: content=self.agent.root.clipboard_get()
        except Exception:
            messagebox.showwarning(APP,'Die lokale Zwischenablage enthält keinen lesbaren Text.',parent=self.remote_win); return
        if len(content)>20000:
            messagebox.showwarning(APP,'Die Zwischenablage ist auf 20.000 Zeichen begrenzt.',parent=self.remote_win); return
        if not messagebox.askyesno(APP,f'{len(content)} Zeichen an das Zielgerät übertragen?',parent=self.remote_win): return
        self.client.send_input(self.device_id,{'kind':'clipboard_text','text':content})

    def send_file_to_remote(self):
        if not self.device_id: return
        from tkinter import filedialog
        import os
        path=filedialog.askopenfilename(parent=self.remote_win,title='Datei an Zielgerät senden')
        if not path: return
        try:
            size=os.path.getsize(path)
            if size>2*1024*1024:
                messagebox.showwarning(APP,'Maximal 2 MiB pro Datei.',parent=self.remote_win); return
            with open(path,'rb') as f: data=f.read()
            name=os.path.basename(path).replace('\\','_').replace('/','_')[:180]
            if not messagebox.askyesno(APP,f'Datei „{name}“ ({size} Bytes) senden?',parent=self.remote_win): return
            encoded=base64.b64encode(data).decode('ascii'); chunk_size=24000; tid=str(uuid.uuid4()); total=(len(encoded)+chunk_size-1)//chunk_size
            self.client.send_input(self.device_id,{'kind':'file_begin','transfer_id':tid,'name':name,'chunks':total})
            for i in range(total): self.client.send_input(self.device_id,{'kind':'file_chunk','transfer_id':tid,'index':i,'data':encoded[i*chunk_size:(i+1)*chunk_size]})
            self.client.send_input(self.device_id,{'kind':'file_end','transfer_id':tid})
            messagebox.showinfo(APP,'Dateiübertragung eingereiht. Zielgerät muss online bleiben.',parent=self.remote_win)
        except Exception as exc: messagebox.showerror(APP,f'Dateiübertragung fehlgeschlagen: {exc}',parent=self.remote_win)

    def stop_remote(self):
        if self.device_id:
            try: self.client.request('remote_stop',device_id=self.device_id,timeout=3)
            except Exception: pass
        self.device_id=None; self.photo=None; self.remote_label=None
        if self.remote_win is not None:
            try: self.remote_win.destroy()
            except tk.TclError: pass
            self.remote_win=None
        if hasattr(self,'status'):
            try: self.status.configure(text='Fernsteuerung beendet.')
            except tk.TclError: pass

    def _coords(self,e):
        w=max(1,self.remote_label.winfo_width()); h=max(1,self.remote_label.winfo_height()); sw,sh=self.display_size; iw,ih=self.frame_size
        ox=(w-sw)/2; oy=(h-sh)/2
        return (min(max(0,round((e.x-ox)*iw/max(1,sw))),iw-1),min(max(0,round((e.y-oy)*ih/max(1,sh))),ih-1))
    def motion(self,e):
        now=time.monotonic()
        if now-self._last_input_move<0.025:return
        self._last_input_move=now; x,y=self._coords(e); self.client.send_input(self.device_id,{'kind':'move','x':x,'y':y})
    def click(self,e,b):
        self.remote_label.focus_set(); x,y=self._coords(e); self.client.send_input(self.device_id,{'kind':'click','x':x,'y':y,'button':b})
    def scroll(self,e):
        x,y=self._coords(e); self.client.send_input(self.device_id,{'kind':'scroll','x':x,'y':y,'dy':1 if e.delta>0 else -1})
    def keydown(self,e):
        if not self.device_id:return
        names={'Return':'enter','Tab':'tab','Escape':'esc','BackSpace':'backspace','Delete':'delete','space':'space','Up':'up','Down':'down','Left':'left','Right':'right','Shift_L':'shift','Control_L':'ctrl','Alt_L':'alt','Super_L':'win'}
        key=names.get(e.keysym,e.keysym.lower() if e.keysym.lower().startswith('f') and e.keysym[1:].isdigit() else (e.char if e.char and e.char.isprintable() else ''))
        if key:self.client.send_input(self.device_id,{'kind':'key','key':key,'action':'down' if key in ('shift','ctrl','alt','win') else 'press'})
    def keyup(self,e):
        if not self.device_id:return
        names={'Shift_L':'shift','Control_L':'ctrl','Alt_L':'alt','Super_L':'win'}; key=names.get(e.keysym)
        if key:self.client.send_input(self.device_id,{'kind':'key','key':key,'action':'up'})

    def _poll_events(self):
        if not self.win.winfo_exists(): return
        if time.monotonic()-self._last_ping >= 8:
            try: self.client._send_raw({'type':'ping'})
            except Exception: pass
            self._last_ping=time.monotonic()
        try:
            while True:
                msg=self.client.events.get_nowait(); typ=msg.get('type')
                if typ=='frame' and self.device_id and msg.get('device_id')==self.device_id:
                    now=time.monotonic()
                    if self._last_frame_at:
                        self._frame_intervals.append(now-self._last_frame_at); self._frame_intervals=self._frame_intervals[-12:]
                        avg=sum(self._frame_intervals)/len(self._frame_intervals); quality='Gut' if avg<0.35 else ('Mittel' if avg<0.8 else 'Schwach')
                        try: self.quality_label.configure(text=f'Bildrate: {1/max(avg,0.01):.1f} FPS · Qualität: {quality}')
                        except Exception: pass
                    self._last_frame_at=now
                    try:
                        self.last_frame=base64.b64decode(msg.get('frame',''))
                        self._frame_pending=True
                    except Exception: pass
                elif typ=='remote_forced_stop': self.stop_remote(); self.status.configure(text='Die Fernsteuerung wurde durch den Server beendet.')
                elif typ=='connection_lost': self.stop_remote(); self.status.configure(text='Serververbindung verloren: '+str(msg.get('error','')))
        except queue.Empty: pass
        if self.remote_label is not None and self.last_frame and self._frame_pending:
            try:
                from PIL import Image, ImageTk
                im=Image.open(io.BytesIO(self.last_frame)); self.frame_size=im.size
                im.thumbnail((max(1,self.remote_label.winfo_width()),max(1,self.remote_label.winfo_height())))
                self.display_size=im.size; self.photo=ImageTk.PhotoImage(im); self.remote_label.configure(image=self.photo,text=''); self._frame_pending=False
            except Exception as exc: self.remote_label.configure(text=f'Bild konnte nicht angezeigt werden: {exc}'); self._frame_pending=False
        self.win.after(80,self._poll_events)

    def close(self):
        self.stop_remote(); self.client.close()
        try:self.win.destroy()
        except tk.TclError:pass


if __name__=='__main__':
    if ensure_room_id():
        app = Agent()
        app.root.mainloop()
