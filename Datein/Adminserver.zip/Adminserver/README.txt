﻿CORE NEXUS ADMINSERVER – ZENTRALES ROOT-KONTO UND SERVERERSTELLUNG
================================================================

ZENTRALES ADMIN-KONTO AUF RENDER
1. In Render > CORE Nexus Relay > Environment sicherstellen:
   CORE_NEXUS_ROOT_USERNAME = gewünschter Root-Benutzername (render.yaml setzt core-owner als Standard)
   CORE_NEXUS_ROOT_PASSWORD = langes, geheimes Passwort
2. Nach Änderungen den Render-Service neu bereitstellen.
3. Adminserver starten und mit genau diesen Daten anmelden. Das Passwort wird nicht lokal gespeichert. Die Render-Sitzung läuft nach 8 Stunden ab.
4. Das Relay-Token (CORE_NEXUS_RELAY_TOKEN) und einen langen Service-Admin-Token im Menü Verbindungseinstellungen setzen. Diese dienen nur der Serverkommunikation, nicht der Root-Anmeldung.

NEUEN SERVER ERSTELLEN
1. Mit dem zentralen Root-Konto anmelden.
2. „Neuen Server erstellen“ anklicken.
3. Servernamen und Owner-Benutzername festlegen sowie ein Passwort mit mindestens 12 Zeichen zweimal eingeben.
4. Das ZIP-Paket wird lokal in Adminserver/created_servers/ erstellt.
5. ZIP auf dem gewünschten Windows-PC entpacken, Server/setup.bat ausführen und danach Server/start.bat starten.
6. Beim ersten Start legt der Server den Owner anhand eines Passwort-Hashes in seiner lokalen SQLite-Datenbank an. Das Klartext-Passwort wird nicht im ZIP gespeichert.
7. Die neue Raum-ID wird automatisch über Render erkannt, sobald der Server verbunden ist.

HINWEISE
- Jeder Server erhält eine eigene Raum-ID.
- Der Server-Owner verwaltet nur den jeweiligen Server. Das zentrale Root-Konto bleibt die oberste Ebene.
- Die Serverpakete enthalten den Relay-Token und Service-Admin-Token, weil sie für den Betrieb gebraucht werden. Schütze die ZIP-Datei und lade sie niemals in ein öffentliches GitHub-Repository hoch.
- Das Relay vermittelt Verbindungen, ist aber keine Ende-zu-Ende-Verschlüsselung der Anwendungsnachrichten.
- LAN-Kommunikation bleibt lokal möglich; über verschiedene Netzwerke ist Render erforderlich.
