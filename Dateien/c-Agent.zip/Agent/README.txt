CORE NEXUS AGENT – INTERNET-RELAY
1. Agent-Ordner auf den Ziel-PC kopieren.
2. In relay_config.json relay_url, relay_token und room_id wie in Server/relay_config.json setzen. enabled muss true sein.
3. install.bat ausführen, danach start.bat.
4. Beim ersten Start lokale Zustimmung erteilen. Anschließend das Gerät im Server-Dashboard ausdrücklich freigeben.
5. Die Fernsteuerung startet nur, wenn am Server eine Sitzung explizit geöffnet wurde.
Wichtig: relay_config.json enthält das geheime Token. Nicht in GitHub veröffentlichen.


VERBINDUNGSVERHALTEN (LAN + RENDER)
-----------------------------------
Der Agent versucht zuerst automatisch, einen CORE-Nexus-Server im selben LAN zu finden.
Wenn kein LAN-Server gefunden oder erreicht wird, verwendet er relay_config.json und den Render-Relay (falls enabled=true und korrekt konfiguriert).
Damit bleibt der lokale Verkehr im lokalen Netzwerk und Render wird nur als Fallback fuer andere Netzwerke genutzt.
Server und Agent muessen fuer den Relay dieselbe room_id und dasselbe Token verwenden.
Die relay_url muss auf den eigenen Render-Dienst zeigen, z.B. wss://DEIN-DIENST.onrender.com/ws.

Automatische Wiederverbindung:
Wenn keine Verbindung zum CORE Nexus Server besteht, sucht der Agent automatisch jede Minute erneut. Zuerst wird das lokale Netzwerk (LAN) per UDP-Erkennung geprüft; wenn dort kein Server erreichbar ist, wird das konfigurierte Render-Relay als Fallback versucht. Die Suche benötigt keine manuelle Bestätigung. Der Button „Erneut verbinden“ bleibt zusätzlich verfügbar.
