@echo off
setlocal EnableExtensions
cd /d "%~dp0"
chcp 65001 >nul
title CORE Nexus Adminserver - Diagnose
echo ========================================
echo CORE Nexus Adminserver - Diagnosemodus
echo ========================================
echo Dieses Fenster offen lassen und Fehlermeldungen kopieren.
echo.
where py >nul 2>&1
if not errorlevel 1 (py -3 adminserver.py) else (python adminserver.py)
echo.
echo Adminserver wurde beendet. Exitcode: %errorlevel%
pause
