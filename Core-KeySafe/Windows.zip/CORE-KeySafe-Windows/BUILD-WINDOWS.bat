@echo off
setlocal
cd /d "%~dp0"
echo ========================================
echo CORE KeySafe - Windows Build
echo ========================================
where py >nul 2>nul
if errorlevel 1 (
  echo Python Launcher (py) wurde nicht gefunden. Installiere Python 3.11 oder 3.12 von python.org.
  pause
  exit /b 1
)
py -3.12 -m venv .venv
if errorlevel 1 py -3.11 -m venv .venv
if errorlevel 1 (
  echo Konnte virtuelle Umgebung nicht erstellen.
  pause
  exit /b 1
)
call .venv\Scripts\activate.bat
python -m pip install --upgrade pip
pip install -r desktop\requirements.txt
pip install pyinstaller
if errorlevel 1 goto fail
pyinstaller --noconfirm --clean --windowed --name "CORE KeySafe" --paths desktop desktop\main.py
if errorlevel 1 goto fail
echo.
echo Build fertig. Programmordner: dist\CORE KeySafe\
echo Hinweis: Vor dem Build config.py mit Render-URL und oeffentlichem Signaturschluessel konfigurieren.
pause
exit /b 0
:fail
echo Build fehlgeschlagen. Fehlermeldungen oben pruefen.
pause
exit /b 1
