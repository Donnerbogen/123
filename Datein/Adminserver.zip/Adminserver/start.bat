@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title CORE Nexus Adminserver
rem Strictly require Python 3.15. No other Python version is accepted.
where py >nul 2>&1
if not errorlevel 1 (
  pyw -V:3.15 -c "import sys; raise SystemExit(0 if sys.version_info[:2] == (3,15) else 1)" >nul 2>&1
  if not errorlevel 1 (
    start "CORE Nexus Adminserver" pyw -V:3.15 "%~dp0adminserver.py"
    exit /b 0
  )
  py -V:3.15 -c "import sys; raise SystemExit(0 if sys.version_info[:2] == (3,15) else 1)" >nul 2>&1
  if not errorlevel 1 (
    start "CORE Nexus Adminserver" py -V:3.15 "%~dp0adminserver.py"
    exit /b 0
  )
)
set "PYW="
for /f "delims=" %%P in ('where pythonw 2^>nul') do if not defined PYW set "PYW=%%P"
if defined PYW (
  "%PYW%" -c "import sys; raise SystemExit(0 if sys.version_info[:2] == (3,15) else 1)" >nul 2>&1
  if not errorlevel 1 (
    start "CORE Nexus Adminserver" "%PYW%" "%~dp0adminserver.py"
    exit /b 0
  )
)
set "PY="
where python >nul 2>&1
if not errorlevel 1 (
  python -c "import sys; raise SystemExit(0 if sys.version_info[:2] == (3,15) else 1)" >nul 2>&1
  if not errorlevel 1 set "PY=python"
)
if defined PY (
  start "CORE Nexus Adminserver" %PY% "%~dp0adminserver.py"
  exit /b 0
)
echo FEHLER: Python 3.15 wurde nicht gefunden.
echo CORE Nexus verwendet absichtlich keine andere Python-Version.
echo Windows Server 2019: Python Install Manager per MSI installieren, danach "py install 3.15" ausfuehren. Python 3.15 x64 mit Tcl/Tk und pip benoetigt.
pause
exit /b 1
