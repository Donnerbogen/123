@echo off
setlocal EnableExtensions
chcp 65001 >nul
pushd "%~dp0" || (echo ERROR: Agent folder could not be opened.& pause & exit /b 1)
title CORE Nexus Agent - Verwaltung

:menu
cls
echo ============================================
echo       CORE Nexus Agent - VERWALTUNG
echo ============================================
echo.
echo   [1] Install / repair and enable autostart
echo   [2] Uninstall
 echo  [3] Enable autostart only
 echo  [4] Disable autostart only
 echo  [5] Exit
echo.
choice /C 12345 /N /M "Select [1-5]: "
if errorlevel 5 goto cancel
if errorlevel 4 goto disable_startup
if errorlevel 3 goto enable_startup
if errorlevel 2 goto uninstall
if errorlevel 1 goto install

:install
cls
title CORE Nexus Agent - Installation
echo ============================================
echo       CORE Nexus Agent - INSTALLATION
echo ============================================
echo.
echo Agent folder: %CD%
where py >nul 2>&1
if not errorlevel 1 (
  set "PY=py -3.15"
) else (
  where python >nul 2>&1
  if errorlevel 1 (
    echo ERROR: Python was not found.
    echo Install Python 3.15.0 from https://www.python.org/downloads/release/python-3150/
    pause
    goto menu
  )
  set "PY=python"
)
%PY% --version
if errorlevel 1 (
  echo ERROR: Python 3.15 could not be started. Install Python 3.15.0 exactly.
  pause
  goto menu
)
%PY% -c "import sys; raise SystemExit(0 if sys.version_info[:3] == (3,15,0) else 1)"
if errorlevel 1 (
  echo ERROR: This agent requires Python 3.15.0 exactly. Python 3.15.1 and other versions are not supported by this package.
  pause
  goto menu
)
%PY% -c "import tkinter; print('Tkinter OK')" >nul 2>&1
if errorlevel 1 (
  echo ERROR: Python Tkinter is missing. Reinstall Python with Tcl/Tk support.
  pause
  goto menu
)
if not exist "%~dp0agent.py" (
  echo ERROR: agent.py is missing from this Agent folder.
  pause
  goto menu
)
%PY% -m pip install --disable-pip-version-check --upgrade pillow mss pynput pyperclip websocket-client cryptography
if errorlevel 1 (
  echo ERROR: Dependencies could not be installed. Check the Internet connection.
  pause
  goto menu
)
%PY% -m py_compile "%~dp0agent.py"
if errorlevel 1 (
  echo ERROR: agent.py has a syntax error. Installation stopped.
  pause
  goto menu
)
if not exist "%~dp0data" mkdir "%~dp0data"
if errorlevel 1 (
  echo ERROR: Cannot create data folder in %CD%.
  pause
  goto menu
)
>"%~dp0installed.flag" echo CORE Nexus installed on %DATE% %TIME%
if errorlevel 1 (
  echo ERROR: Cannot write installed.flag in %CD%.
  pause
  goto menu
)
echo.
echo Installation completed. Enabling autostart...
call :enable_startup_action
if errorlevel 1 (
  echo WARNING: Installation succeeded, but autostart could not be enabled.
  pause
  goto menu
)
echo.
echo Done. CORE Nexus Agent will start at the next Windows sign-in.
echo Use start.bat to launch it now.
echo.
pause
goto menu

:enable_startup
if not exist "%~dp0installed.flag" (
  echo.
  echo CORE Nexus Agent is not installed. Choose option 1 first.
  pause
  goto menu
)
call :enable_startup_action
if errorlevel 1 pause
goto menu

:enable_startup_action
set "START_FILE=%~dp0start.bat"
powershell -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='Stop'; $ws=New-Object -ComObject WScript.Shell; $startup=Join-Path $env:APPDATA 'Microsoft\Windows\Start Menu\Programs\Startup'; if (!(Test-Path $startup)) { New-Item -ItemType Directory -Path $startup -Force | Out-Null }; $link=$ws.CreateShortcut((Join-Path $startup 'CORE Nexus Agent.lnk')); $link.TargetPath=$env:START_FILE; $link.WorkingDirectory=(Split-Path -Parent $env:START_FILE); $link.WindowStyle=7; $link.Description='CORE Nexus Agent at Windows sign-in'; $link.Save()"
if errorlevel 1 (
  echo ERROR: Autostart could not be configured.
  exit /b 1
)
echo Autostart enabled.
exit /b 0

:disable_startup
set "LINK=%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup\CORE Nexus Agent.lnk"
if exist "%LINK%" (del /q "%LINK%" & echo Autostart disabled.) else echo No autostart entry found.
echo.
pause
goto menu

:uninstall
cls
echo This removes the autostart shortcut and installed.flag.
choice /C JN /N /M "Delete local application data too? [J/N]: "
if errorlevel 2 goto keepdata
if errorlevel 1 goto deletedata
goto cleanup
:deletedata
if exist "%~dp0data" rmdir /s /q "%~dp0data"
if exist "%~dp0device_id.json" del /q "%~dp0device_id.json"
if exist "%~dp0consent.json" del /q "%~dp0consent.json"
goto cleanup
:keepdata
echo Local data will be kept.
:cleanup
set "LINK=%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup\CORE Nexus Agent.lnk"
if exist "%LINK%" del /q "%LINK%"
if exist "%~dp0__pycache__" rmdir /s /q "%~dp0__pycache__"
if exist "%~dp0installed.flag" del /q "%~dp0installed.flag"
echo Uninstallation completed. The program files were not deleted.
pause
goto menu

:cancel
echo Cancelled.
exit /b 0
