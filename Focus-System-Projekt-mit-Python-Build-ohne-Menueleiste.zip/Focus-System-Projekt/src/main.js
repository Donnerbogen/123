
const {
  app,
  BrowserWindow,
  ipcMain,
  Tray,
  Menu,
  nativeImage,
  Notification
} = require("electron");

const path = require("path");
const fs = require("fs");
const { execFile } = require("child_process");

const APP_DIR = app.isPackaged
  ? path.dirname(process.execPath)
  : path.resolve(__dirname, "..");

const CONFIG_PATH = path.join(APP_DIR, "config.json");
const LOG_PATH = path.join(APP_DIR, "focus.log");

let win = null;
let tray = null;
let enforcementTimer = null;
let schedulerTimer = null;
let session = null;
let quitting = false;

const defaultConfig = () => ({
  password: null,
  categories: [],
  settings: {
    enforcementIntervalMs: 1200
  },
  schedule: {
    categoryId: null,
    startAt: null,
    endAt: null,
    durationMinutes: null,
    completed: false,
    notified: []
  }
});

function log(message) {
  const line = `[${new Date().toISOString()}] ${message}\n`;

  try {
    fs.appendFileSync(LOG_PATH, line, "utf8");
  } catch {}
}

function readConfig() {
  try {
    const saved = JSON.parse(
      fs.readFileSync(CONFIG_PATH, "utf8")
    );

    return {
      ...defaultConfig(),
      ...saved
    };
  } catch {
    return defaultConfig();
  }
}

let config = readConfig();

function saveConfig() {
  try {
    fs.writeFileSync(
      CONFIG_PATH,
      JSON.stringify(config, null, 2),
      "utf8"
    );
  } catch (error) {
    log(`Konfiguration konnte nicht gespeichert werden: ${error.message}`);
  }
}

function notify(message) {
  if (Notification.isSupported()) {
    new Notification({
      title: "Focus System",
      body: message,
      silent: false
    }).show();
  }

  if (win && !win.isDestroyed()) {
    win.webContents.send("notice", message);
  }
}

function publicState() {
  return {
    needsSetup: !config.password,
    categories: config.categories,
    schedule: config.schedule,
    active: Boolean(session),
    activeCategoryId: session?.categoryId || null,
    activeStartedAt: session?.startedAt || null,
    activeUntil: session?.until || null
  };
}

function broadcast() {
  if (win && !win.isDestroyed()) {
    win.webContents.send("state:update", publicState());
  }
}

function ensureMainWindow() {
  if (win && !win.isDestroyed()) {
    return win;
  }

  win = new BrowserWindow({
    width: 1120,
    height: 780,
    minWidth: 850,
    minHeight: 620,
    backgroundColor: "#080d18",
    show: false,
    autoHideMenuBar: true,
    webPreferences: {
      preload: path.join(__dirname, "preload.js"),
      contextIsolation: true,
      nodeIntegration: false
    }
  });

  win.setMenuBarVisibility(false);
  win.removeMenu();

  win.loadFile(path.join(__dirname, "index.html"));

  win.once("ready-to-show", () => {
    win.show();
  });

  win.on("close", (event) => {
    if (!quitting) {
      event.preventDefault();
      win.hide();
    }
  });

  win.on("closed", () => {
    win = null;
  });

  return win;
}

function openMainWindow() {
  const window = ensureMainWindow();

  if (window.isMinimized()) {
    window.restore();
  }

  window.show();
  window.focus();

  return window;
}

function requestStopFocus() {
  const window = openMainWindow();

  if (session) {
    window.webContents.send("focus:stop-request");
  }
}

function createTray() {
  try {
    const png = Buffer.from(
      "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+jWQAAAABJRU5ErkJggg==",
      "base64"
    );

    tray = new Tray(
      nativeImage.createFromBuffer(png)
    );

    tray.setToolTip("Focus System");

    tray.setContextMenu(
      Menu.buildFromTemplate([
        {
          label: "Focus System öffnen",
          click: () => openMainWindow()
        },
        {
          label: "Fokusmodus beenden",
          click: () => requestStopFocus()
        },
        {
          type: "separator"
        },
        {
          label: "Vollständig beenden",
          click: () => {
            if (session) {
              requestStopFocus();

              notify(
                "Beende zuerst den Fokusmodus mit deinem Masterpasswort."
              );

              return;
            }

            quitting = true;
            app.quit();
          }
        }
      ])
    );

    tray.on("double-click", () => {
      openMainWindow();
    });

  } catch (error) {
    log(`Tray konnte nicht erstellt werden: ${error.message}`);
  }
}

function powershell(scriptArgs) {
  const script = app.isPackaged
    ? path.join(
        process.resourcesPath,
        "app.asar.unpacked",
        "src",
        "window-control.ps1"
      )
    : path.join(__dirname, "window-control.ps1");

  return new Promise((resolve) => {
    execFile(
      "powershell.exe",
      [
        "-NoProfile",
        "-ExecutionPolicy",
        "Bypass",
        "-File",
        script,
        ...scriptArgs
      ],
      {
        windowsHide: true,
        timeout: 12000
      },
      (error, stdout) => {
        resolve(error ? "" : String(stdout || ""));
      }
    );
  });
}

async function enforceWindows() {
  if (!session) return;

  const allowed = new Set();

  const category = config.categories.find(
    item => item.id === session.categoryId
  );

  for (const program of category?.programs || []) {
    try {
      allowed.add(
        path.resolve(program).toLowerCase()
      );
    } catch {}
  }

  await powershell([
    "enforce",
    JSON.stringify([...allowed]),
    "focus",
    String(process.pid)
  ]);
}

function startEnforcement() {
  clearInterval(enforcementTimer);

  const interval = Math.max(
    500,
    Number(config.settings?.enforcementIntervalMs) || 1200
  );

  enforcementTimer = setInterval(() => {
    if (!session) return;

    enforceWindows();
  }, interval);
}

function startFocus(categoryId, fromSchedule = false) {
  if (session) {
    return false;
  }

  const category = config.categories.find(
    item => item.id === categoryId
  );

  if (!category) {
    notify("Die ausgewählte Kategorie existiert nicht.");
    return false;
  }

  const now = Date.now();
  const schedule = config.schedule || {};

  let until = null;

  if (
    fromSchedule ||
    schedule.categoryId === categoryId
  ) {
    const candidates = [];

    if (schedule.endAt) {
      const end = new Date(
        schedule.endAt
      ).getTime();

      if (
        Number.isFinite(end) &&
        end > now
      ) {
        candidates.push(end);
      }
    }

    if (schedule.durationMinutes) {
      const duration = Number(
        schedule.durationMinutes
      );

      if (
        Number.isFinite(duration) &&
        duration > 0
      ) {
        candidates.push(
          now + duration * 60000
        );
      }
    }

    if (candidates.length) {
      until = Math.min(...candidates);
    }
  }

  session = {
    categoryId,
    startedAt: now,
    until
  };

  log(`Fokusmodus gestartet: ${category.name}`);

  notify(`Fokusmodus gestartet: ${category.name}`);

  broadcast();

  return true;
}

function stopFocus(reason = "manual") {
  if (!session) return;

  const category = config.categories.find(
    item => item.id === session.categoryId
  );

  log(
    `Fokusmodus beendet: ${category?.name || "Kategorie"} (${reason})`
  );

  session = null;

  if (config.schedule) {
    config.schedule.completed = true;
    saveConfig();
  }

  notify("Der Fokusmodus wurde beendet.");

  broadcast();
}

function checkSchedule() {
  const schedule = config.schedule || {};

  if (
    !schedule.completed &&
    schedule.startAt &&
    !session
  ) {
    const start = new Date(
      schedule.startAt
    ).getTime();

    const remaining = start - Date.now();

    for (const minutes of [5, 3, 2, 1]) {
      const threshold = minutes * 60000;

      if (
        remaining > 0 &&
        remaining <= threshold &&
        remaining > threshold - 60000 &&
        !(schedule.notified || []).includes(minutes)
      ) {
        schedule.notified = [
          ...(schedule.notified || []),
          minutes
        ];

        saveConfig();

        notify(
          `Dein Fokusmodus startet in ${minutes} Minute${minutes === 1 ? "" : "n"}.`
        );
      }
    }

    if (
      Number.isFinite(start) &&
      remaining <= 0
    ) {
      schedule.completed = true;
      saveConfig();

      if (!startFocus(schedule.categoryId, true)) {
        notify(
          "Der geplante Fokusmodus konnte nicht gestartet werden."
        );
      }
    }
  }

  if (
    session?.until &&
    Date.now() >= session.until
  ) {
    stopFocus("Zeit abgelaufen");
  }
}

/* ---------------- APP START ---------------- */

app.whenReady().then(() => {
  Menu.setApplicationMenu(null);

  ensureMainWindow();
  createTray();
  startEnforcement();

  schedulerTimer = setInterval(
    checkSchedule,
    500
  );

  app.on("activate", () => {
    openMainWindow();
  });
});

app.on("before-quit", (event) => {
  if (session && !quitting) {
    event.preventDefault();
    requestStopFocus();
  }
});

app.on("window-all-closed", () => {
  // Die Anwendung bleibt im Tray verfügbar.
});

/* ---------------- STATE ---------------- */

ipcMain.handle("state:get", () => {
  return publicState();
});

/* ---------------- PASSWORD ---------------- */

ipcMain.handle(
  "password:setup",
  (_event, password) => {
    if (config.password) {
      return {
        ok: false,
        message: "Ein Hauptpasswort ist bereits eingerichtet."
      };
    }

    if (
      typeof password !== "string" ||
      !password.length
    ) {
      return {
        ok: false,
        message: "Bitte ein Passwort eingeben."
      };
    }

    config.password = password;

    saveConfig();

    log("Hauptpasswort erstmalig eingerichtet.");

    return { ok: true };
  }
);

ipcMain.handle(
  "password:login",
  (_event, password) => {
    return {
      ok: password === config.password
    };
  }
);

ipcMain.handle(
  "password:change",
  (_event, oldPassword, newPassword) => {
    if (oldPassword !== config.password) {
      return {
        ok: false,
        message: "Das bisherige Passwort ist falsch."
      };
    }

    if (
      typeof newPassword !== "string" ||
      !newPassword.length
    ) {
      return {
        ok: false,
        message: "Neues Passwort fehlt."
      };
    }

    config.password = newPassword;

    saveConfig();

    log("Hauptpasswort geändert.");

    return { ok: true };
  }
);

/* ---------------- CATEGORIES ---------------- */

ipcMain.handle(
  "categories:save",
  (_event, categories) => {
    if (!Array.isArray(categories)) {
      return { ok: false };
    }

    config.categories = categories.map(category => ({
      id: String(category.id),
      name: String(
        category.name || "Neue Kategorie"
      ),
      programs: Array.isArray(category.programs)
        ? category.programs.map(String)
        : []
    }));

    saveConfig();
    broadcast();

    return { ok: true };
  }
);

/* ---------------- FOCUS ---------------- */

ipcMain.handle(
  "focus:start",
  (_event, categoryId) => {
    if (session) {
      return {
        ok: false,
        message: "Es läuft bereits ein Fokusmodus."
      };
    }

    return {
      ok: startFocus(String(categoryId))
    };
  }
);

ipcMain.handle(
  "focus:stop",
  (_event, masterPassword) => {
    if (!session) {
      return {
        ok: false,
        message: "Es ist kein Fokusmodus aktiv."
      };
    }

    if (masterPassword !== config.password) {
      log(
        "Fehlgeschlagener Versuch, den Fokusmodus zu beenden."
      );

      return {
        ok: false,
        message: "Das Masterpasswort ist falsch."
      };
    }

    stopFocus("Masterpasswort bestätigt");

    return { ok: true };
  }
);

/* ---------------- SCHEDULE ---------------- */

ipcMain.handle(
  "schedule:save",
  (_event, schedule) => {
    const startAt = schedule.startAt || null;
    const endAt = schedule.endAt || null;

    if (
      startAt &&
      endAt &&
      new Date(endAt) <= new Date(startAt)
    ) {
      return {
        ok: false,
        message: "Die Endzeit muss nach der Startzeit liegen."
      };
    }

    config.schedule = {
      categoryId: schedule.categoryId || null,
      startAt,
      endAt,
      durationMinutes: schedule.durationMinutes
        ? Math.max(
            1,
            Number(schedule.durationMinutes)
          )
        : null,
      completed: false,
      notified: []
    };

    saveConfig();

    notify("Zeitplanung gespeichert.");

    broadcast();

    return { ok: true };
  }
);

/* ---------------- RUNNING PROGRAMS ---------------- */

ipcMain.handle(
  "apps:running",
  async () => {
    const raw = await powershell(["list"]);

    try {
      const parsed = JSON.parse(raw || "[]");

      if (Array.isArray(parsed)) {
        return parsed;
      }

      return parsed ? [parsed] : [];
    } catch {
      return [];
    }
  }
);

ipcMain.handle(
  "program:add",
  (_event, categoryId, exePath) => {
    const category = config.categories.find(
      item => item.id === categoryId
    );

    if (!category || !exePath) {
      return { ok: false };
    }

    if (!category.programs.includes(exePath)) {
      category.programs.push(exePath);
    }

    saveConfig();
    broadcast();

    return { ok: true };
  }
);

ipcMain.handle(
  "program:remove",
  (_event, categoryId, exePath) => {
    const category = config.categories.find(
      item => item.id === categoryId
    );

    if (!category) {
      return { ok: false };
    }

    category.programs = category.programs.filter(
      item => item !== exePath
    );

    saveConfig();
    broadcast();

    return { ok: true };
  }
);

/* ---------------- WINDOW CONTROLS ---------------- */

ipcMain.on("window:minimize", () => {
  if (win && !win.isDestroyed()) {
    win.minimize();
  }
});

ipcMain.on("window:hide", () => {
  if (win && !win.isDestroyed()) {
    win.hide();
  }
});

