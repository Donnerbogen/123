@echo off
setlocal EnableExtensions
chcp 65001 >nul
pushd "%~dp0"
title CORE Nexus Agent
if not exist "installed.flag" (
  echo CORE Nexus Agent ist noch nicht installiert.
  echo Bitte zuerst install.bat ausfuehren.
  pause
  popd
  exit /b 1
)
set "PYW="
where pyw >nul 2>&1
if not errorlevel 1 (
  start "CORE Nexus Agent" /B pyw -3 "%~dp0agent.py"
  popd
  exit /b 0
)
for /f "delims=" %%P in ('where pythonw 2^>nul') do if not defined PYW set "PYW=%%P"
if defined PYW (
  start "CORE Nexus Agent" "%PYW%" "%~dp0agent.py"
  popd
  exit /b 0
)
echo FEHLER: pythonw/pyw wurde nicht gefunden.
echo Bitte Python erneut installieren und den Python Launcher aktivieren.
pause
popd
exit /b 1
