"""Owner maintenance utility: clears the persistent global close-agent flag.
Run on the server PC: python reset_agent_lock.py
This only resets the dashboard lock flag; it does not launch agents on client PCs.
"""
import sqlite3
from pathlib import Path
p=Path(__file__).resolve().parent/'data'/'core_nexus.sqlite3'
if not p.exists():
    print('Keine CORE Nexus Datenbank gefunden. Starte zuerst Server/server.py.'); raise SystemExit(1)
with sqlite3.connect(p) as db:
    db.execute("INSERT INTO settings(key,value) VALUES('close_agents','0') ON CONFLICT(key) DO UPDATE SET value='0'")
print('Globaler Agenten-Schließstatus zurückgesetzt.')
