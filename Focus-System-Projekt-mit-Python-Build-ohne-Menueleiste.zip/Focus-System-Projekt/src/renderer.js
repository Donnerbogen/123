const $ = id => document.getElementById(id);

let state = null;
let authenticated = false;
let toastTimer = null;
let countdownTimer = null;

const uid = () =>
  crypto.randomUUID
    ? crypto.randomUUID()
    : String(Date.now()) + Math.random();

function toast(message) {
  const element = $("toast");

  element.textContent = message;
  element.classList.add("show");

  clearTimeout(toastTimer);

  toastTimer = setTimeout(() => {
    element.classList.remove("show");
  }, 3000);
}

function show(id) {
  [
    "setupView",
    "loginView",
    "dashboard",
    "focusView"
  ].forEach(view => {
    $(view).classList.add("hidden");
  });

  $(id).classList.remove("hidden");
}

function localInput(iso) {
  if (!iso) return "";

  const date = new Date(iso);
  const p = value => String(value).padStart(2, "0");

  return (
    `${date.getFullYear()}-` +
    `${p(date.getMonth() + 1)}-` +
    `${p(date.getDate())}T` +
    `${p(date.getHours())}:` +
    `${p(date.getMinutes())}`
  );
}

function fromInput(value) {
  return value ? new Date(value).toISOString() : null;
}

async function refresh() {
  state = await window.focusAPI.getState();

  if (state.active) {
    show("focusView");
    renderFocus();
    return;
  }

  clearInterval(countdownTimer);

  if (state.needsSetup) {
    show("setupView");
    return;
  }

  if (!authenticated) {
    show("loginView");
    return;
  }

  show("dashboard");
  renderDashboard();
}

function getActiveCategory() {
  return state.categories.find(
    category => category.id === state.activeCategoryId
  );
}

function formatRemaining(milliseconds) {
  if (milliseconds <= 0) {
    return "00:00:00";
  }

  const totalSeconds = Math.ceil(milliseconds / 1000);

  const hours = Math.floor(totalSeconds / 3600);
  const minutes = Math.floor((totalSeconds % 3600) / 60);
  const seconds = totalSeconds % 60;

  const p = value => String(value).padStart(2, "0");

  return `${p(hours)}:${p(minutes)}:${p(seconds)}`;
}

function renderFocus() {
  if (!state || !state.active) return;

  const category = getActiveCategory();

  $("focusCategory").textContent =
    category?.name || "Fokusmodus";

  if (state.activeUntil) {
    const remaining = state.activeUntil - Date.now();

    $("focusRemaining").textContent =
      formatRemaining(remaining);

    $("focusTimeLabel").textContent =
      "VERBLEIBENDE ZEIT";
  } else {
    $("focusRemaining").textContent = "∞";

    $("focusTimeLabel").textContent =
      "MANUELLER FOKUSMODUS";
  }

  $("focusStarted").textContent =
    state.activeStartedAt
      ? new Date(state.activeStartedAt).toLocaleTimeString()
      : "Unbekannt";

  $("focusProgramCount").textContent =
    String(category?.programs?.length || 0);
}

function openStopModal() {
  if (!state?.active) return;

  $("stopPassword").value = "";
  $("stopError").textContent = "";

  $("stopModal").classList.remove("hidden");
  $("stopPassword").focus();
}

function closeStopModal() {
  $("stopModal").classList.add("hidden");
  $("stopPassword").value = "";
  $("stopError").textContent = "";
}

async function confirmStopFocus() {
  const password = $("stopPassword").value;

  if (!password) {
    $("stopError").textContent =
      "Bitte gib dein Masterpasswort ein.";
    return;
  }

  const result = await window.focusAPI.stopFocus(password);

  if (!result.ok) {
    $("stopError").textContent =
      result.message || "Das Masterpasswort ist falsch.";

    $("stopPassword").value = "";
    $("stopPassword").focus();

    return;
  }

  closeStopModal();
  toast("Fokusmodus beendet.");

  await refresh();
}

function renderDashboard() {
  $("status").textContent =
    state.active ? "FOCUS AKTIV" : "BEREIT";

  $("categories").innerHTML = "";

  for (const category of state.categories) {
    const wrap = document.createElement("div");
    wrap.className = "category";

    const top = document.createElement("div");
    top.className = "category-top";

    const name = document.createElement("input");
    name.value = category.name;
    name.setAttribute("aria-label", "Kategoriename");

    name.addEventListener("change", () => {
      category.name = name.value;
      saveCategories();
    });

    const del = document.createElement("button");
    del.className = "danger small";
    del.textContent = "Löschen";

    del.onclick = () => {
      state.categories = state.categories.filter(
        item => item.id !== category.id
      );

      saveCategories();
    };

    top.append(name, del);
    wrap.append(top);

    for (const program of category.programs) {
      const row = document.createElement("div");
      row.className = "program";
      row.textContent = program;

      const remove = document.createElement("button");
      remove.textContent = "Entfernen";

      remove.onclick = async () => {
        await window.focusAPI.removeProgram(
          category.id,
          program
        );

        await refresh();
      };

      row.append(remove);
      wrap.append(row);
    }

    const actions = document.createElement("div");
    actions.className = "category-actions";

    const add = document.createElement("button");
    add.className = "small";
    add.textContent = "+ Laufendes Programm";

    add.onclick = async () => {
      const apps = await window.focusAPI.getRunningApps();

      if (!apps.length) {
        toast(
          "Keine laufenden Programme mit ermittelbarem Pfad gefunden."
        );
        return;
      }

      chooseProgram(category.id, apps);
    };

    const start = document.createElement("button");
    start.className = "primary small";
    start.textContent = "Focus starten";

    start.onclick = async () => {
      const result = await window.focusAPI.startFocus(category.id);

      if (!result.ok) {
        toast(result.message || "Fokusmodus konnte nicht gestartet werden.");
      }

      await refresh();
    };

    actions.append(add, start);
    wrap.append(actions);

    $("categories").append(wrap);
  }

  const select = $("scheduleCategory");

  select.innerHTML =
    '<option value="">Kategorie auswählen</option>';

  state.categories.forEach(category => {
    const option = document.createElement("option");

    option.value = category.id;
    option.textContent = category.name;

    select.append(option);
  });

  const schedule = state.schedule || {};

  select.value = schedule.categoryId || "";

  $("startAt").value = localInput(schedule.startAt);
  $("endAt").value = localInput(schedule.endAt);
  $("duration").value = schedule.durationMinutes || "";

  $("scheduleInfo").textContent = schedule.startAt
    ? `Geplanter Start: ${new Date(schedule.startAt).toLocaleString()}`
    : "Ohne Startzeit kannst du den Focus-Modus manuell starten.";
}

async function saveCategories() {
  await window.focusAPI.saveCategories(state.categories);
  await refresh();
}

function chooseProgram(categoryId, apps) {
  const old = document.getElementById("programPicker");

  if (old) old.remove();

  const box = document.createElement("div");
  box.id = "programPicker";
  box.className = "panel";
  box.style.marginTop = "14px";

  const heading = document.createElement("h2");
  heading.textContent = "Laufendes Programm auswählen";

  box.append(heading);

  apps.forEach(app => {
    const button = document.createElement("button");

    button.className = "secondary";
    button.style.display = "block";
    button.style.width = "100%";
    button.style.textAlign = "left";
    button.style.margin = "6px 0";

    button.textContent = `${app.title} — ${app.path}`;

    button.onclick = async () => {
      await window.focusAPI.addProgram(categoryId, app.path);
      box.remove();
      await refresh();
    };

    box.append(button);
  });

  const close = document.createElement("button");
  close.textContent = "Schließen";
  close.onclick = () => box.remove();

  box.append(close);
  $("categories").append(box);
}

/* ---------------- SETUP / LOGIN ---------------- */

$("setupBtn").onclick = async () => {
  const result = await window.focusAPI.setupPassword(
    $("setupPassword").value
  );

  if (result.ok) {
    authenticated = true;
    toast("Masterpasswort eingerichtet.");
    await refresh();
  } else {
    toast(result.message);
  }
};

$("loginBtn").onclick = async () => {
  const result = await window.focusAPI.login(
    $("loginPassword").value
  );

  if (result.ok) {
    authenticated = true;
    $("loginPassword").value = "";
    await refresh();
  } else {
    toast("Passwort ist falsch.");
  }
};

/* ---------------- DASHBOARD ---------------- */

$("dashBtn").onclick = () => {
  if (state?.active) {
    show("focusView");
    renderFocus();
    return;
  }

  if (authenticated) {
    show("dashboard");
  } else {
    show("loginView");
  }
};

$("addCategory").onclick = () => {
  state.categories.push({
    id: uid(),
    name: "Neue Kategorie",
    programs: []
  });

  saveCategories();
};

$("saveSchedule").onclick = async () => {
  const result = await window.focusAPI.saveSchedule({
    categoryId: $("scheduleCategory").value,
    startAt: fromInput($("startAt").value),
    endAt: fromInput($("endAt").value),
    durationMinutes: $("duration").value
  });

  toast(
    result.ok
      ? "Zeitplanung gespeichert."
      : result.message
  );

  await refresh();
};

$("changePassword").onclick = async () => {
  const result = await window.focusAPI.changePassword(
    $("oldPassword").value,
    $("newPassword").value
  );

  toast(
    result.ok
      ? "Masterpasswort geändert."
      : result.message
  );

  $("oldPassword").value = "";
  $("newPassword").value = "";
};

/* ---------------- FOCUS END ---------------- */

$("endFocusBtn").onclick = openStopModal;
$("cancelStopBtn").onclick = closeStopModal;
$("confirmStopBtn").onclick = confirmStopFocus;

$("stopPassword").addEventListener("keydown", event => {
  if (event.key === "Enter") {
    confirmStopFocus();
  }

  if (event.key === "Escape") {
    closeStopModal();
  }
});

/* ---------------- EVENTS ---------------- */

window.focusAPI.onNotice(toast);

window.focusAPI.onUpdate(nextState => {
  state = nextState;

  if (state.active) {
    show("focusView");
    renderFocus();
    return;
  }

  refresh();
});

window.focusAPI.onStopRequest(() => {
  openStopModal();
});

/* ---------------- TIMERS ---------------- */

countdownTimer = setInterval(() => {
  if (state?.active) {
    renderFocus();
  }
}, 1000);

refresh();
