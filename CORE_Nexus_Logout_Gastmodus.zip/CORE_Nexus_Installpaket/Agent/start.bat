﻿@echo off
setlocal EnableExtensions
chcp 65001 >nul
cd /d "%~dp0"
title CORE Nexus Agent
if not exist "installed.flag" (
  echo CORE Nexus Agent wurde noch nicht installiert.
  echo Bitte zuerst install.bat ausfuehren.
  pause
  exit /b 1
)
where py >nul 2>&1
if %errorlevel%==0 (
  py -3 agent.py
) else (
  python agent.py
)
set "RC=%ERRORLEVEL%"
if not "%RC%"=="0" (
  echo.
  echo CORE Nexus Agent wurde mit Fehlercode %RC% beendet.
  echo Lies die Fehlermeldung oben. Sie bleibt sichtbar, bis du eine Taste drueckst.
  pause
)
exit /b %RC%
