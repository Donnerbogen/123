"""CORE Nexus license gate with one-time online activation and machine binding."""
from __future__ import annotations
import base64, hashlib, json, os, platform, subprocess, sys, tkinter as tk, urllib.error, urllib.request, webbrowser
from pathlib import Path
from datetime import datetime, timezone
from tkinter import messagebox
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey

PUBLIC_KEY_B64 = os.environ.get("CORE_NEXUS_LICENSE_PUBLIC_KEY", "pMd03ftgChNqGgJYWCps/M6xMlIyFe7zWGit139/Aus=").strip()
PORTAL_URL = os.environ.get("CORE_NEXUS_LICENSE_URL", "https://core-nexus-license-website.onrender.com/").rstrip("/")
API_URL = os.environ.get("CORE_NEXUS_LICENSE_API_URL", "https://core-nexus-license-website.onrender.com").rstrip("/")

# None means status unknown; True means Render has disabled enforcement.
_LICENSE_BYPASS_ACTIVE = False

def license_service_status():
    """Return True when enforcement is enabled, False when disabled, None on network/API failure."""
    if not API_URL or "REPLACE-WITH" in API_URL:
        return None
    req = urllib.request.Request(API_URL + "/api/license/status", headers={"User-Agent": "CORE-Nexus-License-Client"})
    try:
        with urllib.request.urlopen(req, timeout=5) as response:
            data = json.loads(response.read().decode("utf-8"))
        if data.get("ok") is True and isinstance(data.get("license_enabled"), bool):
            return data["license_enabled"]
    except Exception:
        return None
    return None

def _unb64u(value: str) -> bytes:
    return base64.urlsafe_b64decode(value + "=" * (-len(value) % 4))

def _timestamp(value) -> int:
    """Accept Unix timestamps and ISO-8601 timestamps returned by the license API."""
    if isinstance(value, (int, float)):
        return int(value)
    text = str(value or "").strip()
    try:
        return int(float(text))
    except (TypeError, ValueError):
        pass
    return int(datetime.fromisoformat(text.replace("Z", "+00:00")).timestamp())

def _api_product(product: str) -> str:
    return "server" if product.upper() in ("SERVER", "CORE_NEXUS_SERVER") else "agent"

def verify_key(token: str, expected_product: str):
    try:
        parts = token.strip().split(".")
        if len(parts) != 3 or parts[0] != "CNX1":
            return None, "Ungültiges Lizenzformat. Bitte kopiere den vollständigen Lizenzschlüssel aus dem CORE-Nexus-Lizenzportal."
        payload_raw = _unb64u(parts[1])
        signature = base64.b64decode(parts[2] + "=" * (-len(parts[2]) % 4))
        pub = Ed25519PublicKey.from_public_bytes(base64.b64decode(PUBLIC_KEY_B64))
        # The license API signs the canonical JSON payload bytes directly.
        pub.verify(signature, payload_raw)
        payload = json.loads(payload_raw.decode("utf-8"))
        if payload.get("product") != _api_product(expected_product):
            return None, "Dieser Lizenzschlüssel gehört zu einem anderen Produkt (Server oder Agent)."
        expiry = _timestamp(payload["expires_at"])
        now = int(datetime.now(timezone.utc).timestamp())
        if expiry <= now:
            return payload, "Die Lizenz ist abgelaufen. Bitte erneuere sie im Lizenzportal."
        if _timestamp(payload.get("issued_at", 0)) > now + 300:
            return None, "Der Lizenzschlüssel hat ein ungültiges Ausstellungsdatum."
        return payload, ""
    except Exception:
        return None, "Der Lizenzschlüssel ist ungültig oder die Signatur passt nicht zum konfigurierten öffentlichen Lizenzschlüssel."

def _read_license(path: Path):
    try: return json.loads(path.read_text(encoding="utf-8"))
    except Exception: return {}

def _write_license(path: Path, token: str, payload: dict, device_hash: str):
    path.parent.mkdir(parents=True, exist_ok=True); existing = _read_license(path)
    obj = {"token": token, "product": payload["product"], "license_id": payload.get("license_id", ""),
           "expires_at": int(payload["expires_at"]), "activation_device_hash": device_hash,
           "activated_at": existing.get("activated_at") or int(datetime.now(timezone.utc).timestamp()),
           "last_reminder_stage": existing.get("last_reminder_stage", "")}
    tmp = path.with_suffix(".tmp"); tmp.write_text(json.dumps(obj, indent=2), encoding="utf-8"); os.replace(tmp, path)

def _machine_id() -> str:
    """Return a stable machine identifier without transmitting the raw system ID."""
    raw = ""
    try:
        if sys.platform.startswith("win"):
            import winreg
            with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Cryptography") as key:
                raw = str(winreg.QueryValueEx(key, "MachineGuid")[0])
        elif sys.platform.startswith("linux"):
            for candidate in (Path("/etc/machine-id"), Path("/var/lib/dbus/machine-id")):
                if candidate.exists():
                    raw = candidate.read_text(encoding="utf-8").strip()
                    if raw: break
        else:
            raw = platform.node()
    except Exception:
        raw = ""
    if not raw:
        # Fallback is installation-bound. Copying only license.json will not transfer it.
        p = Path(__file__).resolve().parent / "data" / "install_id.txt"
        p.parent.mkdir(parents=True, exist_ok=True)
        try:
            raw = p.read_text(encoding="utf-8").strip()
        except Exception:
            raw = ""
        if not raw:
            import secrets
            raw = secrets.token_hex(32)
            p.write_text(raw, encoding="utf-8")
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()

def _activate_online(token: str, product: str, device_hash: str):
    if not API_URL or "REPLACE-WITH" in API_URL:
        return False, "Der Lizenzservice ist nicht konfiguriert. Setze CORE_NEXUS_LICENSE_API_URL."
    body = json.dumps({
        "license_key": token,
        "product": _api_product(product),
        "device_id": device_hash,
        "device_name": platform.node()[:120],
    }).encode("utf-8")
    req = urllib.request.Request(API_URL + "/api/license/activate", data=body,
        headers={"Content-Type": "application/json", "User-Agent": "CORE-Nexus-License-Client"}, method="POST")
    try:
        with urllib.request.urlopen(req, timeout=20) as response:
            result = json.loads(response.read().decode("utf-8"))
        if result.get("ok") and result.get("payload") and result.get("signature"):
            return True, result
        return False, str(result.get("detail") or result.get("message") or "Lizenzaktivierung abgelehnt.")
    except urllib.error.HTTPError as exc:
        try:
            detail = json.loads(exc.read().decode("utf-8")).get("detail", "")
        except Exception:
            detail = ""
        messages = {
            404: "Dieser Lizenzschlüssel wurde im Lizenzserver nicht gefunden. Prüfe, ob er vollständig kopiert wurde und ob die Webseite und API dieselbe Lizenzdatenbank verwenden.",
            409: "Dieser Schlüssel wurde bereits aktiviert oder ist für das andere Produkt bestimmt.",
            410: "Dieser Lizenzschlüssel ist abgelaufen.",
        }
        return False, detail or messages.get(exc.code, f"Lizenzservice hat HTTP {exc.code} zurückgegeben.")
    except Exception:
        return False, "Lizenzservice nicht erreichbar. Prüfe die Render-Adresse und deine Internetverbindung."

def _days_left(payload): return int((_timestamp(payload["expires_at"]) - int(datetime.now(timezone.utc).timestamp()) + 86399) // 86400)
def _reminder_stage(days: int):
    if days > 30: return ""
    if days > 14: return "30-day"
    if days > 7: return "14-day"
    if days == 7: return "7-day"
    if days > 0: return "daily:" + datetime.now().date().isoformat()
    return "expired"

def _maybe_remind(path: Path, payload: dict):
    days = _days_left(payload); stage = _reminder_stage(days); saved = _read_license(path)
    if stage and stage != saved.get("last_reminder_stage", ""):
        expiry = datetime.fromtimestamp(_timestamp(payload["expires_at"]), timezone.utc).astimezone().strftime("%d.%m.%Y")
        if days > 0:
            messagebox.showwarning("CORE Nexus – Lizenzverlängerung", f"Deine CORE-Nexus-Lizenz läuft am {expiry} ab.\n\nVerbleibende Zeit: {days} Tag(e).\nBitte verlängere sie rechtzeitig unter:\n{PORTAL_URL}")
        saved["last_reminder_stage"] = stage; path.write_text(json.dumps(saved, indent=2), encoding="utf-8")

def ensure_license(product: str, title: str) -> bool:
    global _LICENSE_BYPASS_ACTIVE
    path = Path(__file__).resolve().parent / "data" / "license.json"
    status = license_service_status()
    if status is False:
        _LICENSE_BYPASS_ACTIVE = True
        return True
    if status is True:
        _LICENSE_BYPASS_ACTIVE = False
    saved = _read_license(path); token = str(saved.get("token", "")); device_hash = _machine_id()
    payload, error = verify_key(token, product) if token else (None, "Für diese Installation ist noch keine Lizenz aktiviert.")
    bound_ok = bool(saved.get("activation_device_hash")) and saved.get("activation_device_hash") == device_hash
    if payload and not error and (not bound_ok or payload.get("device_id") != device_hash):
        error = "Diese Lizenz ist auf diesem Gerät nicht aktiviert. Ein bereits verwendeter Schlüssel kann nicht auf ein anderes Gerät übertragen werden."
        payload = None
    root = tk.Tk(); root.title(title + " | Lizenzaktivierung"); root.geometry("690x380"); root.resizable(False, False); root.configure(padx=22, pady=18)
    result = {"ok": False}
    tk.Label(root, text="CORE Nexus – Lizenz", font=("Segoe UI", 16, "bold")).pack(anchor="w")
    tk.Label(root, text="Server und Agent benötigen jeweils einen eigenen Lizenzschlüssel. Der Schlüssel wird online einmalig aktiviert und danach an dieses Gerät gebunden. Laufzeit: 365 Tage.", justify="left", wraplength=640).pack(anchor="w", pady=(8, 12))
    status = tk.Label(root, text="", justify="left", wraplength=640); status.pack(anchor="w", pady=(0, 10))
    entry = tk.Entry(root, width=92); tk.Label(root, text="Neuer, noch nicht verwendeter Lizenzschlüssel:").pack(anchor="w")
    entry.pack(fill="x", pady=(4, 8))
    if token and not bound_ok: entry.insert(0, "")
    elif token: entry.insert(0, token)
    if payload and not error:
        exp = datetime.fromtimestamp(_timestamp(payload["expires_at"]), timezone.utc).astimezone().strftime("%d.%m.%Y")
        status.configure(text=f"Lizenz auf diesem Gerät aktiviert. Gültig bis {exp}.", fg="#15803d")
    else: status.configure(text=error or "Bitte einen neuen Lizenzschlüssel aktivieren.", fg="#b91c1c")
    def activate():
        new_token = entry.get().strip()
        if not new_token:
            messagebox.showerror("Lizenz fehlt", "Bitte gib den vollständigen Lizenzschlüssel ein.", parent=root); return
        ok, api_result = _activate_online(new_token, product, device_hash)
        if not ok:
            messagebox.showerror("Aktivierung fehlgeschlagen", api_result, parent=root); return
        signed_token = "CNX1." + str(api_result["payload"]) + "." + str(api_result["signature"])
        new_payload, err = verify_key(signed_token, product)
        if err or not new_payload:
            messagebox.showerror("Signaturprüfung fehlgeschlagen", "Der Lizenzserver hat eine Lizenz geliefert, deren Signatur nicht zum öffentlichen Schlüssel im Client passt. CORE_NEXUS_LICENSE_PUBLIC_KEY muss mit /api/license/public-key übereinstimmen. Kontaktiere den Betreiber, bevor du einen weiteren Schlüssel aktivierst.", parent=root); return
        if new_payload.get("device_id") != device_hash:
            messagebox.showerror("Gerätebindung fehlgeschlagen", "Die Lizenzantwort ist nicht an dieses Gerät gebunden.", parent=root); return
        _write_license(path, signed_token, new_payload, device_hash)
        exp = datetime.fromtimestamp(_timestamp(new_payload["expires_at"]), timezone.utc).astimezone().strftime("%d.%m.%Y")
        status.configure(text=f"Lizenz einmalig aktiviert und an dieses Gerät gebunden. Gültig bis {exp}.", fg="#15803d")
        entry.delete(0, "end"); entry.insert(0, signed_token)
        start_btn.configure(state="normal")
    def start():
        current_saved = _read_license(path); current_token = str(current_saved.get("token", ""))
        current, err = verify_key(current_token, product)
        if not err and current and current_saved.get("activation_device_hash") == _machine_id() and current.get("device_id") == _machine_id():
            result["ok"] = True; root.destroy()
        else: messagebox.showerror("Lizenz erforderlich", err or "Lizenz nicht auf diesem Gerät aktiviert. Bitte einen unbenutzten Schlüssel aktivieren.", parent=root)
    def open_portal(): webbrowser.open(PORTAL_URL)
    buttons = tk.Frame(root); buttons.pack(fill="x", pady=(14, 0))
    tk.Button(buttons, text="Lizenzportal öffnen", command=open_portal).pack(side="left")
    tk.Button(buttons, text="Einmalig aktivieren / erneuern", command=activate).pack(side="left", padx=8)
    start_btn = tk.Button(buttons, text="Programm starten", command=start, state=("normal" if payload and not error and bound_ok else "disabled")); start_btn.pack(side="right")
    root.protocol("WM_DELETE_WINDOW", root.destroy); root.mainloop()
    if result.get("ok"):
        fresh, err = verify_key(_read_license(path).get("token", ""), product)
        if fresh and not err: _maybe_remind(path, fresh)
    return bool(result.get("ok"))

def schedule_license_reminders(root, product: str):
    """Poll Render's toggle; bypass enforcement while disabled, resume when enabled."""
    global _LICENSE_BYPASS_ACTIVE
    path = Path(__file__).resolve().parent / "data" / "license.json"
    poll_ms = 60 * 1000
    def check():
        global _LICENSE_BYPASS_ACTIVE
        try:
            status = license_service_status()
            if status is False:
                _LICENSE_BYPASS_ACTIVE = True
                root.after(poll_ms, check)
                return
            if status is True:
                _LICENSE_BYPASS_ACTIVE = False
            elif _LICENSE_BYPASS_ACTIVE:
                # Preserve the last known disabled state during a temporary Render outage.
                root.after(poll_ms, check)
                return
            saved = _read_license(path)
            payload, error = verify_key(str(saved.get("token", "")), product)
            if error or not payload or saved.get("activation_device_hash") != _machine_id() or payload.get("device_id") != _machine_id():
                messagebox.showerror("CORE Nexus – Lizenz erforderlich", "Das Lizenzsystem wurde in Render wieder aktiviert. Für diese Installation fehlt eine gültige Lizenz. Bitte starte das Programm erneut und aktiviere einen passenden Schlüssel.")
                root.destroy(); return
            _maybe_remind(path, payload)
            root.after(poll_ms, check)
        except tk.TclError:
            return
    root.after(poll_ms, check)
