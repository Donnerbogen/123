CORE Nexus Agent

1. setup.bat: Menue fuer Installation/Reparatur, Deinstallation und Autostart.
2. start.bat: Startet die bereits installierte Anwendung sofort.

setup.bat fragt vor jeder Aktion nach deiner Auswahl. Bei der Deinstallation kannst du lokale Daten behalten oder loeschen.

3. Agent-Anmeldung und Gerätefernsteuerung
   - Im Agent-Fenster auf „Am Server anmelden“ klicken.
   - Nur Konten verwenden, die zuvor im Server-Menü „Konten & Rechte“ erstellt wurden.
   - Der Server prüft Kontoaktivität und Berechtigungen. Für die Geräteübersicht ist „Geräte anzeigen“ erforderlich; für Fernsteuerung sind „Bildschirm ansehen“ und „Maus und Tastatur steuern“ erforderlich.
   - Es werden nur serverseitig freigegebene Geräte mit gespeicherter lokaler Zustimmung zur Fernsteuerung angeboten.
   - Im LAN verbindet sich die Anmeldung direkt über TCP 47623. Wenn kein LAN-Server gefunden wird, nutzt sie das konfigurierte Render-Relay; dafür muss die aktualisierte Relay-Version mit Rolle „controller“ auf Render bereitgestellt sein.
   - Die Anmeldung verwendet Challenge-Response. Das Passwort wird nicht im Klartext an den Server gesendet.
   - Der Server hat Vorrang: Wenn eine Fernsteuerung im Server-Dashboard geöffnet wird oder der Server die Sitzung beendet, wird die vom Agenten gestartete Sitzung sofort beendet.


Neue Erweiterungen (Oktober 2026)
Details, Grenzen und Installation stehen in ERWEITERUNGEN_2026-10.txt im Paketstamm. Vor dem Update Server/data sichern. Dateiübertragung ist controller->Zielgerät (max. 2 MiB), Zwischenablage nur nach Bestätigung und Monitorwechsel schaltet die Bildschirmaufnahme um. Der Notfallmodus beendet aktive Sitzungen, nicht den Agenten.



Diese lizenzfreie Ausgabe enthält keine Lizenzschlüssel-Abfrage oder Lizenzdatei.
