import json
from pathlib import Path
p=Path(__file__).resolve().parent/"config.json"
d=json.loads(p.read_text(encoding="utf-8"))
for k in ["show_clock","show_date","show_battery","show_network","wrong_code_sound","success_sound","write_log","log_wrong_codes","autostart"]:
    v=input(f"{k} [{str(d.get(k)).lower()}] (j/n/Enter): ").strip().lower()
    if v=="j": d[k]=True
    elif v=="n": d[k]=False
for k in ["max_failed_attempts","lockout_seconds","auto_lock_seconds"]:
    v=input(f"{k} [{d.get(k)}] (Enter = behalten): ").strip()
    if v:
        try:d[k]=int(v)
        except: print("Ungültige Zahl.")
p.write_text(json.dumps(d,indent=4,ensure_ascii=False),encoding="utf-8")
print("Konfiguration gespeichert.")