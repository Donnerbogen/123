﻿@echo off
setlocal EnableExtensions
chcp 65001 >nul
cd /d "%~dp0"
title CORE Nexus Server - Verwaltung

rem Dieses Menue fragt zuerst nach einer Aktion. Bis zur Auswahl werden keine Aenderungen vorgenommen.
:menu
cls
echo ============================================
echo       CORE Nexus Server - VERWALTUNG
echo ============================================
echo.
echo Was moechtest du machen?
echo.
echo   [1] Installieren / reparieren + Autostart aktivieren
echo   [2] Deinstallieren
echo   [3] Nur Autostart aktivieren
echo   [4] Nur Autostart deaktivieren
echo   [5] Abbrechen
echo.
choice /C 12345 /N /M "Bitte Auswahl treffen [1-5]: "
if errorlevel 5 goto cancel
if errorlevel 4 goto disable_startup
if errorlevel 3 goto enable_startup
if errorlevel 2 goto uninstall
if errorlevel 1 goto install

:install
cls
title CORE Nexus Server - Installation
echo ============================================
echo       CORE Nexus Server - INSTALLATION
echo ============================================
echo.
where py >nul 2>&1
if not errorlevel 1 (
  set "PY=py -3"
) else (
  where python >nul 2>&1
  if errorlevel 1 (
    echo FEHLER: Python wurde nicht gefunden.
    echo Installiere Python von https://www.python.org/downloads/windows/
    echo Aktiviere beim Setup "Add Python to PATH" und installiere Tcl/Tk.
    pause
    exit /b 1
  )
  set "PY=python"
)
%PY% --version
if errorlevel 1 (
  echo FEHLER: Python konnte nicht gestartet werden.
  pause
  exit /b 1
)
%PY% -c "import tkinter; print('Tkinter OK')" >nul 2>&1
if errorlevel 1 (
  echo FEHLER: Python-Tkinter fehlt. Installiere Python mit Tcl/Tk-Unterstuetzung.
  pause
  exit /b 1
)
%PY% -m pip install --disable-pip-version-check --upgrade pillow websocket-client cryptography
if errorlevel 1 (
  echo FEHLER: Abhaengigkeiten konnten nicht installiert werden.
  echo Pruefe die Internetverbindung waehrend der Installation.
  pause
  exit /b 1
)
%PY% -m py_compile server.py
if errorlevel 1 (
  echo FEHLER: server.py hat einen Syntaxfehler. Installation abgebrochen.
  pause
  exit /b 1
)
if not exist "data" mkdir "data"
if not exist "admin_config.json" if exist "admin_config.example.json" copy "admin_config.example.json" "admin_config.json" >nul
>"installed.flag" echo CORE Nexus installiert am %DATE% %TIME%
echo.
echo Installation erfolgreich. Aktiviere den Autostart...
call :enable_startup_action
if errorlevel 1 (
  echo WARNUNG: Installation abgeschlossen, aber der Autostart konnte nicht aktiviert werden.
  pause
  exit /b 1
)
echo.
echo Fertig. CORE Nexus Server startet ab der naechsten Windows-Anmeldung automatisch.
echo Der Service-Admin-Token und das Owner-Bootstrap wurden fuer zentral erstellte Server bereits eingerichtet.
echo Admin-Verbindungen verwenden TCP-Port 47623.
echo Zum sofortigen Start weiterhin start.bat verwenden.
echo.
pause
exit /b 0

:enable_startup
if not exist "installed.flag" (
  echo.
  echo CORE Nexus Server ist noch nicht installiert. Bitte zuerst Option 1 auswaehlen.
  pause
  goto menu
)
call :enable_startup_action
if errorlevel 1 (pause & exit /b 1)
echo.
pause
goto menu

:enable_startup_action
set "START_FILE=%~dp0start.bat"
set "STARTUP_DIR=%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup"
if not exist "%STARTUP_DIR%" mkdir "%STARTUP_DIR%"
powershell -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='Stop'; $ws=New-Object -ComObject WScript.Shell; $link=$ws.CreateShortcut((Join-Path $env:APPDATA 'Microsoft\Windows\Start Menu\Programs\Startup\CORE Nexus Server.lnk')); $link.TargetPath=$env:START_FILE; $link.WorkingDirectory=(Split-Path -Parent $env:START_FILE); $link.WindowStyle=7; $link.Description='CORE Nexus Server automatisch beim Windows-Anmelden starten'; $link.Save()"
if errorlevel 1 (
  echo FEHLER: Autostart konnte nicht eingerichtet werden.
  exit /b 1
)
echo Autostart aktiviert.
exit /b 0

:disable_startup
set "LINK=%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup\CORE Nexus Server.lnk"
if exist "%LINK%" (
  del /q "%LINK%"
  echo Autostart wurde deaktiviert.
) else (
  echo Kein Autostart-Eintrag gefunden.
)
echo.
pause
goto menu

:uninstall
cls
title CORE Nexus Server - Deinstallation
echo ============================================
echo       CORE Nexus Server - DEINSTALLATION
echo ============================================
echo.
echo Die Autostart-Verknuepfung und die Installationsmarkierung werden entfernt.
echo.
choice /C JN /N /M "Sollen auch lokale Anwendungsdaten geloescht werden? [J/N] "
if errorlevel 2 goto keepdata
if errorlevel 1 goto deletedata

goto cleanup
:deletedata
if exist "data" rmdir /s /q "data"
if exist "device_id.json" del /q "device_id.json"
if exist "consent.json" del /q "consent.json"
goto cleanup
:keepdata
echo Lokale Daten bleiben erhalten.
:cleanup
set "LINK=%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup\CORE Nexus Server.lnk"
if exist "%LINK%" del /q "%LINK%"
if exist "__pycache__" rmdir /s /q "__pycache__"
if exist "installed.flag" del /q "installed.flag"
echo.
echo Deinstallation abgeschlossen.
echo Der Programmordner und die Python-Dateien bleiben erhalten, damit du sie manuell entfernen kannst.
pause
exit /b 0

:cancel
echo.
echo Abgebrochen. Es wurden keine Aenderungen vorgenommen.
pause
exit /b 0
