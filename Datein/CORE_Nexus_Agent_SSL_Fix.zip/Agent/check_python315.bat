@echo off
setlocal EnableExtensions
cd /d "%~dp0"
echo ========================================
echo CORE Nexus - Python 3.15-Pruefung
echo ========================================
where py >nul 2>&1
if errorlevel 1 (
  echo FEHLER: Python Install Manager / py wurde nicht gefunden.
  echo Unter Windows Server 2019 den offiziellen Install Manager per MSI installieren.
  echo Danach in einer neuen Eingabeaufforderung ausfuehren: py install 3.15
  pause
  exit /b 1
)
py -V:3.15 --version
if errorlevel 1 (
  echo FEHLER: Python 3.15 ist nicht installiert oder nicht verfuegbar.
  echo Ausfuehren: py install 3.15
  pause
  exit /b 1
)
py -V:3.15 -c "import tkinter; print('Tkinter OK')"
if errorlevel 1 (
  echo FEHLER: Tkinter fehlt in der Python-3.15-Installation.
  pause
  exit /b 1
)
py -V:3.15 -m pip --version
if errorlevel 1 (
  echo FEHLER: pip ist nicht verfuegbar.
  pause
  exit /b 1
)
echo Pruefung erfolgreich.
pause
exit /b 0
