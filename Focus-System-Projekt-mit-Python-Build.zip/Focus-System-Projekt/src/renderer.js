const $ = id => document.getElementById(id);
let state = null, authenticated = false, toastTimer = null;
const uid = () => (crypto.randomUUID ? crypto.randomUUID() : String(Date.now()) + Math.random());
function toast(message) { const el=$("toast"); el.textContent=message; el.classList.add("show"); clearTimeout(toastTimer); toastTimer=setTimeout(()=>el.classList.remove("show"),3000); }
function show(id) { ["setupView","loginView","dashboard","lockView"].forEach(x=>$(x).classList.add("hidden")); $(id).classList.remove("hidden"); }
function localInput(iso) { if(!iso)return ""; const d=new Date(iso); const p=n=>String(n).padStart(2,"0"); return `${d.getFullYear()}-${p(d.getMonth()+1)}-${p(d.getDate())}T${p(d.getHours())}:${p(d.getMinutes())}`; }
function fromInput(v) { return v ? new Date(v).toISOString() : null; }
async function refresh() {
  state=await window.focusAPI.getState();
  if(new URLSearchParams(location.search).get("lock")==="1") { show("lockView"); return; }
  if(state.needsSetup){show("setupView");return;}
  if(!authenticated){show("loginView");return;}
  show("dashboard"); render();
}
function render() {
  $("status").textContent=state.active?"FOCUS AKTIV":"BEREIT";
  $("categories").innerHTML="";
  for(const c of state.categories){
    const wrap=document.createElement("div");wrap.className="category";
    const top=document.createElement("div");top.className="category-top";
    const name=document.createElement("input");name.value=c.name;name.setAttribute("aria-label","Kategoriename");
    name.addEventListener("change",()=>{c.name=name.value;saveCategories();});
    const del=document.createElement("button");del.className="danger small";del.textContent="Löschen";del.onclick=()=>{state.categories=state.categories.filter(x=>x.id!==c.id);saveCategories();};
    top.append(name,del);wrap.append(top);
    for(const p of c.programs){const row=document.createElement("div");row.className="program";row.textContent=p;const rm=document.createElement("button");rm.textContent="Entfernen";rm.onclick=async()=>{await window.focusAPI.removeProgram(c.id,p);refresh();};row.append(rm);wrap.append(row);}
    const actions=document.createElement("div");actions.className="category-actions";
    const add=document.createElement("button");add.className="small";add.textContent="+ Laufendes Programm";add.onclick=async()=>{const apps=await window.focusAPI.getRunningApps(); if(!apps.length){toast("Keine laufenden Programme mit ermittelbarem Pfad gefunden.");return;} chooseProgram(c.id,apps);};
    const start=document.createElement("button");start.className="primary small";start.textContent="Focus starten";start.onclick=async()=>{const r=await window.focusAPI.startFocus(c.id);toast(r.ok?"Focus gestartet.":"Kategorie nicht gefunden.");refresh();};
    actions.append(add,start);wrap.append(actions);$("categories").append(wrap);
  }
  const sel=$("scheduleCategory");sel.innerHTML='<option value="">Kategorie auswählen</option>';
  state.categories.forEach(c=>{const o=document.createElement("option");o.value=c.id;o.textContent=c.name;sel.append(o);});
  const s=state.schedule||{};sel.value=s.categoryId||"";$("startAt").value=localInput(s.startAt);$("endAt").value=localInput(s.endAt);$("duration").value=s.durationMinutes||"";
  $("scheduleInfo").textContent=s.startAt?`Geplanter Start: ${new Date(s.startAt).toLocaleString()}`:"Ohne Startzeit kannst du den Focus-Modus manuell starten.";
}
async function saveCategories(){await window.focusAPI.saveCategories(state.categories);refresh();}
// Program selection is rendered as a temporary in-page picker; no browser prompt/confirm dialogs.
function chooseProgram(categoryId,apps){
  const old=document.getElementById("programPicker");if(old)old.remove();
  const box=document.createElement("div");box.id="programPicker";box.className="panel";box.style.marginTop="14px";
  const h=document.createElement("h2");h.textContent="Laufendes Programm auswählen";box.append(h);
  apps.forEach(a=>{const b=document.createElement("button");b.className="secondary";b.style.display="block";b.style.width="100%";b.style.textAlign="left";b.style.margin="6px 0";b.textContent=`${a.title} — ${a.path}`;b.onclick=async()=>{await window.focusAPI.addProgram(categoryId,a.path);box.remove();refresh();};box.append(b);});
  const close=document.createElement("button");close.textContent="Schließen";close.onclick=()=>box.remove();box.append(close);$("categories").append(box);
}
$("setupBtn").onclick=async()=>{const r=await window.focusAPI.setupPassword($("setupPassword").value);if(r.ok){authenticated=true;toast("Hauptpasswort eingerichtet.");refresh();}else toast(r.message);};
$("loginBtn").onclick=async()=>{const r=await window.focusAPI.login($("loginPassword").value);if(r.ok){authenticated=true;refresh();}else toast("Passwort ist falsch.");};
$("dashBtn").onclick=()=>{if(authenticated)show("dashboard");else show("loginView");};
$("addCategory").onclick=()=>{state.categories.push({id:uid(),name:"Neue Kategorie",programs:[]});saveCategories();};
$("saveSchedule").onclick=async()=>{const r=await window.focusAPI.saveSchedule({categoryId:$("scheduleCategory").value,startAt:fromInput($("startAt").value),endAt:fromInput($("endAt").value),durationMinutes:$("duration").value});toast(r.ok?"Zeitplanung gespeichert.":r.message);refresh();};
$("changePassword").onclick=async()=>{const r=await window.focusAPI.changePassword($("oldPassword").value,$("newPassword").value);toast(r.ok?"Passwort geändert.":r.message);$("oldPassword").value="";$("newPassword").value="";};
$("startLock").onclick=async()=>{const r=await window.focusAPI.startLock($("lockPassword").value,$("lockDuration").value);if(r.ok){$("lockPassword").value="";$("lockDuration").value="";toast("Screen-Lock gestartet.");}else toast(r.message);};
$("unlockBtn").onclick=async()=>{const r=await window.focusAPI.unlock($("unlockPassword").value);if(r.ok){$("unlockPassword").value="";$("lockError").textContent="";}else $("lockError").textContent=r.message;};
$("lockBtn").onclick=()=>{if(authenticated)document.querySelector("#lockPassword").focus();else toast("Bitte zuerst das Dashboard entsperren.");};
window.focusAPI.onNotice(toast);
window.focusAPI.onUpdate(next=>{state=next;if(authenticated&&!state.needsSetup)render();});
refresh();
