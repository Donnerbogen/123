﻿@echo off
setlocal EnableExtensions
cd /d "%~dp0"
chcp 65001 >nul
echo ========================================
echo CORE Nexus - Relay-Konfiguration pruefen
echo ========================================
where py >nul 2>&1
if not errorlevel 1 (set "PY=py -3") else (set "PY=python")
%PY% -c "import json,pathlib,sys; p=pathlib.Path('relay_config.json'); c=json.loads(p.read_text(encoding='utf-8-sig')) if p.exists() else {}; print('Datei:',p.resolve()); print('Vorhanden:',p.exists()); print('Relay-URL:',c.get('relay_url','FEHLT')); print('Raum-ID:',c.get('room_id','FEHLT')); t=str(c.get('relay_token','')); print('Token:', 'FEHLT' if not t else ('PLATZHALTER - durch Render-Token ersetzen' if 'PASTE_' in t else 'gesetzt')); print('Aktiviert:',c.get('enabled',False)); sys.exit(2 if not p.exists() or not c.get('enabled') or not c.get('relay_url') or not c.get('room_id') or not t or 'PASTE_' in t else 0)"
if errorlevel 1 (echo. & echo FEHLER: Konfiguration fehlt oder enthaelt noch einen Platzhalter.) else (echo. & echo Konfiguration sieht grundsaetzlich vollstaendig aus.)
echo.
echo Server und Agent muessen denselben Relay-Token und dieselbe Raum-ID verwenden.
echo Der Token muss exakt CORE_NEXUS_RELAY_TOKEN aus Render entsprechen.
pause
