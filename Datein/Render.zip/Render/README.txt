CORE NEXUS – RENDER RELAY UND DASHBOARD

1. In GitHub den Inhalt des Ordners GitHub im Repository-Stamm speichern.
2. In Render den Blueprint aus render.yaml erstellen oder synchronisieren.
3. In Render -> Environment die automatisch erzeugten geheimen Variablen CORE_NEXUS_RELAY_TOKEN und CORE_NEXUS_DASHBOARD_TOKEN prüfen. Beide getrennt halten.
4. Öffne https://DEIN-DIENST.onrender.com/health für den Health-Check.
5. Öffne https://DEIN-DIENST.onrender.com/ für das geschützte Relay-Dashboard. Gib CORE_NEXUS_DASHBOARD_TOKEN ein.
6. Das Dashboard zeigt aktive Agenten und Server, Nachrichten, Fehler und die letzten Verbindungsereignisse. Werte sind nur im Arbeitsspeicher und werden bei einem Render-Neustart zurückgesetzt.

Hinweis: Das Dashboard zählt nur Verbindungen, die tatsächlich über Render laufen. LAN-Verbindungen werden nicht über Render geleitet und tauchen daher nicht in diesen Zahlen auf.
