"""CORE Nexus Relay and private operations dashboard."""
import asyncio
import json
import os
import secrets
from collections import deque
from datetime import datetime, timezone

from fastapi import FastAPI, WebSocket, WebSocketDisconnect, Header, HTTPException
from fastapi.responses import HTMLResponse

app = FastAPI(title="CORE Nexus Relay", docs_url=None, redoc_url=None)
TOKEN = os.environ.get("CORE_NEXUS_RELAY_TOKEN", "").strip()
DASH_TOKEN = os.environ.get("CORE_NEXUS_DASHBOARD_TOKEN", "").strip()
MAX_MESSAGE_BYTES = int(os.environ.get("MAX_MESSAGE_BYTES", "8388608"))
servers = {}       # room -> websocket
agents = {}        # (room, device_id) -> websocket
locks = {}
agent_server_warning = set()
EVENTS = deque(maxlen=250)
COUNTERS = {"connections_total": 0, "disconnects_total": 0, "errors_total": 0, "messages_total": 0}


def now():
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def event(kind, message, role="system", room="", device=""):
    EVENTS.appendleft({"time": now(), "kind": kind, "message": str(message)[:240],
                       "role": role, "room": room[:48], "device": device[:16]})
    if kind == "error":
        COUNTERS["errors_total"] += 1


def room_lock(room):
    if room not in locks:
        locks[room] = asyncio.Lock()
    return locks[room]


@app.get("/health")
async def health():
    return {"status": "ok", "service": "CORE Nexus Relay", "time": now()}


@app.get("/api/dashboard")
async def dashboard_data(authorization: str | None = Header(default=None)):
    if not DASH_TOKEN or not secrets.compare_digest(authorization or "", f"Bearer {DASH_TOKEN}"):
        raise HTTPException(status_code=401, detail="Dashboard-Anmeldung erforderlich")
    active_rooms = set(servers.keys()) | {room for room, _ in agents.keys()}
    server_rows = [{"room": room[:48], "connected": ws.client_state.name == "CONNECTED"}
                   for room, ws in list(servers.items())]
    agent_rows = [{"room": room[:48], "device": did[:16], "connected": ws.client_state.name == "CONNECTED"}
                  for (room, did), ws in list(agents.items())]
    return {
        "status": "online", "time": now(),
        "metrics": {"servers_online": len(servers), "agents_online": len(agents),
                    "rooms_active": len(active_rooms), **COUNTERS},
        "servers": server_rows, "agents": agent_rows, "events": list(EVENTS),
    }


@app.get("/", response_class=HTMLResponse)
async def dashboard():
    return HTMLResponse(DASHBOARD_HTML)


@app.websocket("/ws")
async def relay(ws: WebSocket):
    auth = ws.headers.get("authorization", "")
    if not TOKEN or not secrets.compare_digest(auth, f"Bearer {TOKEN}"):
        event("error", "Verbindungsversuch mit ungültigem Relay-Token")
        await ws.close(code=1008, reason="Unauthorized")
        return
    role = ws.headers.get("x-core-role", "").strip().lower()
    room = ws.headers.get("x-core-room", "").strip()
    if role not in ("server", "agent") or not room or len(room) > 128:
        event("error", "Verbindungsversuch mit ungültiger Rolle oder Raum-ID", role=role or "unknown")
        await ws.close(code=1008, reason="Invalid role or room")
        return
    await ws.accept()
    COUNTERS["connections_total"] += 1
    event("success", f"{role.title()} hat Relay-Verbindung geöffnet", role, room)
    if role == "server":
        async with room_lock(room):
            if room in servers:
                event("error", "Doppelter Server für dieselbe Raum-ID abgewiesen", role, room)
                await ws.close(code=1008, reason="Server already connected")
                return
            servers[room] = ws
        try:
            while True:
                raw = await ws.receive_text()
                if len(raw.encode("utf-8")) > MAX_MESSAGE_BYTES:
                    event("error", "Nachricht des Servers überschreitet Größenlimit", role, room)
                    await ws.close(code=1009)
                    break
                try:
                    env = json.loads(raw)
                except Exception:
                    event("error", "Ungültiges JSON vom Server", role, room)
                    continue
                did = str(env.get("device_id", ""))[:80]
                payload = env.get("payload")
                if not did or not isinstance(payload, dict):
                    event("error", "Ungültige Relay-Nachricht vom Server", role, room)
                    continue
                COUNTERS["messages_total"] += 1
                target = agents.get((room, did))
                if target:
                    try:
                        await target.send_text(json.dumps({"device_id": did, "payload": payload}, separators=(",", ":")))
                    except Exception:
                        agents.pop((room, did), None)
                        event("error", "Nachricht konnte nicht an Agent zugestellt werden", "agent", room, did)
        except (WebSocketDisconnect, RuntimeError):
            pass
        except Exception as exc:
            event("error", f"Server-Verbindung: {type(exc).__name__}", role, room)
        finally:
            async with room_lock(room):
                if servers.get(room) is ws:
                    servers.pop(room, None)
            COUNTERS["disconnects_total"] += 1
            event("warning", "Server-Verbindung beendet", role, room)
    else:
        did = None
        try:
            while True:
                raw = await ws.receive_text()
                if len(raw.encode("utf-8")) > MAX_MESSAGE_BYTES:
                    event("error", "Nachricht eines Agenten überschreitet Größenlimit", role, room)
                    await ws.close(code=1009)
                    break
                try:
                    env = json.loads(raw)
                except Exception:
                    event("error", "Ungültiges JSON von Agent", role, room)
                    continue
                claimed = str(env.get("device_id", ""))[:80]
                payload = env.get("payload")
                if not claimed or not isinstance(payload, dict):
                    event("error", "Ungültige Relay-Nachricht von Agent", role, room)
                    continue
                if did is None:
                    if payload.get("type") != "hello" or str(payload.get("device_id", "")) != claimed:
                        event("error", "Agent ohne gültige erste hello-Nachricht abgewiesen", role, room, claimed)
                        await ws.close(code=1008, reason="First message must be hello")
                        return
                    did = claimed
                    async with room_lock(room):
                        old = agents.get((room, did))
                        if old and old is not ws:
                            try:
                                await old.close(code=1008, reason="Replaced by newer connection")
                            except Exception:
                                pass
                        agents[(room, did)] = ws
                    event("success", "Agent ist verbunden", role, room, did)
                elif claimed != did:
                    event("error", "Agent versuchte Geräte-ID während Sitzung zu ändern", role, room, did)
                    await ws.close(code=1008, reason="Device identity changed")
                    return
                COUNTERS["messages_total"] += 1
                target = servers.get(room)
                if target:
                    agent_server_warning.discard((room, did))
                    try:
                        await target.send_text(json.dumps({"device_id": did, "payload": payload}, separators=(",", ":")))
                    except Exception:
                        event("error", "Nachricht konnte nicht an Server zugestellt werden", "server", room, did)
                else:
                    # Record the offline server once per agent, not on every heartbeat.
                    key = (room, did)
                    if key not in agent_server_warning:
                        agent_server_warning.add(key)
                        event("warning", "Agent verbunden, aber Server in diesem Raum offline", role, room, did)
        except (WebSocketDisconnect, RuntimeError):
            pass
        except Exception as exc:
            event("error", f"Agent-Verbindung: {type(exc).__name__}", role, room, did or "")
        finally:
            if did:
                async with room_lock(room):
                    if agents.get((room, did)) is ws:
                        agents.pop((room, did), None)
                agent_server_warning.discard((room, did))
                event("warning", "Agent-Verbindung beendet", role, room, did)
            COUNTERS["disconnects_total"] += 1


DASHBOARD_HTML = r'''<!doctype html>
<html lang="de"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>CORE Nexus · Relay Control</title><style>
:root{color-scheme:dark;--bg:#060b16;--panel:#0c1628;--panel2:#101e34;--line:#1d3554;--text:#eef6ff;--muted:#91a7c4;--cyan:#48d9ff;--blue:#579bff;--green:#47e0a0;--amber:#ffca70;--red:#ff7285}
*{box-sizing:border-box}body{margin:0;background:radial-gradient(ellipse at 15% -15%,#12315a 0,transparent 42%),radial-gradient(ellipse at 100% 0,#102641 0,transparent 35%),var(--bg);font:14px/1.5 Inter,Segoe UI,system-ui,sans-serif;color:var(--text)}.wrap{max-width:1400px;margin:auto;padding:26px}.top{display:flex;align-items:center;justify-content:space-between;gap:20px;margin-bottom:26px}.brand{display:flex;align-items:center;gap:14px}.logo{width:48px;height:48px;border:1px solid #28628c;background:linear-gradient(135deg,#163c68,#0c182c);border-radius:15px;display:grid;place-items:center;color:var(--cyan);font-size:24px;box-shadow:0 0 28px #2bbdf31c}.eyebrow{font-size:11px;letter-spacing:.19em;color:var(--cyan);font-weight:800}.brand h1{font-size:23px;margin:0;letter-spacing:.03em}.sub{color:var(--muted);margin-top:2px}.pill{display:inline-flex;align-items:center;gap:8px;padding:8px 12px;border:1px solid var(--line);border-radius:999px;color:var(--muted);background:#0a1424}.dot{width:8px;height:8px;border-radius:50%;background:var(--green);box-shadow:0 0 12px #47e0a0}.hero{display:flex;align-items:center;justify-content:space-between;gap:20px;padding:22px 24px;border:1px solid #21476b;border-radius:20px;background:linear-gradient(110deg,#102743e8,#0c1628ee 70%);margin-bottom:18px}.hero h2{font-size:22px;margin:0 0 5px}.hero p{margin:0;color:var(--muted)}button{cursor:pointer;border:1px solid #245178;color:var(--text);background:linear-gradient(135deg,#17416a,#132c49);padding:10px 15px;border-radius:10px;font-weight:700}button:hover{border-color:var(--cyan);box-shadow:0 0 20px #48d9ff17}.metrics{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:14px;margin:18px 0}.metric,.panel{border:1px solid var(--line);border-radius:16px;background:linear-gradient(145deg,#0e1a2d,#091321);box-shadow:0 10px 30px #00000014}.metric{padding:18px}.metric .label{color:var(--muted);font-size:12px}.metric .num{font-size:30px;font-weight:800;letter-spacing:-.04em;margin-top:7px}.metric .foot{font-size:11px;color:var(--muted);margin-top:3px}.grid{display:grid;grid-template-columns:1.15fr .85fr;gap:14px}.panel{padding:18px;min-width:0}.panelhead{display:flex;justify-content:space-between;align-items:center;gap:10px;margin-bottom:14px}.panel h3{font-size:15px;margin:0}.tag{font-size:11px;border:1px solid var(--line);border-radius:7px;padding:4px 7px;color:var(--muted)}.tablewrap{overflow:auto}table{border-collapse:collapse;width:100%;min-width:420px}th{text-align:left;font-size:11px;text-transform:uppercase;letter-spacing:.08em;color:var(--muted);font-weight:700;padding:10px;border-bottom:1px solid var(--line)}td{padding:11px 10px;border-bottom:1px solid #172942;vertical-align:top}tbody tr:last-child td{border-bottom:0}.status{display:inline-flex;align-items:center;gap:6px;font-size:11px;color:var(--green)}.status:before{content:'';width:6px;height:6px;background:currentColor;border-radius:50%}.events{display:flex;flex-direction:column;gap:8px;max-height:365px;overflow:auto}.event{display:grid;grid-template-columns:9px 1fr;gap:10px;padding:10px;border-radius:10px;background:#0a1525;border:1px solid #142740}.event:before{content:'';width:7px;height:7px;border-radius:50%;background:var(--blue);margin-top:6px}.event.error:before{background:var(--red);box-shadow:0 0 10px #ff728544}.event.warning:before{background:var(--amber)}.event.success:before{background:var(--green)}.event .msg{font-size:12px}.event .meta{color:var(--muted);font-size:10px;margin-top:3px;overflow-wrap:anywhere}.auth{position:fixed;inset:0;background:#030711ed;display:flex;align-items:center;justify-content:center;padding:20px;z-index:3}.authbox{width:min(440px,100%);padding:28px;border:1px solid #275477;border-radius:20px;background:#0b1729;box-shadow:0 20px 90px #0009}.authbox h2{margin:0 0 7px}.authbox p{color:var(--muted)}input{width:100%;padding:12px;background:#07101e;border:1px solid #24405e;border-radius:9px;color:var(--text);margin:8px 0 14px;outline:none}input:focus{border-color:var(--cyan)}.errorText{color:var(--red);font-size:12px;min-height:20px}.footer{color:#617894;text-align:center;font-size:11px;margin:22px 0 6px}.empty{color:var(--muted);padding:18px;text-align:center}@media(max-width:850px){.wrap{padding:16px}.metrics{grid-template-columns:repeat(2,minmax(0,1fr))}.grid{grid-template-columns:1fr}.hero{align-items:flex-start;flex-direction:column}.top{align-items:flex-start;flex-direction:column}}@media(max-width:450px){.metrics{grid-template-columns:1fr 1fr}.metric{padding:13px}.metric .num{font-size:25px}.brand h1{font-size:18px}}
</style></head><body>
<div class="wrap"><header class="top"><div class="brand"><div class="logo">⌘</div><div><div class="eyebrow">CONTROL OPERATIONS</div><h1>CORE NEXUS <span style="color:var(--cyan)">RELAY</span></h1><div class="sub">Verbindungsübersicht · Echtzeit-Diagnose</div></div></div><div class="pill"><span class="dot" id="liveDot"></span><span id="topStatus">Relay-Dashboard bereit</span></div></header>
<section class="hero"><div><div class="eyebrow">SYSTEMÜBERSICHT</div><h2>Netzwerk. Verbindungen. Kontrolle.</h2><p>Aktive Server und Agenten, Relay-Verkehr und letzte Systemereignisse.</p></div><button onclick="refresh(true)">⟳ &nbsp; Jetzt aktualisieren</button></section>
<section class="metrics"><article class="metric"><div class="label">AGENTEN ÜBER RENDER</div><div class="num" id="agents">—</div><div class="foot">Aktuell verbundene Geräte</div></article><article class="metric"><div class="label">SERVER VERBUNDEN</div><div class="num" id="servers">—</div><div class="foot">Aktive Server-Sitzungen</div></article><article class="metric"><div class="label">NACHRICHTEN</div><div class="num" id="messages">—</div><div class="foot">Seit letztem Neustart</div></article><article class="metric"><div class="label">FEHLER</div><div class="num" id="errors">—</div><div class="foot" id="errorFoot">Diagnoseereignisse seit Start</div></article></section>
<section class="grid"><article class="panel"><div class="panelhead"><h3>Aktive Agenten</h3><span class="tag" id="agentTag">0 Geräte</span></div><div class="tablewrap"><table><thead><tr><th>Geräte-ID</th><th>Raum-ID</th><th>Status</th></tr></thead><tbody id="agentRows"><tr><td colspan="3" class="empty">Warte auf Daten …</td></tr></tbody></table></div><div class="panelhead" style="margin-top:22px"><h3>Server-Verbindungen</h3><span class="tag" id="serverTag">0 Server</span></div><div class="tablewrap"><table><thead><tr><th>Raum-ID</th><th>Status</th></tr></thead><tbody id="serverRows"><tr><td colspan="2" class="empty">Warte auf Daten …</td></tr></tbody></table></div></article>
<article class="panel"><div class="panelhead"><h3>Verbindungsereignisse</h3><span class="tag">Letzte 250</span></div><div class="events" id="events"><div class="empty">Melde dich an, um Diagnoseereignisse zu laden.</div></div></article></section><div class="footer">CORE NEXUS · Sichere Verbindung über TLS · Dashboard-Token wird nicht an andere Dienste übertragen</div></div>
<div class="auth" id="auth"><div class="authbox"><div class="eyebrow">GESCHÜTZTER BEREICH</div><h2>Relay-Dashboard entsperren</h2><p>Gib das <b>CORE_NEXUS_DASHBOARD_TOKEN</b> aus den Render-Umgebungsvariablen ein. Es ist getrennt vom Relay-Token.</p><input id="token" type="password" autocomplete="current-password" placeholder="Dashboard-Token"><div class="errorText" id="authError"></div><button style="width:100%" onclick="login()">Dashboard öffnen</button></div></div>
<script>
let token=sessionStorage.getItem('coreNexusDashToken')||'';const $=id=>document.getElementById(id);function esc(v){return String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}function fmt(v){try{return new Date(v).toLocaleString()}catch{return v}}
async function login(){token=$('token').value.trim();if(!token){$('authError').textContent='Bitte Token eingeben.';return}await refresh(true)}
async function refresh(showError=false){try{const r=await fetch('/api/dashboard',{headers:{Authorization:'Bearer '+token},cache:'no-store'});if(r.status===401){$('auth').style.display='flex';$('authError').textContent='Token ungültig oder Dashboard-Token in Render nicht gesetzt.';return}if(!r.ok)throw new Error('HTTP '+r.status);const d=await r.json();sessionStorage.setItem('coreNexusDashToken',token);$('auth').style.display='none';$('topStatus').textContent='Live · aktualisiert '+new Date().toLocaleTimeString();$('liveDot').style.background='var(--green)';$('agents').textContent=d.metrics.agents_online;$('servers').textContent=d.metrics.servers_online;$('messages').textContent=d.metrics.messages_total;$('errors').textContent=d.metrics.errors_total;$('agentTag').textContent=d.agents.length+' Geräte';$('serverTag').textContent=d.servers.length+' Server';$('errorFoot').textContent=d.metrics.disconnects_total+' Verbindungsabbrüche insgesamt';$('agentRows').innerHTML=d.agents.length?d.agents.map(a=>`<tr><td><code>${esc(a.device)}</code></td><td>${esc(a.room)}</td><td><span class="status">Verbunden</span></td></tr>`).join(''):'<tr><td colspan="3" class="empty">Keine Agenten über Render verbunden</td></tr>';$('serverRows').innerHTML=d.servers.length?d.servers.map(s=>`<tr><td>${esc(s.room)}</td><td><span class="status">Verbunden</span></td></tr>`).join(''):'<tr><td colspan="2" class="empty">Kein Server über Render verbunden</td></tr>';$('events').innerHTML=d.events.length?d.events.map(e=>`<div class="event ${esc(e.kind)}"><div><div class="msg">${esc(e.message)}</div><div class="meta">${esc(fmt(e.time))} · ${esc(e.role)}${e.device?' · Gerät '+esc(e.device):''}${e.room?' · Raum '+esc(e.room):''}</div></div></div>`).join(''):'<div class="empty">Noch keine Ereignisse aufgezeichnet.</div>'}catch(e){$('topStatus').textContent='Dashboard nicht erreichbar';$('liveDot').style.background='var(--red)';if(showError){$('auth').style.display='flex';$('authError').textContent='Verbindungsfehler: '+e.message}}}
$('token').addEventListener('keydown',e=>{if(e.key==='Enter')login()});if(token){$('token').value=token;refresh()}else $('auth').style.display='flex';setInterval(()=>{if(token)refresh()},5000);
</script></body></html>'''
