@echo off
setlocal
cd /d "%~dp0"
where pyw >nul 2>&1
if %errorlevel%==0 (
  start "CORE Nexus Adminserver" pyw -3 adminserver.py
  exit /b 0
)
where pythonw >nul 2>&1
if %errorlevel%==0 (
  start "CORE Nexus Adminserver" pythonw adminserver.py
  exit /b 0
)
where py >nul 2>&1
if %errorlevel%==0 (py -3 adminserver.py) else (python adminserver.py)
