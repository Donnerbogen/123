
param(
  [Parameter(Mandatory=$true)]
  [string]$Mode,

  [string]$AllowedJson = "[]",

  [string]$Kind = "focus",

  [string]$OwnPid = "0"
)

Add-Type @"
using System;
using System.Runtime.InteropServices;

public class WinApi {
  [DllImport("user32.dll")]
  public static extern bool EnumWindows(
    EnumWindowsProc callback,
    IntPtr extra
  );

  public delegate bool EnumWindowsProc(
    IntPtr hwnd,
    IntPtr lParam
  );

  [DllImport("user32.dll")]
  public static extern bool IsWindowVisible(
    IntPtr hwnd
  );

  [DllImport("user32.dll")]
  public static extern int GetWindowText(
    IntPtr hwnd,
    System.Text.StringBuilder text,
    int count
  );

  [DllImport("user32.dll")]
  public static extern bool ShowWindow(
    IntPtr hwnd,
    int command
  );

  [DllImport("user32.dll")]
  public static extern uint GetWindowThreadProcessId(
    IntPtr hwnd,
    out uint processId
  );

  [DllImport("user32.dll")]
  public static extern bool IsIconic(
    IntPtr hwnd
  );
}
"@

function Get-WindowTitle($handle) {
  $builder = New-Object System.Text.StringBuilder 512

  [void][WinApi]::GetWindowText(
    $handle,
    $builder,
    $builder.Capacity
  )

  return $builder.ToString()
}

function Get-ProcessPath([uint32]$processId) {
  try {
    return (
      Get-Process -Id $processId -ErrorAction Stop
    ).Path
  }
  catch {
    return ""
  }
}

/* ---------------- LAUFENDE PROGRAMME ---------------- */

if ($Mode -eq "list") {
  $items = New-Object System.Collections.Generic.List[object]

  [WinApi]::EnumWindows({
    param($handle, $lParam)

    if ([WinApi]::IsWindowVisible($handle)) {
      $title = Get-WindowTitle $handle

      [uint32]$windowPid = 0

      [void][WinApi]::GetWindowThreadProcessId(
        $handle,
        [ref]$windowPid
      )

      $processPath = Get-ProcessPath $windowPid

      if ($title -and $processPath) {
        $items.Add(@{
          title = $title
          path = $processPath
        })
      }
    }

    return $true
  }, [IntPtr]::Zero) | Out-Null

  ConvertTo-Json `
    -InputObject @($items) `
    -Compress `
    -Depth 4

  exit
}

/* ---------------- FOKUSMODUS ---------------- */

if ($Mode -eq "enforce") {

  try {
    $allowed = @(
      $AllowedJson | ConvertFrom-Json
    )
  }
  catch {
    $allowed = @()
  }

  $ownPidInt = 0

  try {
    $ownPidInt = [int]$OwnPid
  }
  catch {
    $ownPidInt = 0
  }

  $safeProcesses = @(
    "explorer",
    "dwm",
    "sihost",
    "StartMenuExperienceHost",
    "ShellExperienceHost",
    "SearchHost",
    "TextInputHost",
    "LockApp",
    "SystemSettings",
    "ApplicationFrameHost",
    "taskmgr"
  )

  $ownProcessNames = @(
    "Focus System",
    "Focus-System"
  )

  [WinApi]::EnumWindows({

    param($handle, $lParam)

    if (-not [WinApi]::IsWindowVisible($handle)) {
      return $true
    }

    if ([WinApi]::IsIconic($handle)) {
      return $true
    }

    $title = Get-WindowTitle $handle

    if (-not $title) {
      return $true
    }

    [uint32]$windowPid = 0

    [void][WinApi]::GetWindowThreadProcessId(
      $handle,
      [ref]$windowPid
    )

    # Eigene Anwendung anhand der Prozess-ID schützen.
    if ($windowPid -eq $ownPidInt) {
      return $true
    }

    try {
      $process = Get-Process `
        -Id $windowPid `
        -ErrorAction Stop

      $processName = $process.ProcessName
    }
    catch {
      return $true
    }

    # Wichtige Windows-Prozesse schützen.
    if ($safeProcesses -contains $processName) {
      return $true
    }

    # Eigene Anwendung anhand des Namens schützen.
    if ($ownProcessNames -contains $processName) {
      return $true
    }

    $processPath = Get-ProcessPath $windowPid

    # Erlaubte Programme nicht minimieren.
    if ($processPath) {
      $isAllowed = $false

      foreach ($allowedPath in $allowed) {
        if (
          $allowedPath -and
          $allowedPath.ToLowerInvariant() -eq
          $processPath.ToLowerInvariant()
        ) {
          $isAllowed = $true
          break
        }
      }

      if ($isAllowed) {
        return $true
      }
    }

    # Alle übrigen Fenster minimieren.
    [void][WinApi]::ShowWindow($handle, 6)

    return $true

  }, [IntPtr]::Zero) | Out-Null
}

