CORE Nexus Server

1. setup.bat: Menue fuer Installation/Reparatur, Deinstallation und Autostart.
2. start.bat: Startet die bereits installierte Anwendung sofort.
3. Adminserver-Zugriff: admin_config.example.json wird bei der Installation bei Bedarf nach admin_config.json kopiert. Dort einen langen geheimen admin_token setzen und exakt denselben Token in der Adminserver-Konfiguration hinterlegen.
4. Adminserver-LAN-Port: TCP 47623. Falls Windows-Firewall eingehende Verbindungen blockiert, diesen Port nur im vertrauenswuerdigen Netzwerk freigeben.
5. Externe Verbindung: Server und Adminserver muessen dieselbe Render-Relay-URL, den Relay-Token und dieselbe Raum-ID verwenden.

setup.bat fragt vor jeder Aktion nach deiner Auswahl. Bei der Deinstallation kannst du lokale Daten behalten oder loeschen.

ADMINSERVER-AUTOMATISCHE ERKENNUNG
Wenn der Server im Adminserver automatisch erscheinen soll, muss er mit Render verbunden sein. Verwende auf allen Servern denselben geheimen admin_token in admin_config.json. Die room_id bleibt pro Serverraum eindeutig. Aktualisiere das Render-Relay mit der neuen GitHub/relay/main.py.

ZENTRALE SERVERERSTELLUNG
Wenn das Serverpaket vom angemeldeten CORE Nexus Root-Admin erstellt wurde, sind Raum-ID, Relay-Konfiguration, Service-Admin-Token und Owner-Benutzername bereits eingerichtet. Beim ersten Start wird der Owner aus einem Passwort-Hash in die lokale Datenbank übernommen; das Klartext-Passwort befindet sich nicht im Paket.


UI-UPDATE: Die Geräteansicht verwendet eine kompakte Aktionsauswahl statt vieler nebeneinanderliegender Buttons. Checkbox-Klicks setzen zugleich das Einzelgerät; die Zeilenauswahl bleibt bei automatischen Aktualisierungen erhalten. Bei kleinen Fenstern kann die Gerätetabelle horizontal gescrollt werden.
