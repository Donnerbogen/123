@echo off
setlocal
title Focus System - Windows-Suche einrichten
set "BASE=%~dp0"
set "EXE=%BASE%Focus-System\Focus System.exe"
if not exist "%EXE%" set "EXE=%BASE%Focus System.exe"
if not exist "%EXE%" set "EXE=%BASE%dist\win-unpacked\Focus System.exe"
if not exist "%EXE%" (
  echo Focus System.exe wurde nicht gefunden.
  echo Lege diese BAT neben den Ordner Focus-System oder neben die Build-Ausgabe.
  pause
  exit /b 1
)
for %%I in ("%EXE%") do set "APPDIR=%%~dpI"
set "LINKDIR=%APPDATA%\Microsoft\Windows\Start Menu\Programs"
powershell -NoProfile -ExecutionPolicy Bypass -Command "$s=(New-Object -ComObject WScript.Shell).CreateShortcut('%LINKDIR%\Focus System.lnk');$s.TargetPath='%EXE%';$s.WorkingDirectory='%APPDIR%';$s.Description='Focus System';$s.Save()"
if errorlevel 1 (echo Verknuepfung konnte nicht erstellt werden.) else (echo Focus System wurde dem Startmenue hinzugefuegt.)
echo Es wurden keine Programmdateien kopiert oder verschoben.
pause
