"""Einfaches, integriertes CORE KeySafe-Handbuch."""
from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit, QPushButton,
    QTextBrowser
)

HANDBOOK_HTML = r"""
<style>
body { color:#e8f4fb; background:#08111d; font-family:Arial,sans-serif; line-height:1.55; }
h1 { color:#52dce8; font-size:23px; }
h2 { color:#7de8f0; font-size:17px; margin-top:22px; }
p, li { font-size:13px; }
.card { background:#0c1b2a; border:1px solid #244154; border-radius:8px; padding:10px; margin:8px 0; }
a { color:#7de8f0; }
.small { color:#a9c4d4; font-size:12px; }
</style>
<h1>CORE KeySafe – Handbuch</h1>
<p>Die wichtigsten Funktionen einfach erklärt. Du kannst oben nach einem Begriff suchen oder direkt ein Kapitel auswählen.</p>
<div class="card"><b>Kurzer Überblick</b><br>
CORE KeySafe speichert deine Tresoreinträge lokal in einer verschlüsselten Datei. Das Master-Passwort schützt den Tresor.
Bewahre es sicher auf: Es gibt in dieser Version keine Funktion, ein vergessenes Master-Passwort zurückzusetzen.</div>
<h2 id="start">1. Start und Lizenz</h2>
<ul>
<li>Starte CORE KeySafe und gib bei Aufforderung deinen gültigen Lizenzschlüssel ein.</li>
<li>Die Lizenzprüfung benötigt normalerweise eine Internetverbindung. Eine gültige Offline-Freigabe kann zeitweise weiterhelfen.</li>
<li>Ohne gültige Lizenz bleibt der Tresorbereich gesperrt.</li>
</ul>
<h2 id="vault">2. Tresor erstellen oder öffnen</h2>
<ul>
<li>Wähle <b>„Tresor öffnen / erstellen“</b>.</li>
<li>Beim ersten Start legst du ein Master-Passwort fest und bestätigst es. Die Anwendung verlangt mindestens 12 Zeichen.</li>
<li>Beim späteren Öffnen gibst du das Master-Passwort ein.</li>
<li>Verwende ein langes, einzigartiges Passwort, das du nicht für andere Konten nutzt.</li>
</ul>
<h2 id="entries">3. Einträge verwalten</h2>
<ul>
<li><b>＋ Eintrag:</b> legt einen neuen Eintrag an.</li>
<li>Doppelklicke auf eine Tabellenzeile, um einen Eintrag zu bearbeiten.</li>
<li>Du kannst Titel, Benutzername, Passwort, Webseite, Kategorie, Notizen und Tags eintragen.</li>
<li>Nutze die Suche, um Einträge anhand ihrer angezeigten Daten schneller zu finden.</li>
<li><b>Speichern:</b> verschlüsselt den aktuellen Tresor und schreibt ihn lokal.</li>
</ul>
<h2 id="passwords">4. Passwörter generieren</h2>
<ul>
<li>Wähle <b>„Passwort generieren“</b> und lege die Länge fest.</li>
<li>Es sind 12 bis 128 Zeichen möglich. Längere Passwörter sind in der Regel schwerer zu erraten.</li>
<li>Kopiere oder übertrage das generierte Passwort sicher in den gewünschten Eintrag. Teile es nicht mit anderen.</li>
</ul>
<h2 id="lock">5. Sperren und automatische Sperre</h2>
<ul>
<li><b>Sperren:</b> schließt den geöffneten Tresor in der Oberfläche und entfernt die Einträge aus der angezeigten Liste.</li>
<li>Nach einer Zeit ohne Aktivität sperrt sich der Tresor automatisch. Die Dauer wird in der Anwendungskonfiguration festgelegt.</li>
<li>Zum Weiterarbeiten öffnest du den Tresor erneut mit dem Master-Passwort.</li>
</ul>
<h2 id="import">6. Tresor importieren</h2>
<ul>
<li>Über <b>„Importordner öffnen“</b> gelangst du zum lokalen Importordner.</li>
<li>Lege eine vertrauenswürdige Datei mit der Endung <code>.vault</code> in diesen Ordner und kehre zur Anwendung zurück.</li>
<li>Wenn ein Tresor bereits existiert, fragt die Anwendung vor einem Wechsel nach. Gib das Master-Passwort des importierten Tresors ein.</li>
<li>Ein Import kann den aktuell verwendeten Tresor wechseln. Sichere wichtige Dateien vor dem Import separat.</li>
</ul>
<h2 id="storage">7. Wo liegen die Daten?</h2>
<p>Die Anwendung legt ihre Daten im Benutzerprofil ab, im Ordner <code>Core Network/CORE KeySafe</code> unter dem jeweiligen Konfigurationsbereich des Betriebssystems.</p>
<ul>
<li><b>vault/</b> – verschlüsselte Tresordatei.</li>
<li><b>Import/</b> – Dateien, die zum Import bereitgestellt werden.</li>
<li><b>state/</b> – lokale Lizenz- und Statusinformationen.</li>
</ul>
<p>Schütze dein Benutzerkonto und mache sichere Backups der verschlüsselten Tresordatei. Speichere das Master-Passwort nicht zusammen mit dem Backup.</p>
<h2 id="security">8. Sicherheit – das Wichtigste</h2>
<ul>
<li>Gib dein Master-Passwort und deinen Lizenzschlüssel nicht an andere weiter.</li>
<li>Installiere Updates und nutze nur vertrauenswürdige Geräte.</li>
<li>Die Tresordatei ist verschlüsselt; trotzdem solltest du deinen Computer vor Schadsoftware und unbefugtem Zugriff schützen.</li>
<li>Das Sperren der Oberfläche ersetzt keine sichere Anmeldung am Betriebssystem.</li>
<li>Wenn du ein Master-Passwort vergisst, kann die verschlüsselte Tresordatei möglicherweise nicht mehr geöffnet werden.</li>
</ul>
<h2 id="trouble">9. Häufige Probleme</h2>
<ul>
<li><b>Lizenz wird nicht akzeptiert:</b> prüfe die Eingabe und die Internetverbindung. Bei einem Offline-Ticket kann eine erneute Onlineprüfung nötig sein.</li>
<li><b>Tresor lässt sich nicht öffnen:</b> prüfe das Master-Passwort. Eine Fehlermeldung kann auch auf eine beschädigte Datei hinweisen.</li>
<li><b>Import wird nicht angezeigt:</b> prüfe, ob eine gültige <code>.vault</code>-Datei im Importordner liegt.</li>
<li><b>Die App startet nicht:</b> notiere die vollständige Fehlermeldung und wende dich mit dieser Information an den Support.</li>
</ul>
<h2 id="help">10. Hilfe und Grenzen</h2>
<p>Dieses Handbuch beschreibt Funktionen, die in dieser Programmversion vorhanden sind. Nicht vorhandene Funktionen werden hier nicht als verfügbar dargestellt. Wenn du Hilfe benötigst, nenne die verwendete Windows-/Linux-Version und die genaue Fehlermeldung – niemals dein Master-Passwort oder echte Tresoreinträge.</p>
<p class="small">CORE KeySafe · Kurzes Benutzerhandbuch</p>
"""

class HandbookDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("CORE KeySafe – Handbuch")
        self.resize(760, 680)
        self.setMinimumSize(560, 460)
        self.setStyleSheet("""
            QDialog { background:#08111d; color:#e8f4fb; }
            QLineEdit { background:#0c1b2a; color:#f0f7ff; border:1px solid #244154; padding:8px; border-radius:6px; }
            QPushButton { background:#10313d; color:#eafaff; border:1px solid #236b7a; padding:8px 12px; border-radius:7px; }
            QPushButton:hover { background:#164958; }
            QTextBrowser { background:#08111d; color:#e8f4fb; border:1px solid #244154; border-radius:8px; padding:8px; }
        """)
        layout = QVBoxLayout(self)
        title = QLabel("Hilfe & Handbuch")
        title.setStyleSheet("color:#52dce8;font-size:20px;font-weight:700;")
        layout.addWidget(title)
        row = QHBoxLayout()
        self.search = QLineEdit()
        self.search.setPlaceholderText("Handbuch durchsuchen …")
        self.search.setClearButtonEnabled(True)
        row.addWidget(self.search)
        close = QPushButton("Schließen")
        close.clicked.connect(self.accept)
        row.addWidget(close)
        layout.addLayout(row)
        self.browser = QTextBrowser()
        self.browser.setOpenExternalLinks(False)
        self.browser.setHtml(HANDBOOK_HTML)
        layout.addWidget(self.browser, 1)
        self.search.textChanged.connect(self.find_text)

    def find_text(self, text):
        if not text:
            self.browser.moveCursor(self.browser.textCursor().Start)
            return
        from PySide6.QtGui import QTextDocument
        self.browser.find(text, QTextDocument.FindFlag(0))
