# CORE Nexus Relay – GitHub repository folder

This folder is the repository root to upload to GitHub. Render can deploy the relay from this folder using `render.yaml`.

## What this service does
- Provides an authenticated WebSocket endpoint at `/ws`.
- Accepts `server` and `agent` clients registered into a shared `room`.
- Forwards JSON message envelopes between connected peers. It does not implement CORE Nexus commands or store application data.
- Uses `CORE_NEXUS_RELAY_TOKEN` from Render environment variables; no access token is committed to GitHub.

## Deploy
1. Create a private or public GitHub repository and upload the contents of this `GitHub` folder (not the outer parent folder).
2. In Render, create a Blueprint from that repository. Render reads `render.yaml` and generates `CORE_NEXUS_RELAY_TOKEN`.
3. Copy the generated token into the local server/agent configuration only after their relay transport has been integrated.

## Protocol
Connect to `wss://YOUR-RENDER-SERVICE.onrender.com/ws?token=YOUR_TOKEN`.
The first JSON message must be `{"type":"register","role":"server|agent","room":"a-shared-room-id-at-least-8-chars"}`. Subsequent JSON messages are forwarded inside a `relay_message` envelope. Both endpoints must implement this protocol.

## Important integration note
The included legacy Windows Server and Agent still use the original direct TCP/UDP LAN protocol. Deploying this relay alone does **not** make those two legacy programs internet-capable. They must be updated to use the WebSocket protocol above before remote devices can communicate through Render. Do not expose the old TCP port publicly or configure router port forwarding as a workaround.
