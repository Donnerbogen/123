from pathlib import Path
import subprocess, sys, shutil
ROOT = Path(__file__).resolve().parent
NAME = "CORE-Nexus-Server"
ENTRY = ROOT / "server.py"
REQ = ROOT / "requirements.txt"
DIST = ROOT / "release" / NAME

def run(cmd):
    print("\n>", " ".join(map(str, cmd)), flush=True)
    subprocess.check_call(list(map(str, cmd)), cwd=ROOT)

def main():
    run([sys.executable, "-m", "pip", "install", "--upgrade", "pip", "pyinstaller"])
    if REQ.exists(): run([sys.executable, "-m", "pip", "install", "-r", REQ])
    work = ROOT / "build"; spec = ROOT / "spec"
    if DIST.exists(): shutil.rmtree(DIST)
    cmd=[sys.executable,"-m","PyInstaller","--noconfirm","--clean","--onedir","--windowed","--name",NAME,"--distpath",str(ROOT/"release"),"--workpath",str(work),"--specpath",str(spec),str(ENTRY)]
    run(cmd)
    (DIST/"data").mkdir(parents=True,exist_ok=True)
    # Keep existing user configuration out of the EXE and beside it in data/.
    legacy = ["relay_config.json", "admin_config.json"]
    for filename in legacy:
        src=ROOT/filename
        if src.exists() and not (DIST/"data"/filename).exists(): shutil.copy2(src,DIST/"data"/filename)
    print("\nFertig:", DIST)
    print("Kopiere immer den gesamten Programmordner. Den Ordner data/ bei Updates niemals ersetzen.")

if __name__ == "__main__": main()
