"""CORE Nexus LAN server — native Windows Tkinter dashboard.
All persistent application data lives in Server/data/core_nexus.sqlite3.
Run with: python server.py
"""
from __future__ import annotations
import base64, csv, hashlib, hmac, json, os, queue, secrets, socket, sqlite3, threading, time, uuid
from pathlib import Path
from datetime import datetime
import tkinter as tk
from tkinter import ttk, messagebox, simpledialog

ROOT = Path(__file__).resolve().parent
DATA = ROOT / 'data'
DB = DATA / 'core_nexus.sqlite3'
HOST = '0.0.0.0'
PORT = 47621
DISCOVERY_PORT = 47622
APP = 'CORE Nexus'
PERMISSIONS = {
    'view_devices': 'Geräte anzeigen', 'view_system_info': 'Systeminformationen ansehen',
    'remote_view': 'Bildschirm ansehen', 'remote_input': 'Maus und Tastatur steuern',
    'register_devices': 'Geräte freigeben', 'manage_grants': 'Gerätefreigaben verwalten',
    'close_agents': 'Alle Agenten schließen', 'manage_accounts': 'Konten verwalten',
    'server_settings': 'Servereinstellungen verwalten', 'view_logs': 'Protokolle ansehen'
}

def password_hash(password: str, salt: bytes | None = None) -> str:
    salt = salt or secrets.token_bytes(16)
    digest = hashlib.pbkdf2_hmac('sha256', password.encode('utf-8'), salt, 310_000)
    return base64.b64encode(salt + digest).decode('ascii')

def password_ok(password: str, stored: str) -> bool:
    try:
        raw = base64.b64decode(stored.encode('ascii'))
        return hmac.compare_digest(raw[16:], hashlib.pbkdf2_hmac('sha256', password.encode('utf-8'), raw[:16], 310_000))
    except Exception:
        return False

class NexusServer:
    def __init__(self):
        DATA.mkdir(parents=True, exist_ok=True)
        self.db_lock = threading.RLock()
        self.clients: dict[str, socket.socket] = {}
        self.client_lock = threading.RLock()
        self.ui_events: queue.Queue = queue.Queue()
        self.running = True
        self.current_account = None
        self.poll_started = False
        self.remote_frames = {}
        self.remote_commands = {}
        self.remote_device = None
        self.remote_window = None
        self.remote_image_label = None
        self.remote_photo = None
        self._last_periodic_refresh = 0
        self.db = sqlite3.connect(DB, check_same_thread=False)
        self.db.row_factory = sqlite3.Row
        self._schema()
        self.tcp = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.tcp.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.tcp.bind((HOST, PORT)); self.tcp.listen(40); self.tcp.settimeout(1)
        threading.Thread(target=self._accept_loop, daemon=True).start()
        threading.Thread(target=self._discovery_loop, daemon=True).start()
        self.root = tk.Tk(); self.root.title('CORE Nexus | Device Control Center'); self.root.geometry('1050x680'); self.root.minsize(850, 560)
        self._style(); self.root.geometry('900x600'); self.root.minsize(700, 480); self.root.protocol('WM_DELETE_WINDOW', self.close)
        self._ensure_owner()

    def _schema(self):
        with self.db_lock:
            self.db.executescript('''
            CREATE TABLE IF NOT EXISTS accounts(id INTEGER PRIMARY KEY, username TEXT UNIQUE NOT NULL, password_hash TEXT NOT NULL, is_owner INTEGER NOT NULL DEFAULT 0, permissions TEXT NOT NULL DEFAULT '[]', created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, active INTEGER NOT NULL DEFAULT 1);
            CREATE TABLE IF NOT EXISTS devices(id TEXT PRIMARY KEY, name TEXT NOT NULL, ip TEXT, approved INTEGER NOT NULL DEFAULT 0, consent INTEGER NOT NULL DEFAULT 0, last_seen TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, os TEXT DEFAULT '', boot_id TEXT DEFAULT '', notes TEXT DEFAULT '');
            CREATE TABLE IF NOT EXISTS grants(device_id TEXT NOT NULL, account_id INTEGER NOT NULL, permissions TEXT NOT NULL, PRIMARY KEY(device_id,account_id));
            CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY, value TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS logs(id INTEGER PRIMARY KEY, at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, actor TEXT, action TEXT NOT NULL, detail TEXT);
            '''); self.db.commit()

    def _ensure_owner(self):
        row = self.db.execute('SELECT id FROM accounts WHERE is_owner=1').fetchone()
        if not row:
            self.root.after(300, self._setup_owner)
        else:
            self.root.after(150, self._show_login)

    def _setup_owner(self):
        self.root.deiconify()
        self.root.lift()
        self.root.title('CORE Nexus | Owner-Ersteinrichtung')
        messagebox.showinfo(APP, 'Ersteinrichtung: Lege jetzt das zentrale Owner-Konto an. Das Passwort wird nur als sicherer Hash gespeichert.', parent=self.root)
        username = simpledialog.askstring('Owner einrichten', 'Owner-Benutzername:', parent=self.root)
        if not username or len(username.strip()) < 2:
            messagebox.showerror(APP, 'Einrichtung abgebrochen. Starte den Server erneut, um den Owner einzurichten.', parent=self.root); self.root.after(300, self._setup_owner); return
        password = simpledialog.askstring('Owner einrichten', 'Owner-Passwort (mindestens 4 Zeichen):', show='*', parent=self.root)
        if not password or len(password) < 4:
            messagebox.showerror(APP, 'Das Passwort muss mindestens 4 Zeichen lang sein.', parent=self.root); self.root.after(300, self._setup_owner); return
        with self.db_lock:
            self.db.execute('INSERT INTO accounts(username,password_hash,is_owner,permissions) VALUES(?,?,1,?)', (username.strip(), password_hash(password), json.dumps(list(PERMISSIONS))))
            self.db.commit()
        self._log(username.strip(), 'owner_setup', 'Owner-Konto angelegt'); self.refresh_accounts()
        messagebox.showinfo(APP, 'Owner-Konto wurde eingerichtet. Bitte melde dich jetzt an.', parent=self.root)
        self._show_login()

    def _show_login(self):
        # Use the main window for login instead of a transient dialog whose
        # parent was withdrawn. This avoids the blank/invisible-window issue
        # after the first Owner setup on some Windows/Tk combinations.
        for child in self.root.winfo_children():
            try:
                child.destroy()
            except tk.TclError:
                pass
        self.root.title('CORE Nexus | Server-Anmeldung')
        self.root.geometry('430x360')
        self.root.minsize(430, 360)
        self.root.deiconify()
        self.root.lift()
        outer = ttk.Frame(self.root, padding=(30, 24))
        outer.pack(fill='both', expand=True)
        ttk.Label(outer, text='CORE NEXUS', style='Title.TLabel').pack(pady=(24, 6))
        ttk.Label(outer, text='Bitte am Server anmelden', style='Sub.TLabel').pack(pady=(0, 22))
        form = ttk.Frame(outer)
        form.pack(fill='x', padx=18)
        ttk.Label(form, text='Benutzername').pack(anchor='w')
        user = ttk.Entry(form)
        user.pack(fill='x', pady=(4, 12))
        ttk.Label(form, text='Passwort').pack(anchor='w')
        pw = ttk.Entry(form, show='*')
        pw.pack(fill='x', pady=(4, 12))
        error = ttk.Label(outer, text='', foreground='#ff8585')
        error.pack(pady=(0, 2))

        def attempt(event=None):
            username = user.get().strip()
            password = pw.get()
            with self.db_lock:
                account = self.db.execute('SELECT * FROM accounts WHERE username=? AND active=1', (username,)).fetchone()
            if not account or not password_ok(password, account['password_hash']):
                error.configure(text='Anmeldung fehlgeschlagen. Zugangsdaten prüfen.')
                pw.delete(0, 'end')
                pw.focus_set()
                self._log(username or 'unknown', 'server_login_failed', 'Ungültige Zugangsdaten')
                return
            self.current_account = dict(account)
            try:
                self.current_account['permissions'] = json.loads(account['permissions'])
            except Exception:
                self.current_account['permissions'] = []
            self._log(username, 'server_login_success', 'Dashboard-Anmeldung erfolgreich')
            self._show_dashboard()

        ttk.Button(outer, text='Anmelden', command=attempt).pack(pady=(12, 5))
        ttk.Button(outer, text='Ohne Anmeldung fortfahren', command=self._continue_as_guest).pack(pady=(0, 8))
        self.root.bind('<Return>', attempt)
        user.focus_set()

    def _show_dashboard(self):
        for child in self.root.winfo_children():
            try:
                child.destroy()
            except tk.TclError:
                pass
        try:
            self.root.unbind('<Return>')
        except tk.TclError:
            pass
        self.root.title('CORE Nexus | Device Control Center')
        self.root.geometry('1050x680')
        self.root.minsize(850, 560)
        self._build_ui()
        self.root.deiconify()
        self.root.lift()
        if not self.poll_started:
            self.poll_started = True
            self.root.after(200, self._poll_ui)

    def _continue_as_guest(self):
        self.current_account = None
        self._log('Gast', 'guest_dashboard_opened', 'Dashboard ohne Anmeldung geöffnet')
        self._show_dashboard()

    def _logout_to_guest(self):
        if self.current_account:
            username = self.current_account.get('username', 'unbekannt')
            self._log(username, 'server_logout', 'Abmeldung; Dashboard läuft im Gastmodus weiter')
        self.current_account = None
        self._show_dashboard()

    def _login_from_guest(self):
        self._show_login()

    def is_owner_context(self):
        # Der lokale Gastmodus darf das Dashboard vollständig bedienen, auch ohne Konto.
        return self.current_account is None or bool((self.current_account or {}).get('is_owner'))

    def has_permission(self, permission):
        account = self.current_account or {}
        return self.current_account is None or bool(account.get('is_owner')) or permission in account.get('permissions', [])

    def require_permission(self, permission):
        if self.has_permission(permission): return True
        messagebox.showwarning(APP, 'Du besitzt nicht die erforderliche Berechtigung.', parent=self.root)
        return False

    def _style(self):
        self.root.configure(bg='#080e1b'); s=ttk.Style(); s.theme_use('clam')
        s.configure('.', background='#0d1728', foreground='#eaf2ff', fieldbackground='#111f34', bordercolor='#203854')
        s.configure('TFrame', background='#0d1728'); s.configure('TLabel', background='#0d1728', foreground='#eaf2ff', font=('Segoe UI', 10))
        s.configure('Title.TLabel', font=('Segoe UI', 21, 'bold'), foreground='#58baff'); s.configure('Sub.TLabel', foreground='#91a8c6')
        s.configure('TButton', background='#183454', foreground='#ffffff', padding=8); s.map('TButton', background=[('active','#23649b')])
        s.configure('Treeview', background='#0b1423', fieldbackground='#0b1423', foreground='#eaf2ff', rowheight=27)
        s.configure('Treeview.Heading', background='#172b45', foreground='#bfe7ff'); s.configure('Treeview', rowheight=30, borderwidth=0); s.map('TButton', foreground=[('disabled','#70839d')])
        s.configure('TNotebook', background='#0d1728'); s.configure('TNotebook.Tab', background='#172b45', foreground='#fff', padding=(12,8))

    def _build_ui(self):
        header=ttk.Frame(self.root,padding=(18,15)); header.pack(fill='x')
        ttk.Label(header,text='CORE NEXUS',style='Title.TLabel').pack(side='left')
        ttk.Label(header,text='DEVICE CONTROL CENTER  •  LAN ONLY',style='Sub.TLabel').pack(side='left',padx=18,pady=(9,0))
        self.status=ttk.Label(header,text=f'SERVER ONLINE  |  TCP {PORT}  |  DISCOVERY {DISCOVERY_PORT}',foreground='#7be0ad'); self.status.pack(side='right',pady=10)
        self.tabs=ttk.Notebook(self.root); self.tabs.pack(fill='both',expand=True,padx=16,pady=(0,16))
        self.overview_tab=ttk.Frame(self.tabs,padding=16); self.device_tab=ttk.Frame(self.tabs,padding=12); self.account_tab=ttk.Frame(self.tabs,padding=12); self.log_tab=ttk.Frame(self.tabs,padding=12); self.settings_tab=ttk.Frame(self.tabs,padding=16)
        self.tabs.add(self.overview_tab,text='Übersicht'); self.tabs.add(self.device_tab,text='Geräte'); self.tabs.add(self.account_tab,text='Konten & Rechte'); self.tabs.add(self.log_tab,text='Aktivitätsprotokoll'); self.tabs.add(self.settings_tab,text='System')
        self._build_overview()
        who = (self.current_account or {}).get('username')
        ttk.Label(header, text=(f'ANGEMELDET: {who}' if who else 'GASTMODUS • keine Anmeldung'), style='Sub.TLabel').pack(side='right', padx=12, pady=10)
        if who:
            ttk.Button(header, text='Abmelden', command=self._logout_to_guest).pack(side='right', padx=6, pady=6)
        else:
            ttk.Button(header, text='Anmelden', command=self._login_from_guest).pack(side='right', padx=6, pady=6)
        # Übersicht + Suche für eine schnellere Geräteverwaltung.
        summary=ttk.Frame(self.device_tab); summary.pack(fill='x',pady=(0,8))
        self.device_summary=ttk.Label(summary,text='Geräte: 0  |  Online: 0  |  Freigegeben: 0  |  Zustimmung fehlt: 0',style='Sub.TLabel')
        self.device_summary.pack(side='left')
        searchbar=ttk.Frame(self.device_tab); searchbar.pack(fill='x',pady=(0,8))
        ttk.Label(searchbar,text='Suchen:').pack(side='left',padx=(0,6))
        self.device_search=tk.StringVar()
        search_entry=ttk.Entry(searchbar,textvariable=self.device_search,width=34)
        search_entry.pack(side='left',fill='x',expand=True)
        self.device_search.trace_add('write',lambda *_: self.refresh_devices())
        ttk.Button(searchbar,text='Suche leeren',command=lambda:self.device_search.set('')).pack(side='left',padx=7)
        ttk.Label(searchbar,text='Status:').pack(side='left',padx=(10,4))
        self.device_filter=tk.StringVar(value='Alle')
        filter_box=ttk.Combobox(searchbar,textvariable=self.device_filter,values=('Alle','Online','Offline','Freigabe ausstehend','Freigegeben'),state='readonly',width=22)
        filter_box.pack(side='left'); filter_box.bind('<<ComboboxSelected>>',lambda _e:self.refresh_devices())
        toolbar=ttk.Frame(self.device_tab); toolbar.pack(fill='x',pady=(0,10))
        ttk.Button(toolbar,text='Aktualisieren',command=self.refresh_devices).pack(side='left',padx=(0,5))
        ttk.Button(toolbar,text='Gerät freigeben',command=self.approve_device).pack(side='left',padx=5)
        ttk.Button(toolbar,text='Freigabe widerrufen',command=self.revoke_device).pack(side='left',padx=5)
        ttk.Button(toolbar,text='Gerätedetails bearbeiten',command=self.edit_device_details).pack(side='left',padx=5)
        ttk.Button(toolbar,text='Offline-Gerät entfernen',command=self.delete_device).pack(side='left',padx=5)
        ttk.Button(toolbar,text='Fernsteuerung öffnen',command=self.open_remote).pack(side='left',padx=5)
        ttk.Button(toolbar,text='Fernsteuerung beenden',command=self.stop_remote).pack(side='left',padx=5)
        ttk.Button(toolbar,text='Agentensperre aufheben',command=self.reset_agent_lock).pack(side='right',padx=(5,0))
        ttk.Button(toolbar,text='Alle Agenten schließen',command=self.close_all_agents).pack(side='right')
        cols=('name','ip','connection','approved','consent','last_seen','os'); self.device_tree=ttk.Treeview(self.device_tab,columns=cols,show='headings',selectmode='browse')
        for c,t,w in [('name','Gerät',165),('ip','IP-Adresse',115),('connection','Verbindung',90),('approved','Serverfreigabe',115),('consent','Lokale Zustimmung',135),('last_seen','Zuletzt gesehen',155),('os','Betriebssystem',145)]: self.device_tree.heading(c,text=t); self.device_tree.column(c,width=w,anchor='w')
        self.device_tree.pack(fill='both',expand=True)
        self.device_tree.bind('<Double-1>',lambda _e:self.edit_device_details())
        ttk.Label(self.device_tab,text='Tipp: Doppelklicke ein Gerät, um Name und Notizen zu bearbeiten. Freigabe benötigt lokale Zustimmung UND Serverfreigabe.',style='Sub.TLabel').pack(anchor='w',pady=(9,0))
        accbar=ttk.Frame(self.account_tab); accbar.pack(fill='x',pady=(0,10))
        ttk.Button(accbar,text='Konto erstellen',command=self.create_account).pack(side='left',padx=(0,5))
        ttk.Button(accbar,text='Rechte bearbeiten',command=self.edit_permissions).pack(side='left',padx=5)
        ttk.Button(accbar,text='Passwort zurücksetzen',command=self.reset_account_password).pack(side='left',padx=5)
        ttk.Button(accbar,text='Konto aktivieren/deaktivieren',command=self.toggle_account_active).pack(side='left',padx=5)
        ttk.Button(accbar,text='Aktualisieren',command=self.refresh_accounts).pack(side='right')
        self.account_tree=ttk.Treeview(self.account_tab,columns=('username','role','permissions','active'),show='headings')
        for c,t,w in [('username','Benutzername',190),('role','Rolle',100),('permissions','Berechtigungen',550),('active','Status',100)]: self.account_tree.heading(c,text=t); self.account_tree.column(c,width=w,anchor='w')
        self.account_tree.pack(fill='both',expand=True)
        ttk.Label(self.account_tab,text='Owner-Rechte sind unveränderlich. Rechte werden serverseitig geprüft.',style='Sub.TLabel').pack(anchor='w',pady=(9,0))
        logbar=ttk.Frame(self.log_tab); logbar.pack(fill='x',pady=(0,10))
        ttk.Label(logbar,text='Letzte 500 Ereignisse – sicherheitsrelevante Aktionen werden protokolliert',style='Sub.TLabel').pack(side='left')
        ttk.Button(logbar,text='CSV exportieren',command=self.export_logs).pack(side='right',padx=(6,0))
        ttk.Button(logbar,text='Aktualisieren',command=self.refresh_logs).pack(side='right')
        self.log_tree=ttk.Treeview(self.log_tab,columns=('at','actor','action','detail'),show='headings')
        for c,t,w in [('at','Zeit',180),('actor','Konto / Gerät',150),('action','Aktion',180),('detail','Details',500)]: self.log_tree.heading(c,text=t); self.log_tree.column(c,width=w,anchor='w')
        self.log_tree.pack(fill='both',expand=True)
        if not self.has_permission('manage_accounts'):
            self.tabs.tab(self.account_tab, state='disabled')
        if not self.has_permission('view_logs'):
            self.tabs.tab(self.log_tab, state='disabled')
        self._build_system_tab()
        self.refresh_devices(); self.refresh_accounts(); self.refresh_logs(); self.refresh_overview()
        self.root.after(3000,self._periodic_refresh)

    def _build_overview(self):
        ttk.Label(self.overview_tab,text='Kontrollzentrum',style='Title.TLabel').pack(anchor='w')
        ttk.Label(self.overview_tab,text='Status, Gerätefreigaben und Serverwerkzeuge auf einen Blick.',style='Sub.TLabel').pack(anchor='w',pady=(2,16))
        cards=ttk.Frame(self.overview_tab); cards.pack(fill='x',pady=(0,16))
        self.overview_values={}
        for key,title in [('devices','Registrierte Geräte'),('online','Online'),('approved','Freigegeben'),('pending','Ausstehend')]:
            card=ttk.Frame(cards,padding=14,relief='ridge'); card.pack(side='left',fill='both',expand=True,padx=(0,8))
            ttk.Label(card,text=title,style='Sub.TLabel').pack(anchor='w')
            value=ttk.Label(card,text='0',font=('Segoe UI',22,'bold'),foreground='#58baff'); value.pack(anchor='w',pady=(4,0)); self.overview_values[key]=value
        body=ttk.Frame(self.overview_tab); body.pack(fill='both',expand=True)
        left=ttk.Frame(body,padding=14,relief='ridge'); left.pack(side='left',fill='both',expand=True,padx=(0,8))
        ttk.Label(left,text='Schnellaktionen',font=('Segoe UI',12,'bold')).pack(anchor='w',pady=(0,10))
        ttk.Button(left,text='Geräteverwaltung öffnen',command=lambda:self.tabs.select(self.device_tab)).pack(fill='x',pady=3)
        ttk.Button(left,text='Konten & Rechte öffnen',command=lambda:self.tabs.select(self.account_tab)).pack(fill='x',pady=3)
        ttk.Button(left,text='Datenbank jetzt sichern',command=self.backup_database).pack(fill='x',pady=3)
        ttk.Button(left,text='Aktivitätsprotokoll als CSV exportieren',command=self.export_logs).pack(fill='x',pady=3)
        right=ttk.Frame(body,padding=14,relief='ridge'); right.pack(side='left',fill='both',expand=True)
        ttk.Label(right,text='Serverstatus',font=('Segoe UI',12,'bold')).pack(anchor='w',pady=(0,10))
        self.overview_status=ttk.Label(right,text='Wird geprüft …',wraplength=380); self.overview_status.pack(anchor='w')
        ttk.Label(right,text=f'TCP-Port: {PORT}    •    Geräteerkennung: UDP {DISCOVERY_PORT}',style='Sub.TLabel').pack(anchor='w',pady=(10,4))
        ttk.Label(right,text='Nur für vertrauenswürdige private LAN-Netzwerke. Keine Router-Portfreigaben einrichten.',style='Sub.TLabel',wraplength=390).pack(anchor='w')

    def _build_system_tab(self):
        ttk.Label(self.settings_tab,text='System & Wartung',style='Title.TLabel').pack(anchor='w')
        ttk.Label(self.settings_tab,text='Lokale Serverinformationen, Sicherungen und Diagnose.',style='Sub.TLabel').pack(anchor='w',pady=(2,16))
        info=ttk.Frame(self.settings_tab,padding=14,relief='ridge'); info.pack(fill='x',pady=(0,12))
        for label,value in [('Anwendung',APP),('Netzwerkmodus','LAN only'),('TCP-Port',str(PORT)),('UDP-Erkennung',str(DISCOVERY_PORT)),('Datenbank',str(DB)),('Aktuelles Konto',(self.current_account or {}).get('username','-'))]:
            row=ttk.Frame(info); row.pack(fill='x',pady=3)
            ttk.Label(row,text=label,style='Sub.TLabel',width=20).pack(side='left')
            ttk.Label(row,text=value,wraplength=650).pack(side='left',fill='x',expand=True)
        actions=ttk.Frame(self.settings_tab); actions.pack(fill='x')
        ttk.Button(actions,text='Datenbank sichern',command=self.backup_database).pack(side='left',padx=(0,6))
        ttk.Button(actions,text='Datenordner öffnen',command=self.open_data_folder).pack(side='left',padx=6)
        ttk.Button(actions,text='Status aktualisieren',command=lambda:(self.refresh_devices(),self.refresh_overview())).pack(side='left',padx=6)
        ttk.Label(self.settings_tab,text='Sicherungen werden im Ordner Server/backups abgelegt. Die laufende Datenbank wird über die SQLite-Backup-API kopiert.',style='Sub.TLabel',wraplength=780).pack(anchor='w',pady=(14,0))

    def refresh_overview(self):
        if not hasattr(self,'overview_values'): return
        with self.db_lock: rows=self.db.execute('SELECT approved,consent FROM devices').fetchall()
        with self.client_lock: online=len(self.clients)
        approved=sum(1 for r in rows if r['approved'] and r['consent'])
        pending=sum(1 for r in rows if not (r['approved'] and r['consent']))
        for key,value in [('devices',len(rows)),('online',online),('approved',approved),('pending',pending)]: self.overview_values[key].configure(text=str(value))
        if hasattr(self,'overview_status'):
            self.overview_status.configure(text=f'Serverprozess aktiv. {online} Gerät(e) verbunden; {approved} Gerät(e) vollständig freigegeben. Letzte Aktualisierung: {datetime.now().strftime("%H:%M:%S")}')

    def _periodic_refresh(self):
        if not self.running: return
        try:
            self.refresh_devices(); self.refresh_overview()
        except Exception as exc:
            self._log('system','periodic_refresh_error',str(exc)[:300])
        self.root.after(5000,self._periodic_refresh)

    def backup_database(self):
        try:
            folder=ROOT/'backups'; folder.mkdir(parents=True,exist_ok=True)
            stamp=datetime.now().strftime('%Y%m%d_%H%M%S')
            target=folder/f'core_nexus_{stamp}.sqlite3'
            with self.db_lock:
                backup=sqlite3.connect(target)
                try: self.db.backup(backup)
                finally: backup.close()
            self._log((self.current_account or {}).get('username','unknown'),'database_backup_created',str(target))
            messagebox.showinfo(APP,f'Datenbank erfolgreich gesichert:\n\n{target}',parent=self.root)
        except Exception as exc:
            messagebox.showerror(APP,f'Datenbanksicherung fehlgeschlagen:\n{exc}',parent=self.root)

    def open_data_folder(self):
        try:
            if os.name=='nt': os.startfile(str(DATA))
            else: messagebox.showinfo(APP,f'Datenordner:\n{DATA}',parent=self.root)
        except Exception as exc: messagebox.showerror(APP,f'Datenordner konnte nicht geöffnet werden:\n{exc}',parent=self.root)

    def export_logs(self):
        if not self.require_permission('view_logs'): return
        from tkinter import filedialog
        default=f'core_nexus_logs_{datetime.now().strftime("%Y%m%d_%H%M%S")}.csv'
        path=filedialog.asksaveasfilename(parent=self.root,title='Aktivitätsprotokoll exportieren',defaultextension='.csv',initialfile=default,filetypes=[('CSV-Datei','*.csv')])
        if not path: return
        try:
            with self.db_lock: rows=self.db.execute('SELECT at,actor,action,detail FROM logs ORDER BY id DESC LIMIT 5000').fetchall()
            with open(path,'w',newline='',encoding='utf-8-sig') as handle:
                writer=csv.writer(handle,delimiter=';'); writer.writerow(['Zeit','Konto/Gerät','Aktion','Details'])
                for row in rows: writer.writerow([row['at'],row['actor'] or '',row['action'],row['detail'] or ''])
            messagebox.showinfo(APP,f'{len(rows)} Protokolleinträge exportiert.\n\n{path}',parent=self.root)
        except Exception as exc: messagebox.showerror(APP,f'Export fehlgeschlagen:\n{exc}',parent=self.root)

    def _log(self, actor, action, detail=''):
        with self.db_lock:
            self.db.execute('INSERT INTO logs(actor,action,detail) VALUES(?,?,?)',(actor,action,detail)); self.db.commit()
        self.ui_events.put(('refresh_logs',None))

    def _accept_loop(self):
        while self.running:
            try: conn, addr = self.tcp.accept()
            except socket.timeout: continue
            except OSError: break
            threading.Thread(target=self._client_loop,args=(conn,addr),daemon=True).start()

    def _client_loop(self, conn, addr):
        device_id=None
        try:
            conn.settimeout(15); file=conn.makefile('rwb')
            while self.running:
                line=file.readline()
                if not line: break
                if len(line)>8_000_000: break
                try: msg=json.loads(line.decode('utf-8'))
                except Exception: self._send(file,{'ok':False,'error':'invalid_json'}); continue
                typ=msg.get('type')
                if typ=='hello':
                    device_id=str(msg.get('device_id',''))[:80]
                    if not device_id: self._send(file,{'ok':False,'error':'missing_device_id'}); break
                    with self.db_lock:
                        row=self.db.execute('SELECT * FROM devices WHERE id=?',(device_id,)).fetchone()
                        if row:
                            self.db.execute('UPDATE devices SET name=?,ip=?,last_seen=CURRENT_TIMESTAMP,os=?,boot_id=? WHERE id=?',(str(msg.get('name','PC'))[:120],addr[0],str(msg.get('os',''))[:120],str(msg.get('boot_id',''))[:100],device_id))
                        else:
                            self.db.execute('INSERT INTO devices(id,name,ip,approved,consent,last_seen,os,boot_id) VALUES(?,?,?,0,0,CURRENT_TIMESTAMP,?,?)',(device_id,str(msg.get('name','PC'))[:120],addr[0],str(msg.get('os',''))[:120],str(msg.get('boot_id',''))[:100]))
                        self.db.commit()
                    with self.client_lock: self.clients[device_id]=conn
                    self._send(file,{'ok':True,'approved':bool(row and row['approved'] and row['consent']),'server_name':APP})
                    self.ui_events.put(('refresh_devices',None))
                elif typ=='consent':
                    if not device_id: break
                    with self.db_lock: self.db.execute('UPDATE devices SET consent=? WHERE id=?',(1 if msg.get('accepted') else 0,device_id)); self.db.commit()
                    self._log('device:'+device_id,'local_consent',str(bool(msg.get('accepted'))))
                    
                    with self.db_lock:
                        current=self.db.execute('SELECT approved,consent FROM devices WHERE id=?',(device_id,)).fetchone()
                    self._send(file,{'ok':True,'approved':bool(current and current['approved'] and current['consent']),'server_approved':bool(current and current['approved']),'consent':bool(current and current['consent'])})
                elif typ=='heartbeat':
                    if not device_id: break
                    if msg.get('frame') and device_id==self.remote_device:
                        try: self.remote_frames[device_id]=base64.b64decode(msg['frame'])
                        except Exception: pass
                    with self.db_lock:
                        row=self.db.execute('SELECT approved,consent FROM devices WHERE id=?',(device_id,)).fetchone()
                        lock=self.db.execute("SELECT value FROM settings WHERE key='close_agents' ").fetchone()
                    approved=bool(row and row['approved'] and row['consent'])
                    remote=bool(approved and device_id==self.remote_device and self.remote_window is not None)
                    commands=self.remote_commands.pop(device_id,[]) if remote else []
                    self._send(file,{'ok':True,'approved':approved,'server_approved':bool(row and row['approved']),'consent':bool(row and row['consent']),'close_agent':bool(lock and lock['value']=='1'),'remote_active':remote,'commands':commands})
                elif typ=='system_info':
                    if device_id: self.ui_events.put(('device_info',(device_id,msg.get('info',{}))))
                    self._send(file,{'ok':True})
                elif typ=='agent_closed':
                    self._send(file,{'ok':True}); break
                else: self._send(file,{'ok':False,'error':'unsupported_message'})
        except (OSError,ValueError,KeyError): pass
        finally:
            if device_id:
                with self.client_lock:
                    if self.clients.get(device_id) is conn: self.clients.pop(device_id,None)
                self.ui_events.put(('refresh_devices',None))
            try: conn.close()
            except OSError: pass

    @staticmethod
    def _send(file, obj):
        file.write((json.dumps(obj,separators=(',',':'))+'\n').encode('utf-8')); file.flush()

    def _discovery_loop(self):
        sock=socket.socket(socket.AF_INET,socket.SOCK_DGRAM); sock.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1)
        try: sock.bind(('',DISCOVERY_PORT)); sock.settimeout(1)
        except OSError: return
        while self.running:
            try: data,addr=sock.recvfrom(2048)
            except socket.timeout: continue
            except OSError: break
            if data==b'CORE_NEXUS_DISCOVER_V1':
                try: sock.sendto(json.dumps({'app':APP,'host':self._lan_ip(addr[0]),'port':PORT,'discovery_port':DISCOVERY_PORT}).encode(),addr)
                except OSError: pass
        sock.close()

    @staticmethod
    def _lan_ip(peer):
        s=socket.socket(socket.AF_INET,socket.SOCK_DGRAM)
        try: s.connect((peer,9)); return s.getsockname()[0]
        except OSError: return '127.0.0.1'

    def _selected_device(self):
        sel=self.device_tree.selection()
        if not sel:
            messagebox.showwarning(APP,'Wähle zuerst ein Gerät aus.',parent=self.root)
            return None
        # Die Treeview-IID ist die echte Geräte-ID. Die erste sichtbare Spalte
        # enthält nur den Anzeigenamen und darf niemals als ID verwendet werden.
        return str(sel[0])

    def edit_device_details(self):
        if not self.require_permission('manage_grants'): return
        did=self._selected_device()
        if not did: return
        with self.db_lock:
            row=self.db.execute('SELECT * FROM devices WHERE id=?',(did,)).fetchone()
        if not row:
            messagebox.showerror(APP,'Gerät wurde nicht gefunden.',parent=self.root); return
        dlg=tk.Toplevel(self.root); dlg.title('Gerätedetails bearbeiten'); dlg.transient(self.root); dlg.grab_set(); dlg.configure(bg='#0d1728'); dlg.resizable(False,False)
        body=ttk.Frame(dlg,padding=16); body.pack(fill='both',expand=True)
        ttk.Label(body,text='Gerätename').pack(anchor='w')
        name_var=tk.StringVar(value=row['name'])
        name_entry=ttk.Entry(body,textvariable=name_var,width=48); name_entry.pack(fill='x',pady=(4,12))
        ttk.Label(body,text='Interne Notizen (optional)').pack(anchor='w')
        notes=tk.Text(body,width=52,height=5,wrap='word',bg='#0b1423',fg='#eaf2ff',insertbackground='#ffffff',relief='flat')
        notes.pack(fill='both',expand=True,pady=(4,12)); notes.insert('1.0',row['notes'] or '')
        ttk.Label(body,text=f'Geräte-ID: {did}',style='Sub.TLabel').pack(anchor='w',pady=(0,10))
        def save():
            name=name_var.get().strip(); note=notes.get('1.0','end').strip()
            if not name:
                messagebox.showwarning(APP,'Der Gerätename darf nicht leer sein.',parent=dlg); return
            with self.db_lock:
                self.db.execute('UPDATE devices SET name=?,notes=? WHERE id=?',(name[:120],note[:2000],did)); self.db.commit()
            self._log((self.current_account or {}).get('username','unknown'),'device_details_updated',f'{did}: {name}')
            dlg.destroy(); self.refresh_devices()
        buttons=ttk.Frame(body); buttons.pack(fill='x')
        ttk.Button(buttons,text='Speichern',command=save).pack(side='right',padx=(6,0)); ttk.Button(buttons,text='Abbrechen',command=dlg.destroy).pack(side='right')
        name_entry.focus_set()

    def delete_device(self):
        if not self.require_permission('manage_grants'): return
        did=self._selected_device()
        if not did: return
        with self.client_lock: online=did in self.clients
        if online:
            messagebox.showwarning(APP,'Dieses Gerät ist noch online. Beende zuerst den Agenten auf dem Client-PC.',parent=self.root); return
        with self.db_lock:
            row=self.db.execute('SELECT name FROM devices WHERE id=?',(did,)).fetchone()
        if not row: return
        if not messagebox.askyesno(APP,f'Das Offline-Gerät „{row["name"]}“ dauerhaft aus der Geräteliste entfernen? Bei einer späteren Verbindung wird es neu registriert und benötigt erneut eine Freigabe.',parent=self.root): return
        with self.db_lock:
            self.db.execute('DELETE FROM grants WHERE device_id=?',(did,))
            self.db.execute('DELETE FROM devices WHERE id=?',(did,)); self.db.commit()
        self._log((self.current_account or {}).get('username','unknown'),'device_removed',f'{did} ({row["name"]})')
        self.refresh_devices()

    def approve_device(self):
        if not self.require_permission('register_devices'): return
        did=self._selected_device()
        if not did: return
        with self.db_lock: self.db.execute('UPDATE devices SET approved=1 WHERE id=?',(did,)); self.db.commit()
        self._log((self.current_account or {}).get('username','unknown'),'device_approved',did); self.refresh_devices(); self.refresh_overview()

    def revoke_device(self):
        if not self.require_permission('manage_grants'): return
        did=self._selected_device()
        if not did: return
        if not messagebox.askyesno(APP,'Freigabe für dieses Gerät wirklich widerrufen?',parent=self.root): return
        with self.db_lock: self.db.execute('UPDATE devices SET approved=0 WHERE id=?',(did,)); self.db.commit()
        self._log((self.current_account or {}).get('username','unknown'),'device_revoked',did); self.refresh_devices(); self.refresh_overview()

    def close_all_agents(self):
        if not self.require_permission('close_agents'): return
        if not messagebox.askyesno(APP,'Alle erreichbaren Agentenprogramme schließen? Offline-Geräte erhalten den Status bei der nächsten Verbindung.',parent=self.root): return
        with self.db_lock: self.db.execute("INSERT INTO settings(key,value) VALUES('close_agents','1') ON CONFLICT(key) DO UPDATE SET value='1'"); self.db.commit()
        with self.client_lock: ids=list(self.clients)
        self._log('dashboard','close_all_agents',f'{len(ids)} verbundene Geräte benachrichtigt')
        messagebox.showinfo(APP,'Schließbefehl gesendet. Der Status bleibt gespeichert, bis der Server-Owner ihn zurücksetzt.',parent=self.root)

    def reset_agent_lock(self):
        if not self.is_owner_context():
            messagebox.showwarning(APP, 'Nur das Owner-Konto darf die globale Agentensperre aufheben.', parent=self.root)
            return
        if not messagebox.askyesno(APP, 'Globale Agentensperre aufheben? Agenten dürfen sich danach wieder verbinden.', parent=self.root):
            return
        with self.db_lock:
            self.db.execute("INSERT INTO settings(key,value) VALUES('close_agents','0') ON CONFLICT(key) DO UPDATE SET value='0'")
            self.db.commit()
        self._log((self.current_account or {}).get('username','owner'), 'agent_lock_reset', 'Globale Agentensperre aufgehoben')
        messagebox.showinfo(APP, 'Agentensperre aufgehoben. Starte den Agenten auf dem Client-PC erneut.', parent=self.root)

    def open_remote(self):
        if not (self.has_permission('remote_view') and self.has_permission('remote_input')):
            messagebox.showwarning(APP, 'Für die Fernsteuerung fehlen Bildschirm- und Eingaberechte.', parent=self.root); return
        did=self._selected_device()
        if not did: return
        with self.db_lock:
            row=self.db.execute('SELECT approved,consent,name FROM devices WHERE id=?',(did,)).fetchone()
        if not row or not row['approved'] or not row['consent']:
            messagebox.showwarning(APP,'Das Gerät benötigt lokale Zustimmung und Serverfreigabe.',parent=self.root); return
        if self.remote_window is not None:
            self.stop_remote()
        self.remote_device=did
        win=tk.Toplevel(self.root); win.title('CORE Nexus | Fernsteuerung'); win.geometry('1000x650'); win.configure(bg='#080e1b')
        win.protocol('WM_DELETE_WINDOW',self.stop_remote); self.remote_window=win
        ttk.Label(win,text=f'FERNSTEUERUNG: {row["name"]}  •  Nur im lokalen Netzwerk',style='Title.TLabel').pack(anchor='w',padx=12,pady=8)
        ttk.Label(win,text='Klicks und Tastatur werden an das freigegebene Gerät gesendet. Esc wird an das Ziel weitergegeben; Schließen beendet die Sitzung.',style='Sub.TLabel').pack(anchor='w',padx=12)
        self.remote_image_label=tk.Label(win,text='Warte auf ersten Bildschirmframe …',bg='#050914',fg='#eaf2ff')
        self.remote_image_label.pack(fill='both',expand=True,padx=10,pady=10)
        bar=ttk.Frame(win); bar.pack(fill='x',padx=10,pady=(0,10))
        ttk.Label(bar,text='Hinweis: Windows-Sicherheitsbildschirm (Strg+Alt+Entf) wird nicht umgangen.',style='Sub.TLabel').pack(side='left')
        ttk.Button(bar,text='Sitzung beenden',command=self.stop_remote).pack(side='right')
        self.remote_image_label.bind('<Motion>',self.remote_motion)
        self.remote_image_label.bind('<Button-1>',lambda e:self.remote_click(e,'left'))
        self.remote_image_label.bind('<Button-3>',lambda e:self.remote_click(e,'right'))
        self.remote_image_label.bind('<MouseWheel>',self.remote_scroll)
        win.bind('<KeyPress>',self.remote_keydown); win.bind('<KeyRelease>',self.remote_keyup); win.focus_force()
        self._log('dashboard','remote_session_started',did); self._update_remote_frame()

    def _image_coords(self,event):
        try:
            from PIL import Image
            data=self.remote_frames.get(self.remote_device)
            if not data: return (event.x,event.y)
            im=Image.open(__import__('io').BytesIO(data)); return (max(0,int(event.x*im.width/max(1,self.remote_image_label.winfo_width()))),max(0,int(event.y*im.height/max(1,self.remote_image_label.winfo_height()))))
        except Exception: return (event.x,event.y)

    def queue_input(self,cmd):
        if self.remote_device: self.remote_commands.setdefault(self.remote_device,[]).append(cmd)

    def remote_motion(self,e):
        x,y=self._image_coords(e); self.queue_input({'kind':'move','x':x,'y':y})

    def remote_click(self,e,button):
        x,y=self._image_coords(e); self.queue_input({'kind':'click','x':x,'y':y,'button':button})

    def remote_scroll(self,e):
        x,y=self._image_coords(e); self.queue_input({'kind':'scroll','x':x,'y':y,'dy':1 if e.delta>0 else -1})

    def remote_keydown(self,e):
        if self.remote_window is None: return
        names={'Return':'enter','Tab':'tab','Escape':'esc','BackSpace':'backspace','Delete':'delete','space':'space','Up':'up','Down':'down','Left':'left','Right':'right','Shift_L':'shift','Control_L':'ctrl','Alt_L':'alt','Super_L':'win'}
        key=names.get(e.keysym,e.keysym.lower() if e.keysym.lower().startswith('f') and e.keysym[1:].isdigit() else (e.char if e.char and e.char.isprintable() else ''))
        if key: self.queue_input({'kind':'key','key':key,'action':'down' if key in ('shift','ctrl','alt','win') else 'press'})

    def remote_keyup(self,e):
        names={'Shift_L':'shift','Control_L':'ctrl','Alt_L':'alt','Super_L':'win'}
        key=names.get(e.keysym)
        if key: self.queue_input({'kind':'key','key':key,'action':'up'})

    def _update_remote_frame(self):
        if self.remote_window is None: return
        data=self.remote_frames.get(self.remote_device)
        if data:
            try:
                from PIL import Image, ImageTk
                import io
                im=Image.open(io.BytesIO(data)); maxw=max(320,self.remote_image_label.winfo_width()); maxh=max(240,self.remote_image_label.winfo_height())
                im.thumbnail((maxw,maxh)); self.remote_photo=ImageTk.PhotoImage(im); self.remote_image_label.configure(image=self.remote_photo,text='')
            except Exception as exc: self.remote_image_label.configure(text=f'Bild konnte nicht angezeigt werden: {exc}')
        self.remote_window.after(120,self._update_remote_frame)

    def stop_remote(self):
        if self.remote_device: self._log('dashboard','remote_session_stopped',self.remote_device)
        self.remote_device=None; self.remote_photo=None; self.remote_image_label=None
        win=self.remote_window; self.remote_window=None
        if win is not None:
            try: win.destroy()
            except tk.TclError: pass

    def create_account(self):
        if not self.require_permission('manage_accounts'): return
        username=simpledialog.askstring('Konto erstellen','Benutzername:',parent=self.root)
        if not username: return
        password=simpledialog.askstring('Konto erstellen','Passwort (mindestens 4 Zeichen):',show='*',parent=self.root)
        if not password or len(password)<4: messagebox.showerror(APP,'Passwort muss mindestens 4 Zeichen lang sein.',parent=self.root); return
        choices=list(PERMISSIONS) if self.is_owner_context() else [k for k in PERMISSIONS if k in (self.current_account or {}).get('permissions', [])]
        dlg=tk.Toplevel(self.root); dlg.title('Berechtigungen auswählen'); dlg.configure(bg='#0d1728'); dlg.transient(self.root); dlg.grab_set()
        ttk.Label(dlg,text=f'Rechte für {username}').pack(anchor='w',padx=14,pady=10)
        vars_={}
        for key,label in PERMISSIONS.items():
            if key not in choices: continue
            v=tk.BooleanVar(value=key in ('view_devices','view_system_info')); vars_[key]=v; ttk.Checkbutton(dlg,text=label,variable=v).pack(anchor='w',padx=16,pady=2)
        result={'ok':False}
        def save(): result['ok']=True; dlg.destroy()
        ttk.Button(dlg,text='Konto anlegen',command=save).pack(pady=12); dlg.wait_window()
        if not result['ok']: return
        perms=[k for k,v in vars_.items() if v.get()]
        try:
            with self.db_lock: self.db.execute('INSERT INTO accounts(username,password_hash,is_owner,permissions) VALUES(?,?,0,?)',(username.strip(),password_hash(password),json.dumps(perms))); self.db.commit()
            self._log((self.current_account or {}).get('username','unknown'),'account_created',username.strip()); self.refresh_accounts()
        except sqlite3.IntegrityError: messagebox.showerror(APP,'Dieser Benutzername ist bereits vergeben.',parent=self.root)

    def edit_permissions(self):
        if not self.require_permission('manage_accounts'): return
        sel=self.account_tree.selection()
        if not sel: messagebox.showwarning(APP,'Wähle ein Konto aus.',parent=self.root); return
        aid=int(sel[0]); row=self.db.execute('SELECT * FROM accounts WHERE id=?',(aid,)).fetchone()
        if not row: return
        if row['is_owner']: messagebox.showwarning(APP,'Owner-Rechte können nicht bearbeitet werden.',parent=self.root); return
        try: current=set(json.loads(row['permissions']))
        except Exception: current=set()
        dlg=tk.Toplevel(self.root); dlg.title('Berechtigungen'); dlg.configure(bg='#0d1728'); dlg.transient(self.root); dlg.grab_set()
        ttk.Label(dlg,text=f'Rechte für {row["username"]}').pack(anchor='w',padx=14,pady=10); vars_={}
        allowed=list(PERMISSIONS) if self.is_owner_context() else [k for k in PERMISSIONS if k in (self.current_account or {}).get('permissions', [])]
        for key,label in PERMISSIONS.items():
            if key not in allowed: continue
            v=tk.BooleanVar(value=key in current); vars_[key]=v; ttk.Checkbutton(dlg,text=label,variable=v).pack(anchor='w',padx=16,pady=2)
        def save():
            perms=[k for k,v in vars_.items() if v.get()]
            with self.db_lock: self.db.execute('UPDATE accounts SET permissions=? WHERE id=?',(json.dumps(perms),aid)); self.db.commit()
            self._log('owner','permissions_changed',row['username']); dlg.destroy(); self.refresh_accounts()
        ttk.Button(dlg,text='Speichern',command=save).pack(pady=12)

    def reset_account_password(self):
        if not self.require_permission('manage_accounts'): return
        sel=self.account_tree.selection()
        if not sel:
            messagebox.showwarning(APP,'Wähle ein Konto aus.',parent=self.root); return
        with self.db_lock: row=self.db.execute('SELECT * FROM accounts WHERE id=?',(int(sel[0]),)).fetchone()
        if not row: return
        if row['is_owner'] and not self.is_owner_context():
            messagebox.showwarning(APP,'Nur der Owner darf das Owner-Passwort zurücksetzen.',parent=self.root); return
        password=simpledialog.askstring('Passwort zurücksetzen',f'Neues Passwort für „{row["username"]}“ (mindestens 8 Zeichen):',show='*',parent=self.root)
        if password is None: return
        if len(password)<8:
            messagebox.showerror(APP,'Bitte ein Passwort mit mindestens 8 Zeichen verwenden.',parent=self.root); return
        with self.db_lock:
            self.db.execute('UPDATE accounts SET password_hash=? WHERE id=?',(password_hash(password),row['id'])); self.db.commit()
        self._log((self.current_account or {}).get('username','unknown'),'account_password_reset',row['username'])
        messagebox.showinfo(APP,'Passwort wurde geändert.',parent=self.root)

    def toggle_account_active(self):
        if not self.require_permission('manage_accounts'): return
        sel=self.account_tree.selection()
        if not sel:
            messagebox.showwarning(APP,'Wähle ein Konto aus.',parent=self.root); return
        with self.db_lock: row=self.db.execute('SELECT * FROM accounts WHERE id=?',(int(sel[0]),)).fetchone()
        if not row: return
        if row['is_owner']:
            messagebox.showwarning(APP,'Das Owner-Konto kann nicht über diese Funktion deaktiviert werden.',parent=self.root); return
        new_active=0 if row['active'] else 1
        action='deaktivieren' if not new_active else 'aktivieren'
        if not messagebox.askyesno(APP,f'Konto „{row["username"]}“ wirklich {action}?',parent=self.root): return
        with self.db_lock:
            self.db.execute('UPDATE accounts SET active=? WHERE id=?',(new_active,row['id'])); self.db.commit()
        self._log((self.current_account or {}).get('username','unknown'),'account_enabled' if new_active else 'account_disabled',row['username'])
        self.refresh_accounts()

    def disable_account(self):
        if not self.require_permission('manage_accounts'): return
        sel=self.account_tree.selection()
        if not sel: messagebox.showwarning(APP,'Wähle ein Konto aus.',parent=self.root); return
        row=self.db.execute('SELECT * FROM accounts WHERE id=?',(int(sel[0]),)).fetchone()
        if not row or row['is_owner']: messagebox.showwarning(APP,'Das Owner-Konto kann hier nicht deaktiviert werden.',parent=self.root); return
        if messagebox.askyesno(APP,f'Konto {row["username"]} deaktivieren?',parent=self.root):
            with self.db_lock: self.db.execute('UPDATE accounts SET active=0 WHERE id=?',(row['id'],)); self.db.commit()
            self._log('owner','account_disabled',row['username']); self.refresh_accounts()

    def refresh_devices(self):
        if not hasattr(self,'device_tree'): return
        for i in self.device_tree.get_children(): self.device_tree.delete(i)
        with self.db_lock: rows=self.db.execute('SELECT * FROM devices ORDER BY name COLLATE NOCASE').fetchall()
        with self.client_lock: online_ids=set(self.clients)
        query=self.device_search.get().strip().casefold() if hasattr(self,'device_search') else ''
        visible=[]
        for r in rows:
            searchable=' '.join(str(r[k] or '') for k in ('name','id','ip','os','notes')).casefold()
            if query and query not in searchable: continue
            visible.append(r)
            online=r['id'] in online_ids
            fully_approved=bool(r['approved'] and r['consent'])
            filter_value=self.device_filter.get() if hasattr(self,'device_filter') else 'Alle'
            if filter_value=='Online' and not online: continue
            if filter_value=='Offline' and online: continue
            if filter_value=='Freigabe ausstehend' and fully_approved: continue
            if filter_value=='Freigegeben' and not fully_approved: continue
            visible.append(r)
            approval_label='Freigegeben' if fully_approved else ('Serverfreigabe fehlt' if r['consent'] else 'Zustimmung fehlt')
            item=self.device_tree.insert('', 'end', iid=r['id'], values=(r['name'],r['ip'] or '-', 'Online' if online else 'Offline',approval_label,'Ja' if r['consent'] else 'Nein',r['last_seen'],r['os'] or '-'))
            self.device_tree.item(item,tags=('online' if online else 'offline', 'approved' if fully_approved else 'pending'))
        self.device_tree.tag_configure('online',foreground='#7be0ad'); self.device_tree.tag_configure('offline',foreground='#9aacc4'); self.device_tree.tag_configure('pending',background='#2a2117')
        approved=sum(1 for r in rows if r['approved'] and r['consent'])
        consent_missing=sum(1 for r in rows if not r['consent'])
        self.device_summary.configure(text=f'Geräte: {len(rows)}  |  Online: {len(online_ids)}  |  Freigegeben: {approved}  |  Zustimmung fehlt: {consent_missing}  |  Angezeigt: {len(visible)}')

    def refresh_accounts(self):
        if not hasattr(self,'account_tree'): return
        for i in self.account_tree.get_children(): self.account_tree.delete(i)
        with self.db_lock: rows=self.db.execute('SELECT * FROM accounts ORDER BY is_owner DESC,username').fetchall()
        for r in rows:
            try: perms=json.loads(r['permissions']); summary=', '.join(PERMISSIONS.get(p,p) for p in perms)
            except Exception: summary=''
            self.account_tree.insert('', 'end', iid=str(r['id']), values=(r['username'],'OWNER' if r['is_owner'] else 'Konto',summary,'Aktiv' if r['active'] else 'Deaktiviert'))

    def refresh_logs(self):
        if not hasattr(self,'log_tree'): return
        for i in self.log_tree.get_children(): self.log_tree.delete(i)
        with self.db_lock: rows=self.db.execute('SELECT * FROM logs ORDER BY id DESC LIMIT 300').fetchall()
        for r in rows: self.log_tree.insert('', 'end', values=(r['at'],r['actor'] or '-',r['action'],r['detail'] or ''))

    def _poll_ui(self):
        try:
            while True:
                kind,payload=self.ui_events.get_nowait()
                if kind=='refresh_devices': self.refresh_devices()
                elif kind=='refresh_logs': self.refresh_logs()
                elif kind=='device_info': self._log('device:'+payload[0],'system_info',json.dumps(payload[1],ensure_ascii=False)[:500])
                elif kind=='refresh_overview': self.refresh_overview()
        except queue.Empty: pass
        if self.running: self.root.after(250,self._poll_ui)

    def close(self):
        self.stop_remote()
        self.running=False
        try: self.tcp.close()
        except OSError: pass
        try: self.db.close()
        except Exception: pass
        self.root.destroy()

if __name__=='__main__':
    try: NexusServer().root.mainloop()
    except OSError as e:
        tk.Tk().withdraw(); messagebox.showerror(APP, f'Server konnte Port {PORT} nicht öffnen. Ist CORE Nexus bereits gestartet?\n\n{e}')
