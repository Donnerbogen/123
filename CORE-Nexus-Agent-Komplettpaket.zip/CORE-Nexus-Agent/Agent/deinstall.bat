@echo off
setlocal EnableExtensions
chcp 65001 >nul
pushd "%~dp0"
title CORE Nexus Agent - Deinstallation

echo ============================================
echo       CORE NEXUS AGENT - DEINSTALLATION
echo ============================================
echo.
echo Die Deinstallation beendet das Programm und entfernt die Installationsmarkierung.
echo Du kannst waehlen, ob lokale Daten und Einstellungen erhalten bleiben.
echo.
choice /C JN /N /M "Auch lokale Daten, Raum-ID und Konfiguration loeschen? [J/N] "
if errorlevel 2 goto :keep_data
if errorlevel 1 goto :delete_data

goto :cleanup
:delete_data
echo.
echo Loesche lokale Daten und Konfiguration...
if exist "data" rmdir /s /q "data"
if exist "relay_config.json" del /q "relay_config.json"
if exist "device_id.json" del /q "device_id.json"
if exist "consent.json" del /q "consent.json"
goto :cleanup

:keep_data
echo Lokale Daten und Konfiguration bleiben erhalten.

:cleanup
echo.
echo Beende CORE Nexus Agent...
powershell -NoProfile -ExecutionPolicy Bypass -Command "$root=[IO.Path]::GetFullPath('%~dp0').TrimEnd('\'); Get-CimInstance Win32_Process -ErrorAction SilentlyContinue | Where-Object { ($_.Name -in @('python.exe','pythonw.exe')) -and $_.CommandLine -and ($_.CommandLine -like ('*' + $root + '\agent.py*')) } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }"
if exist "__pycache__" rmdir /s /q "__pycache__"
if exist "installed.flag" del /q "installed.flag"
echo.
echo DEINSTALLATION ABGESCHLOSSEN.
echo Python selbst und die Programmdateien wurden nicht entfernt.
echo Du kannst den Programmordner jetzt bei Bedarf manuell loeschen.
echo.
pause
popd
exit /b 0
