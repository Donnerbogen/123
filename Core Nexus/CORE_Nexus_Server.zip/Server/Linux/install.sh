#!/usr/bin/env bash
set -Eeuo pipefail
cd "$(dirname "$(readlink -f "$0")")/.."
PYTHON="${PYTHON:-python3}"
command -v "$PYTHON" >/dev/null || { echo "Python 3 fehlt."; exit 1; }
"$PYTHON" -c 'import tkinter' 2>/dev/null || { echo "Tkinter fehlt. Debian/Ubuntu: sudo apt install python3-tk python3-venv python3-pip."; exit 1; }
if [[ -z "${VIRTUAL_ENV:-}" ]]; then
  "$PYTHON" -m venv .venv || { echo "Virtuelle Umgebung fehlt. Debian/Ubuntu: sudo apt install python3-venv"; exit 1; }
  PIP=".venv/bin/python -m pip"
else PIP="$PYTHON -m pip"; fi
# shellcheck disable=SC2086
$PIP install --upgrade pip
# shellcheck disable=SC2086
$PIP install -r requirements-linux.txt
"${PYTHON}" -m py_compile server.py
mkdir -p data
cp -n relay_config.example.json relay_config.json 2>/dev/null || true
chmod +x Linux/start.sh
printf '
Installation fertig. Starte mit ./start-linux.sh
Für eine grafische Oberfläche muss eine Desktop-Sitzung aktiv sein.
'
