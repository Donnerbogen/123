﻿@echo off
setlocal
chcp 65001 >nul
cd /d "%~dp0"
title CORE Nexus - Deinstallation

echo ============================================
echo       CORE Nexus - Deinstallation
echo ============================================
echo.
echo Dieser Vorgang entfernt die Installationsmarkierung und Python-Cache-Dateien.
CHOICE /C JN /N /M "Soll auch die lokalen Anwendungsdaten geloescht werden? [J/N] "
if errorlevel 2 goto keepdata
if errorlevel 1 goto deletedata
:deletedata
if exist "data" rmdir /s /q "data"
if exist "device_id.json" del /q "device_id.json"
if exist "consent.json" del /q "consent.json"
goto cleanup
:keepdata
echo Lokale Daten bleiben erhalten.
:cleanup
if exist "__pycache__" rmdir /s /q "__pycache__"
if exist "installed.flag" del /q "installed.flag"
echo.
echo Deinstallation abgeschlossen.
echo Der Programmordner selbst wird nicht geloescht, damit du ihn manuell entfernen kannst.
pause
