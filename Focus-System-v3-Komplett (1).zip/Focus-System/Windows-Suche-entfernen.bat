@echo off
setlocal
set "LINK_FILE=%APPDATA%\Microsoft\Windows\Start Menu\Programs\Focus System.lnk"
if exist "%LINK_FILE%" (del /f /q "%LINK_FILE%"&echo Verknuepfung entfernt.) else echo Keine Verknuepfung gefunden.
echo Programmdateien und Einstellungen bleiben unveraendert.
pause
endlocal
