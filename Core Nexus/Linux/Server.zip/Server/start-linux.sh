#!/usr/bin/env bash
set -Eeuo pipefail
cd "$(dirname "$(readlink -f "$0")")"
if [[ -x .venv/bin/python ]]; then exec .venv/bin/python server.py; fi
exec python3 server.py
