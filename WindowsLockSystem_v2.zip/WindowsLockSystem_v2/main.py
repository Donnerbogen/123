import ctypes, hashlib, json, os, sys, time, winsound
from datetime import datetime
from pathlib import Path
import tkinter as tk

APP_DIR = Path(__file__).resolve().parent
CONFIG_FILE = APP_DIR / "config.json"

def load_config():
    if not CONFIG_FILE.exists():
        raise RuntimeError("config.json fehlt.")
    data = json.loads(CONFIG_FILE.read_text(encoding="utf-8"))
    data.setdefault("exit_code_sha256", hashlib.sha256(b"1234").hexdigest())
    return data

CONFIG = load_config()

def sha(value):
    return hashlib.sha256(value.encode("utf-8")).hexdigest()

def event_log(message):
    if not CONFIG.get("write_log", True): return
    try:
        with (APP_DIR / "lock.log").open("a", encoding="utf-8") as f:
            f.write(f"[{datetime.now():%Y-%m-%d %H:%M:%S}] {message}\n")
    except Exception: pass

def wrong_code_log(code):
    if not CONFIG.get("log_wrong_codes", True): return
    try:
        name = CONFIG.get("wrong_code_log_file", "wrong_codes.log")
        with (APP_DIR / name).open("a", encoding="utf-8") as f:
            f.write(f"[{datetime.now():%Y-%m-%d %H:%M:%S}] FALSCHER CODE: {code}\n")
    except Exception as e:
        event_log(f"Fehler beim Schreiben der Code-Datei: {e}")

def beep(wrong=False):
    try:
        winsound.MessageBeep(winsound.MB_ICONHAND if wrong else winsound.MB_OK)
    except Exception: pass

def battery():
    class S(ctypes.Structure):
        _fields_=[("AC",ctypes.c_ubyte),("BF",ctypes.c_ubyte),("BP",ctypes.c_ubyte),
                  ("SF",ctypes.c_ubyte),("BL",ctypes.c_ulong),("BFULL",ctypes.c_ulong)]
    s=S()
    if ctypes.windll.kernel32.GetSystemPowerStatus(ctypes.byref(s)):
        return f"Akku {s.BP}% · {'Netz' if s.AC == 1 else 'Akku'}"
    return "Akku unbekannt"

def network():
    try:
        import urllib.request
        urllib.request.urlopen("https://www.msftconnecttest.com/connecttest.txt", timeout=2)
        return "● Online"
    except Exception: return "● Offline"

def taskbar(show):
    try:
        h=ctypes.windll.user32.FindWindowW("Shell_TrayWnd",None)
        if h: ctypes.windll.user32.ShowWindow(h,5 if show else 0)
    except Exception: pass

def keyboard_hook():
    u=ctypes.windll.user32; k=ctypes.windll.kernel32
    WH=13; DOWN=0x100; SDOWN=0x104
    blocked={0x5B,0x5C,0x09,0x1B,0x73,0x7A,0x44,0x52,0x4D,0x4C,0x45,0x58}
    class K(ctypes.Structure):
        _fields_=[("vk",ctypes.c_ulong),("scan",ctypes.c_ulong),("flags",ctypes.c_ulong),
                  ("time",ctypes.c_ulong),("extra",ctypes.POINTER(ctypes.c_ulong))]
    PROC=ctypes.WINFUNCTYPE(ctypes.c_long,ctypes.c_int,ctypes.c_uint,ctypes.POINTER(K))
    def cb(n,w,l):
        if n==0 and w in (DOWN,SDOWN):
            vk=l.contents.vk
            if vk in blocked: return 1
            if vk==0x09 and (u.GetAsyncKeyState(0x12)&0x8000 or u.GetAsyncKeyState(0x5B)&0x8000 or u.GetAsyncKeyState(0x5C)&0x8000):
                return 1
        return u.CallNextHookEx(None,n,w,l)
    ref=PROC(cb)
    return u.SetWindowsHookExW(WH,ref,k.GetModuleHandleW(None),0),ref

class LockScreen:
    def __init__(self):
        self.hook=None; self.ref=None; self.failed=0; self.until=0; self.dead=False
        self.root=tk.Tk()
        self.root.title(CONFIG.get("title","Windows Lock System"))
        self.root.configure(bg=CONFIG.get("background","#050505"))
        self.root.attributes("-fullscreen",True)
        self.root.attributes("-topmost",True)
        self.root.overrideredirect(True)
        self.build()
        self.root.protocol("WM_DELETE_WINDOW",self.ignore)
        self.keep()

    def build(self):
        bg=CONFIG.get("background","#050505"); fg=CONFIG.get("text_color","#fff")
        center=tk.Frame(self.root,bg=bg); center.place(relx=.5,rely=.5,anchor="center")
        tk.Label(center,text=CONFIG.get("logo_text","LOCK"),bg=bg,fg=CONFIG.get("accent_color","#00A8FF"),font=("Segoe UI",18,"bold")).pack(pady=(0,10))
        tk.Label(center,text=CONFIG.get("message","Dieser Computer ist gesperrt."),bg=bg,fg=fg,font=("Segoe UI",28,"bold")).pack(pady=(0,25))
        tk.Label(center,text=CONFIG.get("code_prompt","Code zum Entsperren:"),bg=bg,fg=fg,font=("Segoe UI",13)).pack()
        self.var=tk.StringVar()
        self.entry=tk.Entry(center,textvariable=self.var,show="●",justify="center",font=("Segoe UI",20),width=22)
        self.entry.pack(ipady=8,pady=8); self.entry.focus_set(); self.entry.bind("<Return>",self.check)
        self.status=tk.Label(center,text="",bg=bg,fg=CONFIG.get("error_color","#ff5555"),font=("Segoe UI",11)); self.status.pack(pady=8)
        self.info=tk.Label(self.root,text="",bg=bg,fg=fg,font=("Segoe UI",11)); self.info.place(relx=.5,rely=.93,anchor="center")
        self.update_info()

    def update_info(self):
        if self.dead:return
        p=[]
        if CONFIG.get("show_clock",True): p.append(datetime.now().strftime("%H:%M:%S"))
        if CONFIG.get("show_date",True): p.append(datetime.now().strftime("%d.%m.%Y"))
        if CONFIG.get("show_battery",True): p.append(battery())
        if CONFIG.get("show_network",True): p.append(network())
        self.info.config(text="   ·   ".join(p))
        self.root.after(2000,self.update_info)

    def check(self,event=None):
        if time.time()<self.until:
            self.status.config(text=f"Bitte noch {max(1,int(self.until-time.time()))} Sekunden warten.")
            self.var.set(""); self.entry.focus_set(); return
        code=self.var.get()
        if sha(code)==CONFIG["exit_code_sha256"]:
            event_log("Entsperren erfolgreich."); beep(); self.unlock(); return
        wrong_code_log(code)
        self.failed+=1; event_log(f"Fehlgeschlagener Versuch #{self.failed}."); beep(True)
        maximum=int(CONFIG.get("max_failed_attempts",5) or 0)
        if maximum and self.failed>=maximum:
            seconds=int(CONFIG.get("lockout_seconds",30) or 30)
            self.until=time.time()+seconds; self.failed=0
            self.status.config(text=f"Zu viele Fehlversuche. Gesperrt für {seconds} Sekunden.")
        else:
            self.status.config(text="Falscher Code." + (f" Noch {maximum-self.failed} Versuche." if maximum else ""))
        self.var.set(""); self.entry.focus_set()

    def ignore(self):
        self.status.config(text="Zum Beenden muss der Entsperrcode eingegeben werden.")

    def keep(self):
        if self.dead:return
        try:
            self.root.attributes("-fullscreen",True); self.root.attributes("-topmost",True)
            self.root.lift(); self.root.focus_force(); taskbar(False)
            self.root.after(500,self.keep)
        except tk.TclError: pass

    def unlock(self):
        self.dead=True
        if self.hook: ctypes.windll.user32.UnhookWindowsHookEx(self.hook)
        taskbar(True); self.root.destroy()

    def run(self):
        self.hook,self.ref=keyboard_hook()
        event_log("Lock-System gestartet.")
        self.root.mainloop()
        event_log("Lock-System beendet.")

if __name__=="__main__":
    if os.name!="nt": sys.exit("Nur Windows wird unterstützt.")
    try: LockScreen().run()
    except Exception as e:
        event_log(f"Programmfehler: {e}")
        print(e); input("Enter zum Beenden...")
