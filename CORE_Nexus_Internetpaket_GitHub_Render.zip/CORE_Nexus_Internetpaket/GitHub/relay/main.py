"""CORE Nexus Relay: neutral, authenticated WebSocket message forwarder.
No CORE Nexus commands are implemented here; messages are forwarded only.
"""
from __future__ import annotations
import asyncio, hmac, json, os, time
from typing import Dict, Set
from fastapi import FastAPI, WebSocket, WebSocketDisconnect, HTTPException
from fastapi.responses import JSONResponse

app = FastAPI(title="CORE Nexus Relay", docs_url=None, redoc_url=None)
RELAY_TOKEN = os.environ.get("CORE_NEXUS_RELAY_TOKEN", "").strip()
MAX_MESSAGE_BYTES = int(os.environ.get("MAX_MESSAGE_BYTES", "8388608"))
HEARTBEAT_SECONDS = int(os.environ.get("HEARTBEAT_SECONDS", "45"))
# room -> role -> active websocket connections
connections: Dict[str, Dict[str, Set[WebSocket]]] = {}
lock = asyncio.Lock()

def token_ok(value: str) -> bool:
    return bool(RELAY_TOKEN) and hmac.compare_digest(value.encode(), RELAY_TOKEN.encode())

@app.get("/")
async def health():
    return {"service": "CORE Nexus Relay", "status": "online", "protocol": "websocket-json-v1"}

@app.get("/health")
async def health_check():
    return JSONResponse({"status": "ok", "timestamp": int(time.time())})

@app.websocket("/ws")
async def websocket_endpoint(ws: WebSocket):
    # Authentication is required before the socket is accepted.
    token = ws.query_params.get("token", "")
    if not token_ok(token):
        await ws.close(code=4401, reason="Unauthorized")
        return
    await ws.accept()
    room = ""
    role = ""
    try:
        hello = await asyncio.wait_for(ws.receive_json(), timeout=10)
        if not isinstance(hello, dict) or hello.get("type") != "register":
            await ws.close(code=4400, reason="First message must be register")
            return
        role = str(hello.get("role", ""))
        room = str(hello.get("room", ""))[:128]
        if role not in ("server", "agent") or not room or len(room) < 8:
            await ws.close(code=4400, reason="Invalid role or room")
            return
        async with lock:
            connections.setdefault(room, {}).setdefault(role, set()).add(ws)
        await ws.send_json({"type": "registered", "role": role, "room": room})
        while True:
            raw = await ws.receive_text()
            if len(raw.encode("utf-8")) > MAX_MESSAGE_BYTES:
                await ws.close(code=4409, reason="Message too large")
                return
            try:
                message = json.loads(raw)
            except json.JSONDecodeError:
                continue
            if not isinstance(message, dict):
                continue
            # The relay only routes an envelope; it does not execute commands.
            target = "agent" if role == "server" else "server"
            destination = message.get("device_id") if role == "server" else room
            envelope = {"type": "relay_message", "from": role, "room": room,
                        "device_id": str(destination or "")[:128], "payload": message}
            async with lock:
                recipients = list(connections.get(room, {}).get(target, set()))
            if not recipients:
                await ws.send_json({"type": "delivery", "ok": False, "reason": "peer_offline"})
                continue
            delivered = 0
            for peer in recipients:
                try:
                    await peer.send_json(envelope)
                    delivered += 1
                except Exception:
                    pass
            await ws.send_json({"type": "delivery", "ok": delivered > 0, "count": delivered})
    except (WebSocketDisconnect, asyncio.TimeoutError):
        pass
    except Exception:
        try:
            await ws.close(code=1011, reason="Relay error")
        except Exception:
            pass
    finally:
        if room and role:
            async with lock:
                roles = connections.get(room, {})
                roles.get(role, set()).discard(ws)
                for empty_role in [r for r, sockets in roles.items() if not sockets]:
                    roles.pop(empty_role, None)
                if not roles:
                    connections.pop(room, None)
