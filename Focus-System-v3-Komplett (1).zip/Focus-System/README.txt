FOCUS SYSTEM 3.0 – PORTABLE WINDOWS-VERSION
===========================================

ERSTELLEN
---------
Das fertige Programm ist eine portable Windows-Anwendung ohne Installer.
Zum ERSTELLEN auf dem Build-PC werden Node.js (LTS) und npm benötigt.
Auf dem späteren Ziel-PC werden weder Node.js noch Python benötigt.

1. Node.js LTS auf dem Build-PC installieren.
2. Den gesamten Ordner "Focus-System" entpacken.
3. Terminal in diesem Ordner öffnen.
4. Ausführen:

   npm install
   npm run build:win

5. Die Anwendung liegt anschließend unter:

   dist\win-unpacked\Focus System.exe

Den gesamten Ordner "win-unpacked" verschieben/kopieren, nicht nur die EXE.
Electron benötigt die weiteren Dateien in diesem Ordner. Die Anwendung selbst
legt ihre Konfiguration und Protokolle neben der EXE ab und verschiebt keine
Programmdateien nach AppData.

ERSTER START
------------
Beim ersten Start muss ein eigenes Hauptpasswort eingerichtet werden.
Danach öffnet sich eine leere Oberfläche. Es gibt keine Beispielkategorien,
keine Beispielprogramme und keine vorgefertigten Zeitpläne.

KATEGORIEN UND PROGRAMME
------------------------
1. Dashboard öffnen und mit dem Hauptpasswort anmelden.
2. Unter "Kategorien" eigene Kategorien anlegen.
3. Unter "Programme" die gewünschten Windows-Programme zuerst starten.
4. Die laufenden Programme aktualisieren, eine Kategorie auswählen und das
   Programm hinzufügen.
5. Auf der Startseite eine Kategorie auswählen und den Fokusmodus starten.

Im Fokusmodus werden nicht erlaubte normale Programmfenster minimiert, nicht
beendet. Windows-Systemfenster und die Windows-Shell werden teilweise ausgenommen.

ZEITSTEUERUNG
-------------
Startzeit, Endzeit und Dauer sind unabhängig voneinander optional.
- Startzeit: Fokusmodus startet zum angegebenen Zeitpunkt automatisch.
- Ohne Startzeit: Fokusmodus kann manuell gestartet werden.
- Endzeit: Fokusmodus endet zu diesem Zeitpunkt.
- Dauer: zählt ab dem tatsächlichen Start des Fokusmodus.
- Endzeit und Dauer zusammen: Der zuerst erreichte Endpunkt gilt.
- Keine Endzeit und keine Dauer: manueller Stopp erforderlich.

Bei geplanter Startzeit erscheinen Windows-Benachrichtigungen 5, 3, 2 und
1 Minute vor dem Start. Focus System muss geöffnet bleiben. Beim Schließen
mit X wird es in den Infobereich minimiert. Zum vollständigen Beenden das
Kontextmenü des Infobereich-Symbols verwenden.

SCREEN-LOCK
-----------
Das Screen-Lock-Passwort gilt nur für die jeweilige Sitzung und wird nur im
Arbeitsspeicher gehalten. Es wird nach dem Entsperren verworfen. Eine optionale
Dauer führt zur automatischen Entsperrung. Der Screen-Lock ist eine zusätzliche
Konzentrationssperre, keine unüberwindbare Betriebssystemsperre.

DATEN
-----
focus-config.json  – Einstellungen und Hauptpasswort (Klartext, wie gewünscht)
focus-log.jsonl    – Systemprotokoll
Beide Dateien werden bei Bedarf neben der EXE erstellt.

GRENZEN
-------
Focus System beendet keine Programme und kann nicht verhindern, dass Windows
über Task-Manager, Abmelden, Neustart oder andere Betriebssystemfunktionen
verlassen wird. Die Fensterkontrolle hängt von Windows-Rechten ab und davon,
ob Windows den vollständigen Prozesspfad bereitstellt.

OPTIONALE WINDOWS-SUCHE
-----------------------
Windows-Suche-einrichten.bat erstellt eine Startmenü-Verknüpfung. Es werden
keine Programmdateien kopiert. Nach einem Verschieben des Ordners muss die BAT
erneut ausgeführt werden. Windows-Suche-entfernen.bat entfernt die Verknüpfung.
