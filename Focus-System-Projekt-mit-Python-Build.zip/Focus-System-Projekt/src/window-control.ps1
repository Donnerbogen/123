param(
  [Parameter(Mandatory=$true)][string]$Mode,
  [string]$AllowedJson = "[]",
  [string]$Kind = "focus",
  [string]$OwnPid = "0"
)
Add-Type @"
using System;
using System.Runtime.InteropServices;
public class WinApi {
  [DllImport("user32.dll")] public static extern bool EnumWindows(EnumWindowsProc cb, IntPtr extra);
  public delegate bool EnumWindowsProc(IntPtr hwnd, IntPtr lParam);
  [DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr hwnd);
  [DllImport("user32.dll")] public static extern int GetWindowText(IntPtr hwnd, System.Text.StringBuilder text, int count);
  [DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr hwnd, int cmd);
  [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr hwnd, out uint pid);
  [DllImport("user32.dll")] public static extern bool IsIconic(IntPtr hwnd);
}
"@
function Get-WindowTitle($h) {
  $b = New-Object System.Text.StringBuilder 512
  [void][WinApi]::GetWindowText($h, $b, $b.Capacity)
  return $b.ToString()
}
function Get-ProcessPath([uint32]$pid) {
  try { return (Get-Process -Id $pid -ErrorAction Stop).Path } catch { return "" }
}
if ($Mode -eq "list") {
  $items = New-Object System.Collections.Generic.List[object]
  [WinApi]::EnumWindows({
    param($h,$l)
    if ([WinApi]::IsWindowVisible($h)) {
      $title = Get-WindowTitle $h
      [uint32]$pid = 0
      [void][WinApi]::GetWindowThreadProcessId($h,[ref]$pid)
      $p = Get-ProcessPath $pid
      if ($title -and $p) { $items.Add(@{title=$title; path=$p}) }
    }
    return $true
  }, [IntPtr]::Zero) | Out-Null
  ConvertTo-Json -InputObject @($items) -Compress -Depth 4
  exit
}
if ($Mode -eq "enforce") {
  try { $allowed = @($AllowedJson | ConvertFrom-Json) } catch { $allowed = @() }
  $self = [int]$OwnPid
  $safe = @("explorer","dwm","sihost","StartMenuExperienceHost","ShellExperienceHost","SearchHost","TextInputHost","LockApp","SystemSettings","ApplicationFrameHost","taskmgr")
  [WinApi]::EnumWindows({
    param($h,$l)
    if (-not [WinApi]::IsWindowVisible($h) -or [WinApi]::IsIconic($h)) { return $true }
    $title = Get-WindowTitle $h
    if (-not $title) { return $true }
    [uint32]$pid = 0
    [void][WinApi]::GetWindowThreadProcessId($h,[ref]$pid)
    if ($pid -eq $self) { return $true }
    try { $proc = Get-Process -Id $pid -ErrorAction Stop; $name = $proc.ProcessName } catch { return $true }
    if ($safe -contains $name) { return $true }
    $p = Get-ProcessPath $pid
    if ($Kind -ne "lock" -and $p -and ($allowed | Where-Object { $_ -and $_.ToLowerInvariant() -eq $p.ToLowerInvariant() })) { return $true }
    [void][WinApi]::ShowWindow($h, 6)
    return $true
  }, [IntPtr]::Zero) | Out-Null
}
