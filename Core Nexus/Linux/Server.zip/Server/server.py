"""CORE Nexus LAN server — cross-platform Tkinter dashboard.
All persistent application data lives in Server/data/core_nexus.sqlite3.
Run with: python server.py
"""
from __future__ import annotations
import base64, csv, hashlib, hmac, json, os, queue, secrets, socket, sqlite3, threading, time, uuid
from pathlib import Path
from datetime import datetime
import tkinter as tk
from tkinter import ttk, messagebox, simpledialog
from nexus_license import ensure_license, schedule_license_reminders

ROOT = Path(__file__).resolve().parent
DATA = ROOT / 'data'
DB = DATA / 'core_nexus.sqlite3'
HOST = '0.0.0.0'
PORT = 47621
DISCOVERY_PORT = 47622
APP = 'CORE Nexus'
PERMISSIONS = {
    'view_devices': 'Geräte anzeigen', 'view_system_info': 'Systeminformationen ansehen',
    'remote_view': 'Bildschirm ansehen', 'remote_input': 'Maus und Tastatur steuern',
    'register_devices': 'Geräte freigeben', 'manage_grants': 'Gerätefreigaben verwalten',
    'file_transfer': 'Dateien an Geräte übertragen', 'clipboard_share': 'Zwischenablage teilen', 'manage_groups': 'Gerätegruppen verwalten',
    'close_agents': 'Alle Agenten schließen', 'manage_accounts': 'Konten verwalten',
    'server_settings': 'Servereinstellungen verwalten', 'view_logs': 'Protokolle ansehen'
}

def password_hash(password: str, salt: bytes | None = None) -> str:
    salt = salt or secrets.token_bytes(16)
    digest = hashlib.pbkdf2_hmac('sha256', password.encode('utf-8'), salt, 310_000)
    return base64.b64encode(salt + digest).decode('ascii')

def password_ok(password: str, stored: str) -> bool:
    try:
        raw = base64.b64decode(stored.encode('ascii'))
        return hmac.compare_digest(raw[16:], hashlib.pbkdf2_hmac('sha256', password.encode('utf-8'), raw[:16], 310_000))
    except Exception:
        return False

class RelayVirtualFile:
    def __init__(self, conn): self.conn=conn; self.buffer=bytearray()
    def readline(self):
        while b'\n' not in self.buffer:
            if self.conn.closed: return b''
            try: item=self.conn.incoming.get(timeout=20)
            except queue.Empty: raise socket.timeout('Relay-Heartbeat-Timeout')
            if item is None: return b''
            self.buffer.extend(item)
        pos=self.buffer.index(b'\n')+1; line=bytes(self.buffer[:pos]); del self.buffer[:pos]; return line
    def write(self, data): self.conn.send_line(data); return len(data)
    def flush(self): pass
    def close(self): self.conn.close()

class RelayVirtualConn:
    def __init__(self, app, device_id, remote_ip='relay'):
        self.app=app; self.device_id=device_id; self.remote_ip=remote_ip; self.incoming=queue.Queue(); self.closed=False; self.file=RelayVirtualFile(self)
    def settimeout(self, value): pass
    def makefile(self, mode): return self.file
    def send_line(self, data):
        if self.closed: raise OSError('Relay-Gerät ist getrennt')
        self.app._relay_send(self.device_id, data)
    def close(self):
        if not self.closed:
            self.closed=True
            try: self.incoming.put_nowait(None)
            except Exception: pass

class NexusServer:
    def __init__(self):
        DATA.mkdir(parents=True, exist_ok=True)
        self.db_lock = threading.RLock()
        self.clients: dict[str, socket.socket] = {}
        self.client_lock = threading.RLock()
        self.ui_events: queue.Queue = queue.Queue()
        self.running = True
        self.admin_token = self._load_admin_token()
        self.admin_remote_device = None
        self.admin_remote_session = None
        self.admin_remote_commands = {}
        self.admin_remote_lock = threading.RLock()
        self.admin_tcp = None
        self.current_account = None
        self.dashboard_visible = False
        self.poll_started = False
        self.remote_frames = {}
        # Original JPEG dimensions and actual dimensions rendered in the Tk label.
        # They differ whenever the server-side preview is scaled to fit the window.
        self.remote_frame_dimensions = {}
        self.remote_display_dimensions = {}
        self._remote_rendered_data = None
        self.remote_commands = {}
        self.remote_device = None
        self.checked_devices: set[str] = set()
        self.remote_window = None
        self.remote_image_label = None
        self.remote_photo = None
        self._last_periodic_refresh = 0
        self.db = sqlite3.connect(DB, check_same_thread=False)
        self.db.row_factory = sqlite3.Row
        self._schema()
        self.tcp = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.tcp.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.tcp.bind((HOST, PORT)); self.tcp.listen(40); self.tcp.settimeout(1)
        threading.Thread(target=self._accept_loop, daemon=True).start()
        self.admin_tcp = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.admin_tcp.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        try:
            self.admin_tcp.bind((HOST, 47623)); self.admin_tcp.listen(20); self.admin_tcp.settimeout(1)
            threading.Thread(target=self._admin_accept_loop, daemon=True).start()
        except OSError as exc:
            print(f'[CORE Nexus] Admin-Port 47623 konnte nicht geöffnet werden: {exc}')
        threading.Thread(target=self._discovery_loop, daemon=True).start()
        self.relay_config = self._load_relay_config()
        self.relay_ws = None
        self.relay_ws_lock = threading.RLock()
        self.relay_connections = {}
        if self.relay_config.get('enabled'):
            threading.Thread(target=self._relay_loop, daemon=True).start()
        self.root = tk.Tk(); self.root.title('CORE Nexus | Device Control Center'); self.root.geometry('1240x790'); self.root.minsize(980, 650)
        self._style(); self.root.geometry('1240x790'); self.root.minsize(980, 650); self.root.protocol('WM_DELETE_WINDOW', self.close)
        self._ensure_owner()

    def _load_admin_token(self):
        path = ROOT / 'admin_config.json'
        try:
            cfg = json.loads(path.read_text(encoding='utf-8'))
            token = (os.environ.get('CORE_NEXUS_ADMIN_TOKEN') or cfg.get('admin_token') or '').strip()
            if not token or token.startswith('CHANGE_ME_'):
                print('[CORE Nexus] Adminserver nicht aktiviert: admin_config.json benötigt einen individuellen admin_token.')
                return ''
            return token
        except Exception:
            print('[CORE Nexus] Adminserver nicht aktiviert: admin_config.json fehlt oder ist ungültig.')
            return ''

    def _admin_accept_loop(self):
        while self.running and self.admin_tcp:
            try: conn, addr = self.admin_tcp.accept()
            except socket.timeout: continue
            except OSError: break
            threading.Thread(target=self._client_loop, args=(conn, addr), daemon=True).start()

    def _admin_send(self, session, payload):
        try:
            with session['send_lock']:
                self._send(session['file'], payload)
            return True
        except Exception:
            return False

    def _admin_client_loop(self, conn, addr, file, first_message):
        role = str(first_message.get('client_role', 'admin'))
        account = None
        if role == 'agent_user':
            username = str(first_message.get('username', '')).strip()[:120]
            with self.db_lock:
                account_row = self.db.execute('SELECT * FROM accounts WHERE username=? AND active=1', (username,)).fetchone()
            # Challenge-response: the account password is never sent over the LAN socket.
            try:
                stored = base64.b64decode(account_row['password_hash'].encode('ascii')) if account_row else b''
            except Exception:
                stored = b''
            if not account_row or len(stored) < 48:
                self._send(file, {'ok': False, 'type': 'agent_login_result', 'error': 'login_failed'})
                self._log(username or 'unknown', 'agent_login_failed', f'Fehlgeschlagener Agent-Login von {addr[0]}')
                return
            nonce = secrets.token_urlsafe(32)
            self._send(file, {'ok': True, 'type': 'auth_challenge', 'nonce': nonce,
                              'salt': base64.b64encode(stored[:16]).decode('ascii')})
            proof_line = file.readline()
            try:
                proof_message = json.loads(proof_line.decode('utf-8')) if proof_line else {}
            except Exception:
                proof_message = {}
            expected_proof = hmac.new(stored[16:], nonce.encode('utf-8'), hashlib.sha256).hexdigest()
            supplied_proof = str(proof_message.get('proof', '')) if proof_message.get('type') == 'agent_auth_proof' else ''
            if not hmac.compare_digest(expected_proof, supplied_proof):
                self._send(file, {'ok': False, 'type': 'agent_login_result', 'error': 'login_failed'})
                self._log(username or 'unknown', 'agent_login_failed', f'Fehlgeschlagener Agent-Login von {addr[0]}')
                return
            try:
                permissions = json.loads(account_row['permissions'])
            except Exception:
                permissions = []
            account = {'id': int(account_row['id']), 'username': username,
                       'is_owner': bool(account_row['is_owner']), 'permissions': permissions}
            self._log(username, 'agent_login_success', f'Agent-Anmeldung von {addr[0]}')
        else:
            token = str(first_message.get('admin_token', ''))
            if not self.admin_token or not hmac.compare_digest(token, self.admin_token):
                if not self._consume_sync_code(token):
                    self._send(file, {'ok': False, 'error': 'admin_unauthorized_or_sync_code_invalid'}); return
                self._log('server-sync', 'sync_code_redeemed', f'Einmaliger Sync-Code von {addr[0]} eingelöst')
        session = {'conn': conn, 'file': file, 'send_lock': threading.RLock(), 'remote_device': None,
                   'role': role, 'account': account}
        self._admin_send(session, {'ok': True, 'type': 'agent_login_result' if role == 'agent_user' else 'admin_ready',
                                  'server_name': APP, 'username': account['username'] if account else 'admin'})
        try:
            while self.running:
                line = file.readline()
                if not line: break
                if len(line) > 8_000_000: break
                try: msg = json.loads(line.decode('utf-8'))
                except Exception: continue
                typ = msg.get('type'); rid = msg.get('request_id')
                response = {'type': 'response', 'request_id': rid, 'ok': True}
                is_agent_user = session.get('role') == 'agent_user'
                user_account = session.get('account') or {}
                user_perms = set(user_account.get('permissions', []))
                user_owner = bool(user_account.get('is_owner'))
                if typ == 'list_devices':
                    if is_agent_user and not (user_owner or 'view_devices' in user_perms):
                        response.update(ok=False, error='permission_denied')
                    else:
                        with self.db_lock:
                            rows = self.db.execute('SELECT id,name,ip,approved,consent,last_seen,os,notes,device_group FROM devices ORDER BY device_group COLLATE NOCASE,name COLLATE NOCASE').fetchall()
                            if is_agent_user and not user_owner:
                                assigned = {r['device_id'] for r in self.db.execute('SELECT device_id FROM grants WHERE account_id=?', (int(user_account.get('id', -1)),)).fetchall()}
                            else:
                                assigned = None
                        with self.client_lock: online = set(self.clients.keys())
                        response['devices'] = [dict(r) | {'online': r['id'] in online} for r in rows
                                               if not is_agent_user or (r['approved'] and r['consent'] and (user_owner or r['id'] in assigned))]
                elif typ == 'remote_start':
                    if is_agent_user and not (user_owner or ('remote_view' in user_perms and 'remote_input' in user_perms)):
                        response.update(ok=False, error='permission_denied')
                        self._admin_send(session, response)
                        continue
                    did = str(msg.get('device_id', ''))
                    with self.db_lock:
                        row = self.db.execute('SELECT approved,consent,name FROM devices WHERE id=?', (did,)).fetchone()
                        assigned = True
                        if is_agent_user and not user_owner:
                            assigned = self.db.execute('SELECT 1 FROM grants WHERE device_id=? AND account_id=?', (did, int(user_account.get('id', -1)))).fetchone() is not None
                    with self.client_lock: is_online = did in self.clients
                    if is_agent_user and not user_owner and not assigned:
                        response.update(ok=False, error='device_not_assigned')
                    elif not row or not row['approved'] or not row['consent']:
                        response.update(ok=False, error='device_not_approved_or_no_consent')
                    elif not is_online:
                        response.update(ok=False, error='device_offline')
                    else:
                        with self.admin_remote_lock:
                            if self.remote_window is not None:
                                response.update(ok=False, error='server_remote_session_busy')
                            elif self.admin_remote_session is not None and self.admin_remote_session is not session:
                                response.update(ok=False, error='another_admin_session_active')
                            else:
                                self.admin_remote_device = did
                                self.admin_remote_session = session
                                self.admin_remote_commands.setdefault(did, [])
                                session['remote_device'] = did
                                self._log('adminserver', 'remote_session_started', did)
                                response['device_name'] = row['name']
                elif typ == 'remote_input':
                    if is_agent_user and not (user_owner or 'remote_input' in user_perms):
                        response.update(ok=False, error='permission_denied')
                        self._admin_send(session, response)
                        continue
                    did = str(msg.get('device_id', ''))
                    with self.admin_remote_lock:
                        active_session = self.admin_remote_session is session and self.admin_remote_device == did
                    with self.db_lock:
                        assigned = True
                        if is_agent_user and not user_owner:
                            assigned = self.db.execute('SELECT 1 FROM grants WHERE device_id=? AND account_id=?', (did, int(user_account.get('id', -1)))).fetchone() is not None
                    with self.admin_remote_lock:
                        if not active_session or (is_agent_user and not assigned):
                            response.update(ok=False, error='device_not_assigned' if is_agent_user and not assigned else 'remote_session_not_active')
                        else:
                            cmd = msg.get('command')
                            if isinstance(cmd, dict):
                                kind = str(cmd.get('kind', ''))
                                required = 'file_transfer' if kind in ('file_begin','file_chunk','file_end') else ('clipboard_share' if kind == 'clipboard_text' else None)
                                if is_agent_user and not user_owner and required and required not in user_perms:
                                    response.update(ok=False, error='permission_denied')
                                else:
                                    self.admin_remote_commands.setdefault(did, []).append(cmd)
                                    if len(self.admin_remote_commands[did]) > 300:
                                        self.admin_remote_commands[did] = self.admin_remote_commands[did][-250:]
                elif typ == 'remote_stop':
                    with self.admin_remote_lock:
                        if self.admin_remote_session is session:
                            did = self.admin_remote_device
                            self.admin_remote_device = None; self.admin_remote_session = None
                            self.admin_remote_commands.clear(); session['remote_device'] = None
                            if did: self._log('adminserver', 'remote_session_stopped', did)
                elif typ == 'ping':
                    response['time'] = time.time()
                else:
                    response.update(ok=False, error='unsupported_admin_command')
                if rid is not None or typ != 'remote_input':
                    self._admin_send(session, response)
        except (OSError, ValueError, AttributeError):
            pass
        finally:
            with self.admin_remote_lock:
                if self.admin_remote_session is session:
                    did = self.admin_remote_device
                    self.admin_remote_device = None; self.admin_remote_session = None
                    self.admin_remote_commands.clear()
                    if did: self._log('adminserver', 'remote_session_disconnected', did)

    def _load_relay_config(self):
        path = ROOT / 'relay_config.json'
        try:
            cfg = json.loads(path.read_text(encoding='utf-8'))
            cfg['relay_token'] = (os.environ.get(cfg.get('relay_token_env','CORE_NEXUS_RELAY_TOKEN')) or cfg.get('relay_token') or '').strip()
            return cfg
        except Exception as exc:
            print(f'[CORE Nexus] Relay-Konfiguration nicht lesbar: {exc}')
            return {'enabled': False}

    def _relay_send(self, device_id, data):
        cfg=self.relay_config
        try: payload=json.loads(data.decode('utf-8').strip())
        except Exception: return
        with self.relay_ws_lock:
            ws=self.relay_ws
            if ws is None: raise OSError('Render-Relay nicht verbunden')
            ws.send(json.dumps({'device_id':device_id,'payload':payload},separators=(',',':')))

    def _relay_loop(self):
        try:
            import websocket
        except Exception:
            print('[CORE Nexus] Relay benötigt websocket-client. Bitte Server/install.bat ausführen.')
            return
        while self.running:
            cfg=self.relay_config
            url=str(cfg.get('relay_url','')).strip(); token=str(cfg.get('relay_token','')).strip(); room=str(cfg.get('room_id','')).strip()
            if not url.startswith('wss://') or not token or not room or 'PASTE_' in token:
                print('[CORE Nexus] Relay nicht konfiguriert: relay_config.json prüfen.')
                time.sleep(8); continue
            ws=None
            try:
                ws=websocket.create_connection(url,timeout=15,header=[f'Authorization: Bearer {token}', 'X-Core-Role: server', f'X-Core-Room: {room}', f"X-Core-Name: {cfg.get('server_name', APP)}"],origin=url.split('/ws')[0])
                ws.settimeout(30)
                with self.relay_ws_lock: self.relay_ws=ws
                print('[CORE Nexus] Render-Relay verbunden.')
                while self.running:
                    raw=ws.recv()
                    if not raw: raise ConnectionError('Relay-Verbindung beendet')
                    envelope=json.loads(raw); did=str(envelope.get('device_id',''))[:80]; payload=envelope.get('payload')
                    if not did or not isinstance(payload,dict): continue
                    conn=self.relay_connections.get(did)
                    if conn is None or conn.closed:
                        conn=RelayVirtualConn(self,did)
                        self.relay_connections[did]=conn
                        threading.Thread(target=self._client_loop,args=(conn,(conn.remote_ip,0)),daemon=True).start()
                    conn.incoming.put((json.dumps(payload,separators=(',',':'))+'\n').encode('utf-8'))
            except Exception as exc:
                print(f'[CORE Nexus] Relay-Verbindung unterbrochen: {exc}')
            finally:
                with self.relay_ws_lock: self.relay_ws=None
                for conn in list(self.relay_connections.values()): conn.close()
                self.relay_connections.clear()
                try:
                    if ws: ws.close()
                except Exception: pass
            time.sleep(5)

    def _schema(self):
        with self.db_lock:
            self.db.executescript('''
            CREATE TABLE IF NOT EXISTS accounts(id INTEGER PRIMARY KEY, username TEXT UNIQUE NOT NULL, password_hash TEXT NOT NULL, is_owner INTEGER NOT NULL DEFAULT 0, permissions TEXT NOT NULL DEFAULT '[]', created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, active INTEGER NOT NULL DEFAULT 1);
            CREATE TABLE IF NOT EXISTS devices(id TEXT PRIMARY KEY, name TEXT NOT NULL, ip TEXT, approved INTEGER NOT NULL DEFAULT 0, consent INTEGER NOT NULL DEFAULT 0, last_seen TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, os TEXT DEFAULT '', boot_id TEXT DEFAULT '', notes TEXT DEFAULT '', device_group TEXT DEFAULT 'Standard');
            
            CREATE TABLE IF NOT EXISTS grants(device_id TEXT NOT NULL, account_id INTEGER NOT NULL, permissions TEXT NOT NULL, PRIMARY KEY(device_id,account_id));
            CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY, value TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS logs(id INTEGER PRIMARY KEY, at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, actor TEXT, action TEXT NOT NULL, detail TEXT);
            CREATE TABLE IF NOT EXISTS sync_codes(code_hash TEXT PRIMARY KEY, expires_at REAL NOT NULL, created_by TEXT NOT NULL, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
            ''');
            cols = {r['name'] for r in self.db.execute('PRAGMA table_info(devices)').fetchall()}
            if 'device_group' not in cols: self.db.execute("ALTER TABLE devices ADD COLUMN device_group TEXT DEFAULT 'Standard'")
            self.db.commit()

    def _ensure_owner(self):
        row = self.db.execute('SELECT id FROM accounts WHERE is_owner=1').fetchone()
        if not row:
            # A centrally provisioned owner is supplied as a password hash only.
            cfg_path = ROOT / 'admin_config.json'
            try:
                cfg = json.loads(cfg_path.read_text(encoding='utf-8'))
                username = str(cfg.get('bootstrap_owner_username', '')).strip()
                stored_hash = str(cfg.get('bootstrap_owner_password_hash', '')).strip()
                if username and len(username) >= 2 and stored_hash and len(base64.b64decode(stored_hash)) >= 48:
                    with self.db_lock:
                        self.db.execute('INSERT INTO accounts(username,password_hash,is_owner,permissions) VALUES(?,?,1,?)',
                                        (username, stored_hash, json.dumps(list(PERMISSIONS))))
                        self.db.commit()
                    # Remove the bootstrap hash from the config after successful import.
                    cfg.pop('bootstrap_owner_username', None)
                    cfg.pop('bootstrap_owner_password_hash', None)
                    cfg_path.write_text(json.dumps(cfg, indent=2, ensure_ascii=False), encoding='utf-8')
                    self._log(username, 'owner_setup', 'Zentral provisioniertes Owner-Konto übernommen')
                    self.root.after(150, self._show_login)
                    return
            except Exception as exc:
                print(f'[CORE Nexus] Owner-Provisionierung nicht nutzbar: {exc}')
            self.root.after(300, self._setup_owner)
        else:
            self.root.after(150, self._show_login)

    def _setup_owner(self):
        self.root.deiconify()
        self.root.lift()
        self.root.title('CORE Nexus | Owner-Ersteinrichtung')
        messagebox.showinfo(APP, 'Ersteinrichtung: Lege jetzt das zentrale Owner-Konto an. Das Passwort wird nur als sicherer Hash gespeichert.', parent=self.root)
        username = simpledialog.askstring('Owner einrichten', 'Owner-Benutzername:', parent=self.root)
        if not username or len(username.strip()) < 2:
            messagebox.showerror(APP, 'Einrichtung abgebrochen. Starte den Server erneut, um den Owner einzurichten.', parent=self.root); self.root.after(300, self._setup_owner); return
        password = simpledialog.askstring('Owner einrichten', 'Owner-Passwort (mindestens 4 Zeichen):', show='*', parent=self.root)
        if not password or len(password) < 4:
            messagebox.showerror(APP, 'Das Passwort muss mindestens 4 Zeichen lang sein.', parent=self.root); self.root.after(300, self._setup_owner); return
        with self.db_lock:
            self.db.execute('INSERT INTO accounts(username,password_hash,is_owner,permissions) VALUES(?,?,1,?)', (username.strip(), password_hash(password), json.dumps(list(PERMISSIONS))))
            self.db.commit()
        self._log(username.strip(), 'owner_setup', 'Owner-Konto angelegt'); self.refresh_accounts()
        messagebox.showinfo(APP, 'Owner-Konto wurde eingerichtet. Bitte melde dich jetzt an.', parent=self.root)
        self._show_login()

    def _show_login(self):
        self.dashboard_visible = False
        # Use the main window for login instead of a transient dialog whose
        # parent was withdrawn. This avoids the blank/invisible-window issue
        # after the first Owner setup on some Windows/Tk combinations.
        for child in self.root.winfo_children():
            try:
                child.destroy()
            except tk.TclError:
                pass
        self.root.title('CORE Nexus | Server-Anmeldung')
        self.root.geometry('430x360')
        self.root.minsize(430, 360)
        self.root.deiconify()
        self.root.lift()
        outer = ttk.Frame(self.root, padding=(30, 24))
        outer.pack(fill='both', expand=True)
        ttk.Label(outer, text='CORE NEXUS', style='Title.TLabel').pack(pady=(24, 6))
        ttk.Label(outer, text='Bitte am Server anmelden', style='Sub.TLabel').pack(pady=(0, 22))
        form = ttk.Frame(outer)
        form.pack(fill='x', padx=18)
        ttk.Label(form, text='Benutzername').pack(anchor='w')
        user = ttk.Entry(form)
        user.pack(fill='x', pady=(4, 12))
        ttk.Label(form, text='Passwort').pack(anchor='w')
        pw = ttk.Entry(form, show='*')
        pw.pack(fill='x', pady=(4, 12))
        error = ttk.Label(outer, text='', foreground='#ff8585')
        error.pack(pady=(0, 2))

        def attempt(event=None):
            username = user.get().strip()
            password = pw.get()
            with self.db_lock:
                account = self.db.execute('SELECT * FROM accounts WHERE username=? AND active=1', (username,)).fetchone()
            if not account or not password_ok(password, account['password_hash']):
                error.configure(text='Anmeldung fehlgeschlagen. Zugangsdaten prüfen.')
                pw.delete(0, 'end')
                pw.focus_set()
                self._log(username or 'unknown', 'server_login_failed', 'Ungültige Zugangsdaten')
                return
            self.current_account = dict(account)
            try:
                self.current_account['permissions'] = json.loads(account['permissions'])
            except Exception:
                self.current_account['permissions'] = []
            self._log(username, 'server_login_success', 'Dashboard-Anmeldung erfolgreich')
            self._show_dashboard()

        ttk.Button(outer, text='Anmelden', command=attempt).pack(pady=(12, 5))
        ttk.Label(outer, text='Der Serverdienst läuft auch ohne Dashboard-Anmeldung weiter.', style='Sub.TLabel', wraplength=340, justify='center').pack(pady=(8, 0))
        self.root.bind('<Return>', attempt)
        user.focus_set()

    def _show_dashboard(self):
        if not self.current_account:
            self._show_login()
            return
        self.dashboard_visible = True
        for child in self.root.winfo_children():
            try:
                child.destroy()
            except tk.TclError:
                pass
        try:
            self.root.unbind('<Return>')
        except tk.TclError:
            pass
        self.root.title('CORE Nexus | Device Control Center')
        self.root.geometry('1050x680')
        self.root.minsize(850, 560)
        self._build_ui()
        self.root.deiconify()
        self.root.lift()
        if not self.poll_started:
            self.poll_started = True
            self.root.after(200, self._poll_ui)

    def _continue_as_guest(self):
        # Compatibility handler for older UI versions: guest dashboard access is disabled.
        self.current_account = None
        self._show_login()

    def _logout_to_guest(self):
        # Logging out locks only the GUI. Network listeners, LAN discovery, relay and
        # connected agents keep running in their background threads.
        if self.current_account:
            username = self.current_account.get('username', 'unbekannt')
            self._log(username, 'server_logout', 'Abmeldung; Serverdienst läuft im Hintergrund weiter')
        self.stop_remote()
        self.current_account = None
        self._show_login()

    def _login_from_guest(self):
        self._show_login()

    def is_owner_context(self):
        return bool(self.current_account and self.current_account.get('is_owner'))

    def has_permission(self, permission):
        account = self.current_account or {}
        return bool(account) and (bool(account.get('is_owner')) or permission in account.get('permissions', []))

    def require_permission(self, permission):
        if self.has_permission(permission): return True
        messagebox.showwarning(APP, 'Du besitzt nicht die erforderliche Berechtigung.', parent=self.root)
        return False

    def _style(self):
        self.root.configure(bg='#060b16'); s=ttk.Style(); s.theme_use('clam')
        s.configure('.', background='#0b1628', foreground='#eef6ff', fieldbackground='#101f34', bordercolor='#203b5b', font=('Segoe UI', 10))
        s.configure('TFrame', background='#0b1628'); s.configure('TLabel', background='#0b1628', foreground='#eef6ff', font=('Segoe UI', 10))
        s.configure('Title.TLabel', font=('Segoe UI', 23, 'bold'), foreground='#55d9ff'); s.configure('Sub.TLabel', foreground='#91a7c4', font=('Segoe UI', 9))
        s.configure('Hero.TLabel', font=('Segoe UI', 12, 'bold'), foreground='#d9efff')
        s.configure('Card.TFrame', background='#0d1b2e', relief='solid', borderwidth=1)
        s.configure('TButton', background='#153657', foreground='#f4faff', padding=(12, 9), borderwidth=1, focusthickness=0)
        s.map('TButton', background=[('active','#1e5b89'),('pressed','#16436a')], foreground=[('disabled','#71849e')])
        s.configure('Treeview', background='#081322', fieldbackground='#081322', foreground='#eaf2ff', rowheight=32, borderwidth=0, font=('Segoe UI', 9))
        s.configure('Treeview.Heading', background='#142a43', foreground='#aee9ff', padding=(9, 9), font=('Segoe UI', 9, 'bold'))
        s.map('Treeview', background=[('selected','#174d78')], foreground=[('selected','#ffffff')])
        s.configure('TNotebook', background='#0b1628', borderwidth=0, tabmargins=(3, 5, 3, 0))
        s.configure('TNotebook.Tab', background='#10223a', foreground='#a9bfd8', padding=(16, 10), font=('Segoe UI', 9, 'bold'))
        s.map('TNotebook.Tab', background=[('selected','#1a4165'),('active','#15314f')], foreground=[('selected','#ffffff')])
        s.configure('TEntry', padding=7, fieldbackground='#071322', foreground='#eef6ff')
        s.configure('TCombobox', padding=6, fieldbackground='#071322', foreground='#eef6ff')

    def _build_ui(self):
        header=ttk.Frame(self.root,padding=(24,20)); header.pack(fill='x')
        ttk.Label(header,text='CORE NEXUS',style='Title.TLabel').pack(side='left')
        ttk.Label(header,text='CONTROL CENTER   /   LAN + RENDER RELAY',style='Sub.TLabel').pack(side='left',padx=20,pady=(11,0))
        self.status=ttk.Label(header,text=f'SERVER ONLINE  |  TCP {PORT}  |  DISCOVERY {DISCOVERY_PORT}',foreground='#7be0ad'); self.status.pack(side='right',pady=10)
        # Neue Menüstruktur: feste linke Navigation statt einzelner Registerkarten.
        workspace=ttk.Frame(self.root); workspace.pack(fill='both',expand=True,padx=18,pady=(0,18))
        self.sidebar=ttk.Frame(workspace,padding=(10,12),style='Card.TFrame'); self.sidebar.pack(side='left',fill='y',padx=(0,14))
        ttk.Label(self.sidebar,text='NAVIGATION',style='Sub.TLabel').pack(anchor='w',padx=8,pady=(4,12))
        self.content_frame=ttk.Frame(workspace); self.content_frame.pack(side='left',fill='both',expand=True)
        self.overview_tab=ttk.Frame(self.content_frame,padding=16); self.device_tab=ttk.Frame(self.content_frame,padding=12); self.device_info_tab=ttk.Frame(self.content_frame,padding=16); self.remote_tab=ttk.Frame(self.content_frame,padding=16); self.sync_tab=ttk.Frame(self.content_frame,padding=16); self.account_tab=ttk.Frame(self.content_frame,padding=12); self.log_tab=ttk.Frame(self.content_frame,padding=12); self.settings_tab=ttk.Frame(self.content_frame,padding=16)
        self.menu_frames={'Übersicht':self.overview_tab,'Geräte':self.device_tab,'Geräteinformationen':self.device_info_tab,'Fernsteuerung':self.remote_tab,'Server-Sync':self.sync_tab,'Konten & Rechte':self.account_tab,'Aktivitätsprotokoll':self.log_tab,'System & Wartung':self.settings_tab}
        self.menu_buttons={}
        for menu_name in self.menu_frames:
            btn=ttk.Button(self.sidebar,text=menu_name,command=lambda name=menu_name:self.show_menu(name))
            btn.pack(fill='x',pady=3,ipady=5)
            self.menu_buttons[menu_name]=btn
        self.active_menu=None
        self._build_overview()
        self._build_device_info_menu()
        self._build_sync_menu()
        who = (self.current_account or {}).get('username')
        ttk.Label(header, text=f'ANGEMELDET: {who}', style='Sub.TLabel').pack(side='right', padx=12, pady=10)
        ttk.Button(header, text='Abmelden', command=self._logout_to_guest).pack(side='right', padx=6, pady=6)
        # Übersicht + Suche für eine schnellere Geräteverwaltung.
        summary=ttk.Frame(self.device_tab); summary.pack(fill='x',pady=(0,8))
        self.device_summary=ttk.Label(summary,text='Geräte: 0  |  Online: 0  |  Freigegeben: 0  |  Zustimmung fehlt: 0',style='Sub.TLabel')
        self.device_summary.pack(side='left')
        searchbar=ttk.Frame(self.device_tab); searchbar.pack(fill='x',pady=(0,8))
        ttk.Label(searchbar,text='Suchen:').pack(side='left',padx=(0,6))
        self.device_search=tk.StringVar()
        search_entry=ttk.Entry(searchbar,textvariable=self.device_search,width=34)
        search_entry.pack(side='left',fill='x',expand=True)
        self.device_search.trace_add('write',lambda *_: self.refresh_devices())
        ttk.Button(searchbar,text='Suche leeren',command=lambda:self.device_search.set('')).pack(side='left',padx=7)
        ttk.Label(searchbar,text='Status:').pack(side='left',padx=(10,4))
        self.device_filter=tk.StringVar(value='Alle')
        filter_box=ttk.Combobox(searchbar,textvariable=self.device_filter,values=('Alle','Online','Offline','Freigabe ausstehend','Freigegeben'),state='readonly',width=22)
        filter_box.pack(side='left'); filter_box.bind('<<ComboboxSelected>>',lambda _e:self.refresh_devices())
        toolbar=ttk.Frame(self.device_tab); toolbar.pack(fill='x',pady=(0,10))
        ttk.Button(toolbar,text='Aktualisieren',command=self.refresh_devices).pack(side='left',padx=(0,5))
        ttk.Button(toolbar,text='Gerät freigeben',command=self.approve_device).pack(side='left',padx=5)
        ttk.Button(toolbar,text='Freigabe widerrufen',command=self.revoke_device).pack(side='left',padx=5)
        ttk.Button(toolbar,text='Gerätedetails bearbeiten',command=self.edit_device_details).pack(side='left',padx=5)
        ttk.Button(toolbar,text='Offline-Gerät entfernen',command=self.delete_device).pack(side='left',padx=5)
        ttk.Button(toolbar,text='Fernsteuerung öffnen',command=self.open_remote).pack(side='left',padx=5)
        ttk.Button(toolbar,text='Fernsteuerung beenden',command=self.stop_remote).pack(side='left',padx=5)
        ttk.Button(toolbar,text='Agentensperre aufheben',command=self.reset_agent_lock).pack(side='right',padx=(5,0))
        ttk.Button(toolbar,text='Alle Agenten schließen',command=self.close_all_agents).pack(side='right')
        # Checkbox-Auswahl links neben jedem Gerät; normale Zeilenauswahl bleibt für Einzelaktionen erhalten.
        selectionbar=ttk.Frame(self.device_tab); selectionbar.pack(fill='x',pady=(0,8))
        ttk.Button(selectionbar,text='Alle angezeigten auswählen',command=self.select_all_visible_devices).pack(side='left',padx=(0,5))
        ttk.Button(selectionbar,text='Auswahl aufheben',command=self.clear_device_checks).pack(side='left',padx=5)
        ttk.Button(selectionbar,text='Auswahl freigeben',command=self.approve_selected_devices).pack(side='left',padx=5)
        ttk.Button(selectionbar,text='Auswahl widerrufen',command=self.revoke_selected_devices).pack(side='left',padx=5)
        ttk.Button(selectionbar,text='Offline-Auswahl entfernen',command=self.delete_selected_offline_devices).pack(side='left',padx=5)
        ttk.Button(selectionbar,text='Auswahl exportieren',command=self.export_selected_devices).pack(side='left',padx=5)
        ttk.Button(selectionbar,text='IDs kopieren',command=self.copy_selected_device_ids).pack(side='left',padx=5)
        cols=('name','group','ip','connection','approved','consent','last_seen','os'); self.device_tree=ttk.Treeview(self.device_tab,columns=cols,show='tree headings',selectmode='browse')
        self.device_tree.heading('#0',text='✓'); self.device_tree.column('#0',width=42,minwidth=42,stretch=False,anchor='center')
        for c,t,w in [('name','Gerät',145),('group','Gruppe',105),('ip','IP-Adresse',115),('connection','Verbindung',90),('approved','Serverfreigabe',115),('consent','Lokale Zustimmung',135),('last_seen','Zuletzt gesehen',155),('os','Betriebssystem',145)]: self.device_tree.heading(c,text=t); self.device_tree.column(c,width=w,anchor='w')
        self.device_tree.pack(fill='both',expand=True)
        self.device_tree.bind('<Double-1>',lambda _e:self.edit_device_details())
        self.device_tree.bind('<Button-1>',self._device_checkbox_click,add='+')
        ttk.Label(self.device_tab,text='Tipp: Doppelklicke ein Gerät, um Name und Notizen zu bearbeiten. Freigabe benötigt lokale Zustimmung UND Serverfreigabe.',style='Sub.TLabel').pack(anchor='w',pady=(9,0))
        accbar=ttk.Frame(self.account_tab); accbar.pack(fill='x',pady=(0,10))
        ttk.Button(accbar,text='Konto erstellen',command=self.create_account).pack(side='left',padx=(0,5))
        ttk.Button(accbar,text='Rechte bearbeiten',command=self.edit_permissions).pack(side='left',padx=5)
        ttk.Button(accbar,text='Geräte zuweisen',command=self.assign_devices_to_account).pack(side='left',padx=5)
        ttk.Button(accbar,text='Passwort zurücksetzen',command=self.reset_account_password).pack(side='left',padx=5)
        ttk.Button(accbar,text='Konto aktivieren/deaktivieren',command=self.toggle_account_active).pack(side='left',padx=5)
        ttk.Button(accbar,text='Aktualisieren',command=self.refresh_accounts).pack(side='right')
        self.account_tree=ttk.Treeview(self.account_tab,columns=('username','role','permissions','active'),show='headings')
        for c,t,w in [('username','Benutzername',190),('role','Rolle',100),('permissions','Berechtigungen',550),('active','Status',100)]: self.account_tree.heading(c,text=t); self.account_tree.column(c,width=w,anchor='w')
        self.account_tree.pack(fill='both',expand=True)
        ttk.Label(self.account_tab,text='Owner-Rechte sind unveränderlich. Rechte werden serverseitig geprüft.',style='Sub.TLabel').pack(anchor='w',pady=(9,0))
        logbar=ttk.Frame(self.log_tab); logbar.pack(fill='x',pady=(0,10))
        ttk.Label(logbar,text='Letzte 500 Ereignisse – sicherheitsrelevante Aktionen werden protokolliert',style='Sub.TLabel').pack(side='left')
        ttk.Button(logbar,text='CSV exportieren',command=self.export_logs).pack(side='right',padx=(6,0))
        ttk.Button(logbar,text='Aktualisieren',command=self.refresh_logs).pack(side='right')
        self.log_tree=ttk.Treeview(self.log_tab,columns=('at','actor','action','detail'),show='headings')
        for c,t,w in [('at','Zeit',180),('actor','Konto / Gerät',150),('action','Aktion',180),('detail','Details',500)]: self.log_tree.heading(c,text=t); self.log_tree.column(c,width=w,anchor='w')
        self.log_tree.pack(fill='both',expand=True)
        if not self.has_permission('view_system_info'):
            self.menu_buttons['Geräteinformationen'].configure(state='disabled')
        if not self.has_permission('manage_accounts'):
            self.menu_buttons['Konten & Rechte'].configure(state='disabled')
        if not self.has_permission('view_logs'):
            self.menu_buttons['Aktivitätsprotokoll'].configure(state='disabled')
        self._build_remote_menu()
        self._build_system_tab()
        self.show_menu('Übersicht')
        self.refresh_devices(); self.refresh_device_info_menu(); self.refresh_accounts(); self.refresh_logs(); self.refresh_overview()
        self.root.after(3000,self._periodic_refresh)

    def show_menu(self, name):
        """Wechselt zwischen den Hauptmenüs, ohne die jeweilige Ansicht neu aufzubauen."""
        frame=self.menu_frames.get(name)
        if frame is None:
            return
        if name == 'Geräteinformationen' and not self.has_permission('view_system_info'):
            messagebox.showwarning('Keine Berechtigung','Du darfst Geräteinformationen nicht ansehen.',parent=self.root)
            return
        if name == 'Konten & Rechte' and not self.has_permission('manage_accounts'):
            messagebox.showwarning('Keine Berechtigung','Du darfst Konten und Rechte nicht verwalten.',parent=self.root)
            return
        if name == 'Aktivitätsprotokoll' and not self.has_permission('view_logs'):
            messagebox.showwarning('Keine Berechtigung','Du darfst das Aktivitätsprotokoll nicht ansehen.',parent=self.root)
            return
        for item in self.menu_frames.values():
            item.pack_forget()
        frame.pack(fill='both',expand=True)
        self.active_menu=name
        for menu_name, button in self.menu_buttons.items():
            button.state(['pressed'] if menu_name == name else ['!pressed'])

    def _build_device_info_menu(self):
        ttk.Label(self.device_info_tab, text='Geräteinformationen', style='Title.TLabel').pack(anchor='w')
        ttk.Label(self.device_info_tab, text='Wähle ein registriertes Gerät aus, um dessen gespeicherte Informationen und Verbindungsstatus zu sehen.', style='Sub.TLabel', wraplength=760).pack(anchor='w', pady=(3, 16))
        selectbar = ttk.Frame(self.device_info_tab, style='Card.TFrame', padding=12)
        selectbar.pack(fill='x', pady=(0, 12))
        ttk.Label(selectbar, text='Gerät:').pack(side='left', padx=(0, 8))
        self.device_info_choice = tk.StringVar()
        self.device_info_combo = ttk.Combobox(selectbar, textvariable=self.device_info_choice, state='readonly', width=48)
        self.device_info_combo.pack(side='left', fill='x', expand=True, padx=(0, 8))
        self.device_info_combo.bind('<<ComboboxSelected>>', lambda _e: self.refresh_device_info_menu())
        ttk.Button(selectbar, text='Aktualisieren', command=self.refresh_device_info_menu).pack(side='left')
        panel = ttk.Frame(self.device_info_tab, style='Card.TFrame', padding=16)
        panel.pack(fill='both', expand=True)
        self.device_info_values = {}
        fields = [
            ('name', 'Gerätename'), ('id', 'Geräte-ID'), ('online', 'Verbindungsstatus'),
            ('ip', 'IP-Adresse (vom Server beobachtet)'), ('os', 'Betriebssystem / Plattform'),
            ('last_seen', 'Zuletzt gesehen'), ('approved', 'Serverfreigabe'),
            ('consent', 'Lokale Zustimmung'), ('boot_id', 'Startkennung'),
            ('notes', 'Interne Notizen'), ('mode', 'Tarn-/Hintergrundmodus')
        ]
        for key, label in fields:
            line = ttk.Frame(panel)
            line.pack(fill='x', pady=5)
            ttk.Label(line, text=label, style='Sub.TLabel', width=30).pack(side='left', anchor='nw')
            value = ttk.Label(line, text='Bitte ein Gerät auswählen.', wraplength=620, justify='left')
            value.pack(side='left', fill='x', expand=True, anchor='w')
            self.device_info_values[key] = value
        ttk.Label(self.device_info_tab, text='Hinweis: Diese Version des Agenten übermittelt keinen Tarn-/Hintergrundmodus-Status. Deshalb wird dieser Wert ausdrücklich als nicht verfügbar angezeigt, nicht als vermeintlich aktiv oder inaktiv.', style='Sub.TLabel', wraplength=780).pack(anchor='w', pady=(10, 0))

    def refresh_device_info_menu(self):
        if not hasattr(self, 'device_info_combo'):
            return
        with self.db_lock:
            rows = self.db.execute('SELECT * FROM devices ORDER BY name COLLATE NOCASE').fetchall()
        with self.client_lock:
            online_ids = set(self.clients)
        choices = [f"{r['name']}  [{r['id']}]" for r in rows]
        self.device_info_combo['values'] = choices
        selected = self.device_info_choice.get()
        selected_id = selected.rsplit('[', 1)[-1].rstrip(']') if '[' in selected else ''
        row = next((r for r in rows if str(r['id']) == selected_id), None)
        if row is None and rows:
            row = rows[0]
            self.device_info_choice.set(f"{row['name']}  [{row['id']}]")
        elif not rows:
            self.device_info_choice.set('')
        if row is None:
            values = {k: 'Keine Geräte registriert.' for k in self.device_info_values}
            values['mode'] = 'Nicht verfügbar – kein Agentenstatus vorhanden.'
        else:
            did = str(row['id'])
            values = {
                'name': row['name'] or '-', 'id': did,
                'online': 'Online' if did in online_ids else 'Offline',
                'ip': row['ip'] or 'Unbekannt', 'os': row['os'] or 'Unbekannt',
                'last_seen': row['last_seen'] or 'Unbekannt',
                'approved': 'Ja' if row['approved'] else 'Nein',
                'consent': 'Erteilt' if row['consent'] else 'Nicht erteilt / widerrufen',
                'boot_id': row['boot_id'] or 'Nicht gemeldet',
                'notes': row['notes'] or 'Keine Notizen',
                'mode': 'Nicht verfügbar – diese Agent-Version meldet keinen Tarn-/Hintergrundmodus-Status.'
            }
        for key, value in values.items():
            self.device_info_values[key].configure(text=str(value))

    def _build_remote_menu(self):
        ttk.Label(self.remote_tab,text='Fernsteuerung',style='Title.TLabel').pack(anchor='w')
        ttk.Label(self.remote_tab,text='Wähle im Menü „Geräte“ ein Gerät aus und starte hier die Sitzung.',style='Sub.TLabel',wraplength=650).pack(anchor='w',pady=(3,18))
        panel=ttk.Frame(self.remote_tab,padding=18,style='Card.TFrame'); panel.pack(fill='x',anchor='n')
        ttk.Label(panel,text='FERNZUGRIFF',font=('Segoe UI',12,'bold')).pack(anchor='w',pady=(0,8))
        ttk.Label(panel,text='Eine Sitzung kann jeweils für ein Gerät geöffnet werden. Die lokale Zustimmung des Agenten, die Serverfreigabe und die passenden Kontorechte bleiben erforderlich.',style='Sub.TLabel',wraplength=650).pack(anchor='w',pady=(0,14))
        actions=ttk.Frame(panel); actions.pack(anchor='w')
        ttk.Button(actions,text='Fernsteuerung öffnen',command=self.open_remote).pack(side='left',padx=(0,8))
        ttk.Button(actions,text='Sitzung beenden',command=self.stop_remote).pack(side='left')
        ttk.Button(self.remote_tab,text='Zur Geräteauswahl',command=lambda:self.show_menu('Geräte')).pack(anchor='w',pady=(14,0))

    def _build_overview(self):
        ttk.Label(self.overview_tab,text='Kontrollzentrum',style='Title.TLabel').pack(anchor='w')
        ttk.Label(self.overview_tab,text='Status, Gerätefreigaben und Serverwerkzeuge auf einen Blick.',style='Sub.TLabel').pack(anchor='w',pady=(2,16))
        cards=ttk.Frame(self.overview_tab); cards.pack(fill='x',pady=(0,16))
        self.overview_values={}
        for key,title in [('devices','Registrierte Geräte'),('online','Online'),('approved','Freigegeben'),('pending','Ausstehend')]:
            card=ttk.Frame(cards,padding=16,style='Card.TFrame'); card.pack(side='left',fill='both',expand=True,padx=(0,10))
            ttk.Label(card,text=title,style='Sub.TLabel').pack(anchor='w')
            value=ttk.Label(card,text='0',font=('Segoe UI',22,'bold'),foreground='#58baff'); value.pack(anchor='w',pady=(4,0)); self.overview_values[key]=value
        body=ttk.Frame(self.overview_tab); body.pack(fill='both',expand=True)
        left=ttk.Frame(body,padding=18,style='Card.TFrame'); left.pack(side='left',fill='both',expand=True,padx=(0,10))
        ttk.Label(left,text='Schnellaktionen',font=('Segoe UI',12,'bold')).pack(anchor='w',pady=(0,10))
        ttk.Button(left,text='Geräteverwaltung öffnen',command=lambda:self.show_menu('Geräte')).pack(fill='x',pady=3)
        ttk.Button(left,text='NOTFALLMODUS: Alle Sitzungen beenden',command=self.emergency_stop_all).pack(fill='x',pady=3)
        ttk.Button(left,text='Konten & Rechte öffnen',command=lambda:self.show_menu('Konten & Rechte')).pack(fill='x',pady=3)
        ttk.Button(left,text='Datenbank jetzt sichern',command=self.backup_database).pack(fill='x',pady=3)
        ttk.Button(left,text='Aktivitätsprotokoll als CSV exportieren',command=self.export_logs).pack(fill='x',pady=3)
        right=ttk.Frame(body,padding=18,style='Card.TFrame'); right.pack(side='left',fill='both',expand=True)
        ttk.Label(right,text='Serverstatus',style='Hero.TLabel').pack(anchor='w',pady=(0,10))
        self.overview_status=ttk.Label(right,text='Wird geprüft …',wraplength=380); self.overview_status.pack(anchor='w')
        ttk.Label(right,text=f'TCP-Port: {PORT}    •    Geräteerkennung: UDP {DISCOVERY_PORT}',style='Sub.TLabel').pack(anchor='w',pady=(10,4))
        self.relay_overview=ttk.Label(right,text='Render-Relay: wird geprüft …',style='Sub.TLabel',wraplength=440); self.relay_overview.pack(anchor='w',pady=(7,0))
        ttk.Label(right,text='Nur für vertrauenswürdige private LAN-Netzwerke. Keine Router-Portfreigaben einrichten.',style='Sub.TLabel',wraplength=390).pack(anchor='w')

    def _build_sync_menu(self):
        ttk.Label(self.sync_tab,text='Server-Sync',style='Title.TLabel').pack(anchor='w')
        ttk.Label(self.sync_tab,text='Gib einem anderen CORE-Nexus-Server zeitlich begrenzten, einmaligen Zugriff auf diesen Server. Die Freigabe gilt nur in diese Richtung.',style='Sub.TLabel',wraplength=760).pack(anchor='w',pady=(3,16))
        card=ttk.Frame(self.sync_tab,padding=16,style='Card.TFrame'); card.pack(fill='x',anchor='n')
        ttk.Label(card,text='Freigabe für diesen Server',font=('Segoe UI',12,'bold')).pack(anchor='w',pady=(0,8))
        ttk.Label(card,text='Der Code erlaubt dem einlösenden Adminserver die vorhandenen Serverfunktionen zu verwenden. Bestehende Gerätefreigaben, Rechte und lokale Zustimmungen bleiben aktiv. Der Code läuft nach 10 Minuten ab und ist nur einmal einlösbar.',style='Sub.TLabel',wraplength=740).pack(anchor='w',pady=(0,12))
        row=ttk.Frame(card); row.pack(fill='x')
        ttk.Button(row,text='Sync aktivieren / Code erzeugen',command=self.generate_sync_code).pack(side='left',padx=(0,8))
        ttk.Button(row,text='Offene Codes widerrufen',command=self.revoke_sync_codes).pack(side='left')
        self.sync_code_label=ttk.Label(card,text='Aktuell kein angezeigter Code.',font=('Consolas',12,'bold'),wraplength=740)
        self.sync_code_label.pack(anchor='w',pady=(14,6))
        ttk.Button(card,text='Code kopieren',command=self.copy_sync_code).pack(anchor='w')
        ttk.Label(self.sync_tab,text='Verbindung: Über Render muss der andere Adminserver dieselbe Relay-URL und denselben Relay-Token verwenden. Im LAN kann die IP-Adresse dieses Servers mit TCP-Port 47623 genutzt werden. Sync-Codes nicht öffentlich teilen.',style='Sub.TLabel',wraplength=760).pack(anchor='w',pady=(16,0))
        self._display_sync_code=''

    def _sync_room_id(self):
        try: return str(json.loads((ROOT/'relay_config.json').read_text(encoding='utf-8')).get('room_id','')).strip()
        except Exception: return ''

    def generate_sync_code(self):
        account=self.current_account or {}
        if not account.get('is_owner'):
            messagebox.showerror(APP,'Nur das Owner-Konto darf einen Server-Sync aktivieren.',parent=self.root); return
        code='CNX-'+secrets.token_hex(5).upper()
        expires=time.time()+600
        with self.db_lock:
            self.db.execute('DELETE FROM sync_codes')
            self.db.execute('INSERT INTO sync_codes(code_hash,expires_at,created_by) VALUES(?,?,?)',(hashlib.sha256(code.encode()).hexdigest(),expires,account.get('username','owner')))
            self.db.commit()
        self._display_sync_code=code
        room=self._sync_room_id()
        self.sync_code_label.configure(text=f'SYNC-CODE: {code}\nAblauf: 10 Minuten nach Erstellung\nRelay-Raum-ID: {room or "nicht konfiguriert – LAN-IP verwenden"}')
        self._log(account.get('username','owner'),'sync_code_created','Einmaliger Server-Sync-Code für 10 Minuten erstellt')
        messagebox.showinfo(APP,'Sync-Code erstellt. Teile ihn nur mit dem gewünschten Server-Administrator. Er kann einmalig innerhalb von 10 Minuten eingelöst werden.',parent=self.root)

    def copy_sync_code(self):
        if not self._display_sync_code:
            messagebox.showinfo(APP,'Erzeuge zuerst einen Sync-Code.',parent=self.root); return
        self.root.clipboard_clear(); self.root.clipboard_append(self._display_sync_code); self.root.update()
        messagebox.showinfo(APP,'Sync-Code wurde in die Zwischenablage kopiert.',parent=self.root)

    def revoke_sync_codes(self):
        if not (self.current_account or {}).get('is_owner'):
            messagebox.showerror(APP,'Nur das Owner-Konto darf Sync-Codes widerrufen.',parent=self.root); return
        with self.db_lock: self.db.execute('DELETE FROM sync_codes'); self.db.commit()
        self._display_sync_code=''; self.sync_code_label.configure(text='Alle offenen Sync-Codes wurden widerrufen.')
        self._log((self.current_account or {}).get('username','owner'),'sync_codes_revoked','Alle offenen Sync-Codes widerrufen')

    def _consume_sync_code(self, code):
        code=str(code or '').strip()
        if not code.startswith('CNX-') or len(code)>64: return False
        digest=hashlib.sha256(code.encode()).hexdigest()
        with self.db_lock:
            row=self.db.execute('SELECT expires_at FROM sync_codes WHERE code_hash=?',(digest,)).fetchone()
            if not row or float(row['expires_at']) < time.time():
                self.db.execute('DELETE FROM sync_codes WHERE code_hash=?',(digest,)); self.db.commit(); return False
            self.db.execute('DELETE FROM sync_codes WHERE code_hash=?',(digest,)); self.db.commit()
            return True

    def _build_system_tab(self):
        ttk.Label(self.settings_tab,text='System & Wartung',style='Title.TLabel').pack(anchor='w')
        ttk.Label(self.settings_tab,text='Lokale Serverinformationen, Sicherungen und Diagnose.',style='Sub.TLabel').pack(anchor='w',pady=(2,16))
        info=ttk.Frame(self.settings_tab,padding=14,relief='ridge'); info.pack(fill='x',pady=(0,12))
        for label,value in [('Anwendung',APP),('Netzwerkmodus','LAN + Render-Relay-Fallback'),('TCP-Port',str(PORT)),('UDP-Erkennung',str(DISCOVERY_PORT)),('Datenbank',str(DB)),('Aktuelles Konto',(self.current_account or {}).get('username','-'))]:
            row=ttk.Frame(info); row.pack(fill='x',pady=3)
            ttk.Label(row,text=label,style='Sub.TLabel',width=20).pack(side='left')
            ttk.Label(row,text=value,wraplength=650).pack(side='left',fill='x',expand=True)
        actions=ttk.Frame(self.settings_tab); actions.pack(fill='x')
        ttk.Button(actions,text='Datenbank sichern',command=self.backup_database).pack(side='left',padx=(0,6))
        ttk.Button(actions,text='Datenordner öffnen',command=self.open_data_folder).pack(side='left',padx=6)
        ttk.Button(actions,text='Status aktualisieren',command=lambda:(self.refresh_devices(),self.refresh_overview())).pack(side='left',padx=6)
        ttk.Label(self.settings_tab,text='Sicherungen werden im Ordner Server/backups abgelegt. Die laufende Datenbank wird über die SQLite-Backup-API kopiert.',style='Sub.TLabel',wraplength=780).pack(anchor='w',pady=(14,0))

    def refresh_overview(self):
        if not hasattr(self,'overview_values'): return
        with self.db_lock: rows=self.db.execute('SELECT approved,consent FROM devices').fetchall()
        with self.client_lock: online=len(self.clients)
        approved=sum(1 for r in rows if r['approved'] and r['consent'])
        pending=sum(1 for r in rows if not (r['approved'] and r['consent']))
        for key,value in [('devices',len(rows)),('online',online),('approved',approved),('pending',pending)]: self.overview_values[key].configure(text=str(value))
        if hasattr(self,'overview_status'):
            self.overview_status.configure(text=f'Serverprozess aktiv. {online} Gerät(e) verbunden; {approved} Gerät(e) vollständig freigegeben. Letzte Aktualisierung: {datetime.now().strftime("%H:%M:%S")}')
            if hasattr(self, 'relay_overview'):
                with self.relay_ws_lock:
                    relay_up = self.relay_ws is not None
                enabled = bool(self.relay_config.get('enabled'))
                self.relay_overview.configure(text=('Render-Relay: VERBUNDEN' if relay_up else ('Render-Relay: aktiviert, wartet auf Verbindung' if enabled else 'Render-Relay: deaktiviert – LAN läuft unabhängig')), foreground=('#47e0a0' if relay_up else '#ffca70' if enabled else '#91a7c4'))

    def _periodic_refresh(self):
        if not self.running: return
        try:
            # refresh_devices also refreshes the device-information selector.
            self.refresh_devices(); self.refresh_overview()
        except Exception as exc:
            self._log('system','periodic_refresh_error',str(exc)[:300])
        self.root.after(5000,self._periodic_refresh)

    def backup_database(self):
        try:
            folder=ROOT/'backups'; folder.mkdir(parents=True,exist_ok=True)
            stamp=datetime.now().strftime('%Y%m%d_%H%M%S')
            target=folder/f'core_nexus_{stamp}.sqlite3'
            with self.db_lock:
                backup=sqlite3.connect(target)
                try: self.db.backup(backup)
                finally: backup.close()
            self._log((self.current_account or {}).get('username','unknown'),'database_backup_created',str(target))
            messagebox.showinfo(APP,f'Datenbank erfolgreich gesichert:\n\n{target}',parent=self.root)
        except Exception as exc:
            messagebox.showerror(APP,f'Datenbanksicherung fehlgeschlagen:\n{exc}',parent=self.root)

    def open_data_folder(self):
        try:
            if os.name=='nt': os.startfile(str(DATA))
            elif __import__('sys').platform == 'darwin': __import__('subprocess').Popen(['open', str(DATA)])
            else: __import__('subprocess').Popen(['xdg-open', str(DATA)])
        except Exception as exc: messagebox.showerror(APP,f'Datenordner konnte nicht geöffnet werden:\n{exc}',parent=self.root)

    def export_logs(self):
        if not self.require_permission('view_logs'): return
        from tkinter import filedialog
        default=f'core_nexus_logs_{datetime.now().strftime("%Y%m%d_%H%M%S")}.csv'
        path=filedialog.asksaveasfilename(parent=self.root,title='Aktivitätsprotokoll exportieren',defaultextension='.csv',initialfile=default,filetypes=[('CSV-Datei','*.csv')])
        if not path: return
        try:
            with self.db_lock: rows=self.db.execute('SELECT at,actor,action,detail FROM logs ORDER BY id DESC LIMIT 5000').fetchall()
            with open(path,'w',newline='',encoding='utf-8-sig') as handle:
                writer=csv.writer(handle,delimiter=';'); writer.writerow(['Zeit','Konto/Gerät','Aktion','Details'])
                for row in rows: writer.writerow([row['at'],row['actor'] or '',row['action'],row['detail'] or ''])
            messagebox.showinfo(APP,f'{len(rows)} Protokolleinträge exportiert.\n\n{path}',parent=self.root)
        except Exception as exc: messagebox.showerror(APP,f'Export fehlgeschlagen:\n{exc}',parent=self.root)

    def _log(self, actor, action, detail=''):
        with self.db_lock:
            self.db.execute('INSERT INTO logs(actor,action,detail) VALUES(?,?,?)',(actor,action,detail)); self.db.commit()
        self.ui_events.put(('refresh_logs',None))

    def _accept_loop(self):
        while self.running:
            try: conn, addr = self.tcp.accept()
            except socket.timeout: continue
            except OSError: break
            threading.Thread(target=self._client_loop,args=(conn,addr),daemon=True).start()

    def _client_loop(self, conn, addr):
        device_id=None
        try:
            conn.settimeout(15); file=conn.makefile('rwb')
            while self.running:
                line=file.readline()
                if not line: break
                if len(line)>8_000_000: break
                try: msg=json.loads(line.decode('utf-8'))
                except Exception: self._send(file,{'ok':False,'error':'invalid_json'}); continue
                typ=msg.get('type')
                if typ == 'hello' and msg.get('client_role') in ('admin', 'agent_user'):
                    # Controller sockets stay open while the user is viewing the device list.
                    # Their own protocol has explicit ping messages, so no short socket timeout is needed.
                    try: conn.settimeout(None)
                    except OSError: pass
                    self._admin_client_loop(conn, addr, file, msg)
                    return
                if typ=='hello':
                    device_id=str(msg.get('device_id',''))[:80]
                    if not device_id: self._send(file,{'ok':False,'error':'missing_device_id'}); break
                    with self.db_lock:
                        row=self.db.execute('SELECT * FROM devices WHERE id=?',(device_id,)).fetchone()
                        if row:
                            self.db.execute('UPDATE devices SET name=?,ip=?,last_seen=CURRENT_TIMESTAMP,os=?,boot_id=? WHERE id=?',(str(msg.get('name','PC'))[:120],addr[0],str(msg.get('os',''))[:120],str(msg.get('boot_id',''))[:100],device_id))
                        else:
                            self.db.execute('INSERT INTO devices(id,name,ip,approved,consent,last_seen,os,boot_id) VALUES(?,?,?,0,0,CURRENT_TIMESTAMP,?,?)',(device_id,str(msg.get('name','PC'))[:120],addr[0],str(msg.get('os',''))[:120],str(msg.get('boot_id',''))[:100]))
                        self.db.commit()
                    with self.client_lock: self.clients[device_id]=conn
                    self._send(file,{'ok':True,'approved':bool(row and row['approved'] and row['consent']),'server_name':APP})
                    self.ui_events.put(('refresh_devices',None))
                elif typ=='consent':
                    if not device_id: break
                    with self.db_lock: self.db.execute('UPDATE devices SET consent=? WHERE id=?',(1 if msg.get('accepted') else 0,device_id)); self.db.commit()
                    self._log('device:'+device_id,'local_consent',str(bool(msg.get('accepted'))))
                    
                    with self.db_lock:
                        current=self.db.execute('SELECT approved,consent FROM devices WHERE id=?',(device_id,)).fetchone()
                    self._send(file,{'ok':True,'approved':bool(current and current['approved'] and current['consent']),'server_approved':bool(current and current['approved']),'consent':bool(current and current['consent'])})
                elif typ=='heartbeat':
                    if not device_id: break
                    if msg.get('frame') and device_id==self.remote_device:
                        try: self.remote_frames[device_id]=base64.b64decode(msg['frame'])
                        except Exception: pass
                    with self.admin_remote_lock:
                        admin_session = self.admin_remote_session if device_id == self.admin_remote_device else None
                    if msg.get('frame') and admin_session is not None:
                        self._admin_send(admin_session, {'type':'frame','device_id':device_id,'frame':msg.get('frame')})
                    with self.db_lock:
                        row=self.db.execute('SELECT approved,consent FROM devices WHERE id=?',(device_id,)).fetchone()
                        lock=self.db.execute("SELECT value FROM settings WHERE key='close_agents' ").fetchone()
                    approved=bool(row and row['approved'] and row['consent'])
                    with self.admin_remote_lock:
                        admin_remote = bool(approved and device_id == self.admin_remote_device and self.admin_remote_session is not None)
                        admin_commands = self.admin_remote_commands.pop(device_id, []) if admin_remote else []
                    remote=bool(approved and ((device_id==self.remote_device and self.remote_window is not None) or admin_remote))
                    commands=(self.remote_commands.pop(device_id,[]) if device_id==self.remote_device and self.remote_window is not None else []) + admin_commands
                    self._send(file,{'ok':True,'approved':approved,'server_approved':bool(row and row['approved']),'consent':bool(row and row['consent']),'close_agent':bool(lock and lock['value']=='1'),'remote_active':remote,'commands':commands})
                elif typ=='system_info':
                    if device_id: self.ui_events.put(('device_info',(device_id,msg.get('info',{}))))
                    self._send(file,{'ok':True})
                elif typ=='agent_closed':
                    self._send(file,{'ok':True}); break
                else: self._send(file,{'ok':False,'error':'unsupported_message'})
        except (OSError,ValueError,KeyError): pass
        finally:
            if device_id:
                with self.client_lock:
                    if self.clients.get(device_id) is conn: self.clients.pop(device_id,None)
                self.ui_events.put(('refresh_devices',None))
            elif isinstance(conn, RelayVirtualConn):
                if self.relay_connections.get(conn.device_id) is conn:
                    self.relay_connections.pop(conn.device_id, None)
            try: conn.close()
            except OSError: pass

    @staticmethod
    def _send(file, obj):
        file.write((json.dumps(obj,separators=(',',':'))+'\n').encode('utf-8')); file.flush()

    def _discovery_loop(self):
        sock=socket.socket(socket.AF_INET,socket.SOCK_DGRAM); sock.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1)
        try: sock.bind(('',DISCOVERY_PORT)); sock.settimeout(1)
        except OSError: return
        while self.running:
            try: data,addr=sock.recvfrom(2048)
            except socket.timeout: continue
            except OSError: break
            if data==b'CORE_NEXUS_DISCOVER_V1':
                try: sock.sendto(json.dumps({'app':APP,'host':self._lan_ip(addr[0]),'port':PORT,'discovery_port':DISCOVERY_PORT}).encode(),addr)
                except OSError: pass
        sock.close()

    @staticmethod
    def _lan_ip(peer):
        s=socket.socket(socket.AF_INET,socket.SOCK_DGRAM)
        try: s.connect((peer,9)); return s.getsockname()[0]
        except OSError: return '127.0.0.1'

    def _selected_device(self):
        sel=self.device_tree.selection()
        if not sel:
            messagebox.showwarning(APP,'Wähle zuerst ein Gerät aus.',parent=self.root)
            return None
        # Die Treeview-IID ist die echte Geräte-ID. Die erste sichtbare Spalte
        # enthält nur den Anzeigenamen und darf niemals als ID verwendet werden.
        return str(sel[0])

    def edit_device_details(self):
        if not self.require_permission('manage_grants'): return
        did=self._selected_device()
        if not did: return
        with self.db_lock:
            row=self.db.execute('SELECT * FROM devices WHERE id=?',(did,)).fetchone()
        if not row:
            messagebox.showerror(APP,'Gerät wurde nicht gefunden.',parent=self.root); return
        dlg=tk.Toplevel(self.root); dlg.title('Gerätedetails bearbeiten'); dlg.transient(self.root); dlg.grab_set(); dlg.configure(bg='#0d1728'); dlg.resizable(False,False)
        body=ttk.Frame(dlg,padding=16); body.pack(fill='both',expand=True)
        ttk.Label(body,text='Gerätename').pack(anchor='w')
        name_var=tk.StringVar(value=row['name'])
        name_entry=ttk.Entry(body,textvariable=name_var,width=48); name_entry.pack(fill='x',pady=(4,12))
        ttk.Label(body,text='Gerätegruppe').pack(anchor='w')
        group_var=tk.StringVar(value=row['device_group'] or 'Standard')
        group_entry=ttk.Entry(body,textvariable=group_var,width=48); group_entry.pack(fill='x',pady=(4,12))
        ttk.Label(body,text='Interne Notizen (optional)').pack(anchor='w')
        notes=tk.Text(body,width=52,height=5,wrap='word',bg='#0b1423',fg='#eaf2ff',insertbackground='#ffffff',relief='flat')
        notes.pack(fill='both',expand=True,pady=(4,12)); notes.insert('1.0',row['notes'] or '')
        ttk.Label(body,text=f'Geräte-ID: {did}',style='Sub.TLabel').pack(anchor='w',pady=(0,10))
        def save():
            name=name_var.get().strip(); note=notes.get('1.0','end').strip()
            if not name:
                messagebox.showwarning(APP,'Der Gerätename darf nicht leer sein.',parent=dlg); return
            with self.db_lock:
                self.db.execute('UPDATE devices SET name=?,notes=?,device_group=? WHERE id=?',(name[:120],note[:2000],(group_var.get().strip() or 'Standard')[:80],did)); self.db.commit()
            self._log((self.current_account or {}).get('username','unknown'),'device_details_updated',f'{did}: {name}; Gruppe={group_var.get().strip() or 'Standard'}')
            dlg.destroy(); self.refresh_devices()
        buttons=ttk.Frame(body); buttons.pack(fill='x')
        ttk.Button(buttons,text='Speichern',command=save).pack(side='right',padx=(6,0)); ttk.Button(buttons,text='Abbrechen',command=dlg.destroy).pack(side='right')
        name_entry.focus_set()

    def delete_device(self):
        if not self.require_permission('manage_grants'): return
        did=self._selected_device()
        if not did: return
        with self.client_lock: online=did in self.clients
        if online:
            messagebox.showwarning(APP,'Dieses Gerät ist noch online. Beende zuerst den Agenten auf dem Client-PC.',parent=self.root); return
        with self.db_lock:
            row=self.db.execute('SELECT name FROM devices WHERE id=?',(did,)).fetchone()
        if not row: return
        if not messagebox.askyesno(APP,f'Das Offline-Gerät „{row["name"]}“ dauerhaft aus der Geräteliste entfernen? Bei einer späteren Verbindung wird es neu registriert und benötigt erneut eine Freigabe.',parent=self.root): return
        with self.db_lock:
            self.db.execute('DELETE FROM grants WHERE device_id=?',(did,))
            self.db.execute('DELETE FROM devices WHERE id=?',(did,)); self.db.commit()
        self._log((self.current_account or {}).get('username','unknown'),'device_removed',f'{did} ({row["name"]})')
        self.refresh_devices()

    def approve_device(self):
        if not self.require_permission('register_devices'): return
        did=self._selected_device()
        if not did: return
        with self.db_lock: self.db.execute('UPDATE devices SET approved=1 WHERE id=?',(did,)); self.db.commit()
        self._log((self.current_account or {}).get('username','unknown'),'device_approved',did); self.refresh_devices(); self.refresh_overview()

    def revoke_device(self):
        if not self.require_permission('manage_grants'): return
        did=self._selected_device()
        if not did: return
        if not messagebox.askyesno(APP,'Freigabe für dieses Gerät wirklich widerrufen?',parent=self.root): return
        with self.db_lock: self.db.execute('UPDATE devices SET approved=0 WHERE id=?',(did,)); self.db.commit()
        self._log((self.current_account or {}).get('username','unknown'),'device_revoked',did); self.refresh_devices(); self.refresh_overview()

    def emergency_stop_all(self):
        """End all active remote-control sessions without shutting down agents."""
        if not self.is_owner_context() and not self.has_permission('close_agents'):
            messagebox.showwarning(APP, 'Der Notfallmodus erfordert Owner- oder Notfallberechtigung.', parent=self.root); return
        if not messagebox.askyesno(APP, 'NOTFALLMODUS aktivieren? Alle aktiven Fernsteuerungssitzungen werden beendet. Agenten bleiben installiert und laufen weiter.', parent=self.root, icon='warning'):
            return
        stopped=[]
        with self.admin_remote_lock:
            if self.admin_remote_session is not None:
                sess=self.admin_remote_session; did=self.admin_remote_device
                self._admin_send(sess, {'type':'remote_forced_stop','reason':'emergency_stop'})
                if sess: sess['remote_device']=None
                if did: stopped.append(did)
                self.admin_remote_session=None; self.admin_remote_device=None; self.admin_remote_commands.clear()
        if self.remote_device:
            stopped.append(self.remote_device)
            self.remote_commands.clear(); self.remote_device=None
            self.remote_photo=None; self._remote_rendered_data=None
            win=self.remote_window; self.remote_window=None; self.remote_image_label=None
            if win is not None:
                try: win.destroy()
                except tk.TclError: pass
        self._log((self.current_account or {}).get('username','owner'), 'emergency_stop_all_sessions', ','.join(stopped) or 'Keine aktive Sitzung')
        messagebox.showinfo(APP, f'Notfallmodus ausgeführt. Beendete Sitzungen: {len(set(stopped))}. Agenten wurden nicht deinstalliert oder geschlossen.', parent=self.root)

    def close_all_agents(self):
        if not self.require_permission('close_agents'): return
        if not messagebox.askyesno(APP,'Alle erreichbaren Agentenprogramme schließen? Offline-Geräte erhalten den Status bei der nächsten Verbindung.',parent=self.root): return
        with self.db_lock: self.db.execute("INSERT INTO settings(key,value) VALUES('close_agents','1') ON CONFLICT(key) DO UPDATE SET value='1'"); self.db.commit()
        with self.client_lock: ids=list(self.clients)
        self._log('dashboard','close_all_agents',f'{len(ids)} verbundene Geräte benachrichtigt')
        messagebox.showinfo(APP,'Schließbefehl gesendet. Der Status bleibt gespeichert, bis der Server-Owner ihn zurücksetzt.',parent=self.root)

    def reset_agent_lock(self):
        if not self.is_owner_context():
            messagebox.showwarning(APP, 'Nur das Owner-Konto darf die globale Agentensperre aufheben.', parent=self.root)
            return
        if not messagebox.askyesno(APP, 'Globale Agentensperre aufheben? Agenten dürfen sich danach wieder verbinden.', parent=self.root):
            return
        with self.db_lock:
            self.db.execute("INSERT INTO settings(key,value) VALUES('close_agents','0') ON CONFLICT(key) DO UPDATE SET value='0'")
            self.db.commit()
        self._log((self.current_account or {}).get('username','owner'), 'agent_lock_reset', 'Globale Agentensperre aufgehoben')
        messagebox.showinfo(APP, 'Agentensperre aufgehoben. Starte den Agenten auf dem Client-PC erneut.', parent=self.root)

    def open_remote(self):
        if not (self.has_permission('remote_view') and self.has_permission('remote_input')):
            messagebox.showwarning(APP, 'Für die Fernsteuerung fehlen Bildschirm- und Eingaberechte.', parent=self.root); return
        did=self._selected_device()
        if not did: return
        with self.db_lock:
            row=self.db.execute('SELECT approved,consent,name FROM devices WHERE id=?',(did,)).fetchone()
        if not row or not row['approved'] or not row['consent']:
            messagebox.showwarning(APP,'Das Gerät benötigt lokale Zustimmung und Serverfreigabe.',parent=self.root); return
        if self.remote_window is not None:
            self.stop_remote()
        # The local server dashboard has priority over agent-login controller sessions.
        with self.admin_remote_lock:
            old_session = self.admin_remote_session
            old_device = self.admin_remote_device
            if old_session is not None:
                self._admin_send(old_session, {'type': 'remote_forced_stop', 'reason': 'server_priority'})
                self.admin_remote_session = None
                self.admin_remote_device = None
                self.admin_remote_commands.clear()
                old_session['remote_device'] = None
                if old_device: self._log((old_session.get('account') or {}).get('username', 'adminserver'), 'remote_session_stopped_by_server', old_device)
        self.remote_device=did
        self._remote_rendered_data=None
        self._last_frame_seen_at=0.0; self._frame_interval_samples=[]
        self.remote_frame_dimensions.pop(did, None)
        win=tk.Toplevel(self.root); win.title('CORE Nexus | Fernsteuerung'); win.geometry('1000x650'); win.configure(bg='#080e1b')
        win.protocol('WM_DELETE_WINDOW',self.stop_remote); self.remote_window=win
        ttk.Label(win,text=f'FERNSTEUERUNG: {row["name"]}  •  Freigegebene Sitzung',style='Title.TLabel').pack(anchor='w',padx=12,pady=8)
        ttk.Label(win,text='Klicks und Tastatur werden an das freigegebene Gerät gesendet. Esc wird an das Ziel weitergegeben; Schließen beendet die Sitzung.',style='Sub.TLabel').pack(anchor='w',padx=12)
        self.remote_image_label=tk.Label(win,text='Warte auf ersten Bildschirmframe …',bg='#050914',fg='#eaf2ff')
        self.remote_image_label.pack(fill='both',expand=True,padx=10,pady=10)
        bar=ttk.Frame(win); bar.pack(fill='x',padx=10,pady=(0,10))
        ttk.Label(bar,text='Hinweis: System-Sicherheitsbildschirme werden nicht umgangen.',style='Sub.TLabel').pack(side='left')
        ttk.Button(bar,text='Datei senden',command=self.send_file_to_remote).pack(side='left',padx=6)
        ttk.Button(bar,text='Zwischenablage teilen',command=self.share_clipboard_to_remote).pack(side='left',padx=6)
        ttk.Button(bar,text='Nächster Monitor',command=self.next_remote_monitor).pack(side='left',padx=6)
        self.remote_quality_label=ttk.Label(bar,text='Verbindungsqualität: wird gemessen',style='Sub.TLabel'); self.remote_quality_label.pack(side='left',padx=8)
        self._last_frame_seen_at=0.0; self._frame_interval_samples=[]
        ttk.Button(bar,text='Sitzung beenden',command=self.stop_remote).pack(side='right')
        # Make the viewing surface focusable and bind keyboard events both on the
        # top-level window and the image widget. Tkinter does not always deliver
        # key events to the Toplevel when the pointer is over a child widget.
        self.remote_image_label.configure(takefocus=1, cursor='crosshair')
        self.remote_image_label.bind('<Motion>',self.remote_motion)
        self.remote_image_label.bind('<Button-1>',lambda e:self.remote_click(e,'left'))
        self.remote_image_label.bind('<Button-3>',lambda e:self.remote_click(e,'right'))
        self.remote_image_label.bind('<MouseWheel>',self.remote_scroll)
        self.remote_image_label.bind('<KeyPress>',self.remote_keydown)
        self.remote_image_label.bind('<KeyRelease>',self.remote_keyup)
        win.bind('<KeyPress>',self.remote_keydown); win.bind('<KeyRelease>',self.remote_keyup)
        win.after(250, lambda: (win.focus_force(), self.remote_image_label.focus_set() if self.remote_image_label else None))
        self._log('dashboard','remote_session_started',did); self._update_remote_frame()

    def next_remote_monitor(self):
        if not self.remote_device or self.remote_window is None: return
        self.queue_input({'kind':'monitor_next'})
        self._log((self.current_account or {}).get('username','dashboard'), 'remote_monitor_next_requested', self.remote_device)

    def share_clipboard_to_remote(self):
        if not self.remote_device or self.remote_window is None: return
        if not self.is_owner_context() and not self.has_permission('clipboard_share'):
            messagebox.showwarning(APP, 'Deinem Konto fehlt die Berechtigung zum Teilen der Zwischenablage.', parent=self.remote_window); return
        try: content=self.root.clipboard_get()
        except Exception:
            messagebox.showwarning(APP, 'Die lokale Zwischenablage enthält keinen lesbaren Text.', parent=self.remote_window); return
        if len(content)>20000:
            messagebox.showwarning(APP, 'Zum Schutz der Verbindung ist die Zwischenablage auf 20.000 Zeichen begrenzt.', parent=self.remote_window); return
        if not messagebox.askyesno(APP, f'{len(content)} Zeichen an das freigegebene Zielgerät übertragen?', parent=self.remote_window): return
        self.queue_input({'kind':'clipboard_text','text':content})
        self._log((self.current_account or {}).get('username','dashboard'), 'clipboard_shared_to_device', self.remote_device)

    def send_file_to_remote(self):
        if not self.remote_device or self.remote_window is None: return
        from tkinter import filedialog
        import os, base64
        path=filedialog.askopenfilename(parent=self.remote_window, title='Datei an Zielgerät senden')
        if not path: return
        try:
            size=os.path.getsize(path)
            if size>2*1024*1024:
                messagebox.showwarning(APP, 'Diese sichere Basisübertragung ist auf 2 MB pro Datei begrenzt. Größere Dateien bitte in kleinere Dateien aufteilen.', parent=self.remote_window); return
            with open(path,'rb') as f: data=f.read()
            name=os.path.basename(path).replace('\\','_').replace('/','_')[:180]
            if not self.is_owner_context() and not self.has_permission('file_transfer'):
                messagebox.showwarning(APP, 'Deinem Konto fehlt die Berechtigung für Dateiübertragungen.', parent=self.remote_window); return
            if not messagebox.askyesno(APP, f'Datei „{name}“ ({size} Bytes) an das Zielgerät übertragen? Sie wird dort im Ordner Downloads\\CORE-Nexus-Received abgelegt.', parent=self.remote_window): return
            encoded=base64.b64encode(data).decode('ascii')
            chunk_size=24000; transfer_id=str(uuid.uuid4())
            total=(len(encoded)+chunk_size-1)//chunk_size
            self.queue_input({'kind':'file_begin','transfer_id':transfer_id,'name':name,'chunks':total})
            for index in range(total): self.queue_input({'kind':'file_chunk','transfer_id':transfer_id,'index':index,'data':encoded[index*chunk_size:(index+1)*chunk_size]})
            self.queue_input({'kind':'file_end','transfer_id':transfer_id})
            self._log((self.current_account or {}).get('username','dashboard'), 'file_transfer_queued', f'{self.remote_device}: {name} ({size} Bytes)')
            messagebox.showinfo(APP, 'Dateiübertragung wurde eingereiht. Das Zielgerät muss online bleiben, bis die Übertragung abgeschlossen ist.', parent=self.remote_window)
        except Exception as exc: messagebox.showerror(APP, f'Datei konnte nicht vorbereitet werden: {exc}', parent=self.remote_window)

    def _image_coords(self,event):
        # Convert widget coordinates to the original encoded-frame coordinates.
        # The frame is first reduced on the agent and then may be reduced again
        # to fit the server preview. Use the *actual rendered size* for mapping.
        try:
            dims=self.remote_frame_dimensions.get(self.remote_device)
            shown=self.remote_display_dimensions.get(self.remote_device)
            if not dims or not shown: return (event.x,event.y)
            image_w,image_h=dims
            shown_w,shown_h=shown
            label_w=max(1,self.remote_image_label.winfo_width())
            label_h=max(1,self.remote_image_label.winfo_height())
            offset_x=(label_w-shown_w)/2
            offset_y=(label_h-shown_h)/2
            scale_x=shown_w/max(1,image_w)
            scale_y=shown_h/max(1,image_h)
            x=round((event.x-offset_x)/max(scale_x,0.0001))
            y=round((event.y-offset_y)/max(scale_y,0.0001))
            return (min(max(0,x),image_w-1),min(max(0,y),image_h-1))
        except Exception:
            return (event.x,event.y)

    def queue_input(self,cmd):
        if not self.remote_device or self.remote_window is None: return
        pending=self.remote_commands.setdefault(self.remote_device,[])
        # Mouse-motion events can arrive hundreds of times per second. Coalesce
        # pending moves so clicks and key events are delivered promptly.
        if cmd.get('kind') == 'move':
            for index in range(len(pending)-1, -1, -1):
                if pending[index].get('kind') == 'move':
                    pending[index]=cmd
                    return
        if len(pending) >= 300:
            pending[:] = [item for item in pending if item.get('kind') != 'move'][-250:]
        pending.append(cmd)

    def remote_motion(self,e):
        x,y=self._image_coords(e); self.queue_input({'kind':'move','x':x,'y':y})

    def remote_click(self,e,button):
        # Keep keyboard focus on the remote-view surface after a click.
        try:
            if self.remote_image_label is not None: self.remote_image_label.focus_set()
        except tk.TclError: pass
        x,y=self._image_coords(e); self.queue_input({'kind':'click','x':x,'y':y,'button':button})

    def remote_scroll(self,e):
        x,y=self._image_coords(e); self.queue_input({'kind':'scroll','x':x,'y':y,'dy':1 if e.delta>0 else -1})

    def remote_keydown(self,e):
        if self.remote_window is None: return
        names={'Return':'enter','Tab':'tab','Escape':'esc','BackSpace':'backspace','Delete':'delete','space':'space','Up':'up','Down':'down','Left':'left','Right':'right','Shift_L':'shift','Control_L':'ctrl','Alt_L':'alt','Super_L':'win'}
        key=names.get(e.keysym,e.keysym.lower() if e.keysym.lower().startswith('f') and e.keysym[1:].isdigit() else (e.char if e.char and e.char.isprintable() else ''))
        if key: self.queue_input({'kind':'key','key':key,'action':'down' if key in ('shift','ctrl','alt','win') else 'press'})

    def remote_keyup(self,e):
        names={'Shift_L':'shift','Control_L':'ctrl','Alt_L':'alt','Super_L':'win'}
        key=names.get(e.keysym)
        if key: self.queue_input({'kind':'key','key':key,'action':'up'})

    def _update_remote_frame(self):
        if self.remote_window is None: return
        data=self.remote_frames.get(self.remote_device)
        # Only decode and render a newly received frame, rather than converting
        # the same JPEG every UI tick.
        if data and data is not self._remote_rendered_data:
            now=time.monotonic()
            if self._last_frame_seen_at:
                self._frame_interval_samples.append(now-self._last_frame_seen_at)
                self._frame_interval_samples=self._frame_interval_samples[-12:]
                avg=sum(self._frame_interval_samples)/len(self._frame_interval_samples)
                quality='Gut' if avg<0.35 else ('Mittel' if avg<0.8 else 'Schwach')
                if hasattr(self,'remote_quality_label'):
                    try: self.remote_quality_label.configure(text=f'Bildrate: {1/max(avg,0.01):.1f} FPS · Qualität: {quality}')
                    except tk.TclError: pass
            self._last_frame_seen_at=now
            try:
                from PIL import Image, ImageTk
                import io
                im=Image.open(io.BytesIO(data))
                self.remote_frame_dimensions[self.remote_device]=im.size
                maxw=max(1,self.remote_image_label.winfo_width())
                maxh=max(1,self.remote_image_label.winfo_height())
                im.thumbnail((maxw,maxh))
                self.remote_display_dimensions[self.remote_device]=im.size
                self.remote_photo=ImageTk.PhotoImage(im)
                self.remote_image_label.configure(image=self.remote_photo,text='')
                self._remote_rendered_data=data
            except Exception as exc:
                self.remote_image_label.configure(text=f'Bild konnte nicht angezeigt werden: {exc}')
        self.remote_window.after(90,self._update_remote_frame)

    def stop_remote(self):
        if self.remote_device: self._log((self.current_account or {}).get('username', 'dashboard'), 'remote_session_stopped', self.remote_device)
        # The server's stop action is authoritative and also terminates a session
        # started from an Agent login or the separate adminserver.
        with self.admin_remote_lock:
            session = self.admin_remote_session
            did = self.admin_remote_device
            if session is not None:
                self._admin_send(session, {'type': 'remote_forced_stop', 'reason': 'server_stopped'})
                session['remote_device'] = None
            self.admin_remote_session = None
            self.admin_remote_device = None
            self.admin_remote_commands.clear()
            if did: self._log((session.get('account') or {}).get('username', 'adminserver') if session else 'server', 'remote_session_stopped_by_server', did)
        self.remote_device=None; self.remote_photo=None; self.remote_image_label=None; self._remote_rendered_data=None
        win=self.remote_window; self.remote_window=None
        if win is not None:
            try: win.destroy()
            except tk.TclError: pass

    def create_account(self):
        if not self.require_permission('manage_accounts'): return
        username=simpledialog.askstring('Konto erstellen','Benutzername:',parent=self.root)
        if not username: return
        password=simpledialog.askstring('Konto erstellen','Passwort (mindestens 4 Zeichen):',show='*',parent=self.root)
        if not password or len(password)<4: messagebox.showerror(APP,'Passwort muss mindestens 4 Zeichen lang sein.',parent=self.root); return
        choices=list(PERMISSIONS) if self.is_owner_context() else [k for k in PERMISSIONS if k in (self.current_account or {}).get('permissions', [])]
        dlg=tk.Toplevel(self.root); dlg.title('Berechtigungen auswählen'); dlg.configure(bg='#0d1728'); dlg.transient(self.root); dlg.grab_set()
        ttk.Label(dlg,text=f'Rechte für {username}').pack(anchor='w',padx=14,pady=10)
        vars_={}
        for key,label in PERMISSIONS.items():
            if key not in choices: continue
            v=tk.BooleanVar(value=key in ('view_devices','view_system_info')); vars_[key]=v; ttk.Checkbutton(dlg,text=label,variable=v).pack(anchor='w',padx=16,pady=2)
        result={'ok':False}
        def save(): result['ok']=True; dlg.destroy()
        ttk.Button(dlg,text='Konto anlegen',command=save).pack(pady=12); dlg.wait_window()
        if not result['ok']: return
        perms=[k for k,v in vars_.items() if v.get()]
        try:
            with self.db_lock: self.db.execute('INSERT INTO accounts(username,password_hash,is_owner,permissions) VALUES(?,?,0,?)',(username.strip(),password_hash(password),json.dumps(perms))); self.db.commit()
            self._log((self.current_account or {}).get('username','unknown'),'account_created',username.strip()); self.refresh_accounts()
        except sqlite3.IntegrityError: messagebox.showerror(APP,'Dieser Benutzername ist bereits vergeben.',parent=self.root)

    def assign_devices_to_account(self):
        """Assign only explicitly selected devices to the selected non-owner account."""
        if not self.require_permission('manage_accounts'):
            return
        if not self.is_owner_context() and not self.require_permission('manage_grants'):
            return
        sel = self.account_tree.selection()
        if not sel:
            messagebox.showwarning(APP, 'Wähle zuerst ein Konto aus.', parent=self.root)
            return
        account_id = int(sel[0])
        with self.db_lock:
            account = self.db.execute('SELECT id,username,is_owner FROM accounts WHERE id=?', (account_id,)).fetchone()
            devices = self.db.execute('SELECT id,name,ip,approved,consent FROM devices ORDER BY name COLLATE NOCASE').fetchall()
            current = {r['device_id'] for r in self.db.execute('SELECT device_id FROM grants WHERE account_id=?', (account_id,)).fetchall()}
        if not account:
            return
        if account['is_owner']:
            messagebox.showinfo(APP, 'Das Owner-Konto hat automatisch Zugriff auf alle freigegebenen Geräte.', parent=self.root)
            return
        dlg = tk.Toplevel(self.root)
        dlg.title(f'Gerätezuweisung – {account["username"]}')
        dlg.configure(bg='#0d1728'); dlg.transient(self.root); dlg.grab_set(); dlg.geometry('620x540')
        body = ttk.Frame(dlg, padding=14); body.pack(fill='both', expand=True)
        ttk.Label(body, text=f'Geräte, die „{account["username"]}“ steuern darf', style='Title.TLabel').pack(anchor='w', pady=(0,6))
        ttk.Label(body, text='Nur angehakte Geräte werden diesem Konto zugewiesen. Zusätzlich gelten Kontorechte, Serverfreigabe und lokale Zustimmung.', style='Sub.TLabel', wraplength=570).pack(anchor='w', pady=(0,10))
        canvas = tk.Canvas(body, bg='#0b1423', highlightthickness=0)
        scrollbar = ttk.Scrollbar(body, orient='vertical', command=canvas.yview)
        inner = ttk.Frame(canvas, padding=8)
        inner.bind('<Configure>', lambda _e: canvas.configure(scrollregion=canvas.bbox('all')))
        canvas.create_window((0,0), window=inner, anchor='nw')
        canvas.configure(yscrollcommand=scrollbar.set)
        canvas.pack(side='left', fill='both', expand=True); scrollbar.pack(side='right', fill='y')
        vars_ = {}
        for device in devices:
            did = str(device['id'])
            label = f"{device['name']}  |  {did[:14]}…"
            if not device['approved'] or not device['consent']:
                label += '  (derzeit nicht freigegeben)'
            var = tk.BooleanVar(value=did in current); vars_[did] = var
            ttk.Checkbutton(inner, text=label, variable=var).pack(anchor='w', pady=3)
        def save():
            selected = {did for did, var in vars_.items() if var.get()}
            with self.db_lock:
                self.db.execute('DELETE FROM grants WHERE account_id=?', (account_id,))
                self.db.executemany('INSERT INTO grants(device_id,account_id,permissions) VALUES(?,?,?)', [(did, account_id, '["control"]') for did in sorted(selected)])
                self.db.commit()
            actor = (self.current_account or {}).get('username', 'server')
            self._log(actor, 'account_device_assignment_updated', f'{account["username"]}: {len(selected)} Gerät(e)')
            # If the assignment is revoked during a remote session, stop it immediately.
            with self.admin_remote_lock:
                active_session = self.admin_remote_session
                active_did = self.admin_remote_device
                active_account = (active_session or {}).get('account') or {}
                if active_session and active_session.get('role') == 'agent_user' and active_account.get('id') == account_id and active_did not in selected:
                    self._admin_send(active_session, {'type': 'remote_forced_stop', 'reason': 'device_assignment_revoked'})
                    active_session['remote_device'] = None
                    self.admin_remote_session = None; self.admin_remote_device = None; self.admin_remote_commands.clear()
                    self._log(actor, 'remote_session_stopped_assignment_revoked', str(active_did))
            dlg.destroy()
            self.refresh_accounts()
            messagebox.showinfo(APP, f'{len(selected)} Gerät(e) wurden {account["username"]} zugewiesen.', parent=self.root)
        footer = ttk.Frame(body); footer.pack(fill='x', pady=(10,0))
        ttk.Button(footer, text='Speichern', command=save).pack(side='right', padx=(6,0))
        ttk.Button(footer, text='Abbrechen', command=dlg.destroy).pack(side='right')

    def edit_permissions(self):
        if not self.require_permission('manage_accounts'): return
        sel=self.account_tree.selection()
        if not sel: messagebox.showwarning(APP,'Wähle ein Konto aus.',parent=self.root); return
        aid=int(sel[0]); row=self.db.execute('SELECT * FROM accounts WHERE id=?',(aid,)).fetchone()
        if not row: return
        if row['is_owner']: messagebox.showwarning(APP,'Owner-Rechte können nicht bearbeitet werden.',parent=self.root); return
        try: current=set(json.loads(row['permissions']))
        except Exception: current=set()
        dlg=tk.Toplevel(self.root); dlg.title('Berechtigungen'); dlg.configure(bg='#0d1728'); dlg.transient(self.root); dlg.grab_set()
        ttk.Label(dlg,text=f'Rechte für {row["username"]}').pack(anchor='w',padx=14,pady=10); vars_={}
        allowed=list(PERMISSIONS) if self.is_owner_context() else [k for k in PERMISSIONS if k in (self.current_account or {}).get('permissions', [])]
        for key,label in PERMISSIONS.items():
            if key not in allowed: continue
            v=tk.BooleanVar(value=key in current); vars_[key]=v; ttk.Checkbutton(dlg,text=label,variable=v).pack(anchor='w',padx=16,pady=2)
        def save():
            perms=[k for k,v in vars_.items() if v.get()]
            with self.db_lock: self.db.execute('UPDATE accounts SET permissions=? WHERE id=?',(json.dumps(perms),aid)); self.db.commit()
            self._log('owner','permissions_changed',row['username']); dlg.destroy(); self.refresh_accounts()
        ttk.Button(dlg,text='Speichern',command=save).pack(pady=12)

    def reset_account_password(self):
        if not self.require_permission('manage_accounts'): return
        sel=self.account_tree.selection()
        if not sel:
            messagebox.showwarning(APP,'Wähle ein Konto aus.',parent=self.root); return
        with self.db_lock: row=self.db.execute('SELECT * FROM accounts WHERE id=?',(int(sel[0]),)).fetchone()
        if not row: return
        if row['is_owner'] and not self.is_owner_context():
            messagebox.showwarning(APP,'Nur der Owner darf das Owner-Passwort zurücksetzen.',parent=self.root); return
        password=simpledialog.askstring('Passwort zurücksetzen',f'Neues Passwort für „{row["username"]}“ (mindestens 8 Zeichen):',show='*',parent=self.root)
        if password is None: return
        if len(password)<8:
            messagebox.showerror(APP,'Bitte ein Passwort mit mindestens 8 Zeichen verwenden.',parent=self.root); return
        with self.db_lock:
            self.db.execute('UPDATE accounts SET password_hash=? WHERE id=?',(password_hash(password),row['id'])); self.db.commit()
        self._log((self.current_account or {}).get('username','unknown'),'account_password_reset',row['username'])
        messagebox.showinfo(APP,'Passwort wurde geändert.',parent=self.root)

    def toggle_account_active(self):
        if not self.require_permission('manage_accounts'): return
        sel=self.account_tree.selection()
        if not sel:
            messagebox.showwarning(APP,'Wähle ein Konto aus.',parent=self.root); return
        with self.db_lock: row=self.db.execute('SELECT * FROM accounts WHERE id=?',(int(sel[0]),)).fetchone()
        if not row: return
        if row['is_owner']:
            messagebox.showwarning(APP,'Das Owner-Konto kann nicht über diese Funktion deaktiviert werden.',parent=self.root); return
        new_active=0 if row['active'] else 1
        action='deaktivieren' if not new_active else 'aktivieren'
        if not messagebox.askyesno(APP,f'Konto „{row["username"]}“ wirklich {action}?',parent=self.root): return
        with self.db_lock:
            self.db.execute('UPDATE accounts SET active=? WHERE id=?',(new_active,row['id'])); self.db.commit()
        self._log((self.current_account or {}).get('username','unknown'),'account_enabled' if new_active else 'account_disabled',row['username'])
        self.refresh_accounts()

    def disable_account(self):
        if not self.require_permission('manage_accounts'): return
        sel=self.account_tree.selection()
        if not sel: messagebox.showwarning(APP,'Wähle ein Konto aus.',parent=self.root); return
        row=self.db.execute('SELECT * FROM accounts WHERE id=?',(int(sel[0]),)).fetchone()
        if not row or row['is_owner']: messagebox.showwarning(APP,'Das Owner-Konto kann hier nicht deaktiviert werden.',parent=self.root); return
        if messagebox.askyesno(APP,f'Konto {row["username"]} deaktivieren?',parent=self.root):
            with self.db_lock: self.db.execute('UPDATE accounts SET active=0 WHERE id=?',(row['id'],)); self.db.commit()
            self._log('owner','account_disabled',row['username']); self.refresh_accounts()

    def _device_checkbox_click(self, event):
        # Nur Klicks auf die linke Checkbox-Spalte ändern die Mehrfachauswahl.
        if self.device_tree.identify_region(event.x, event.y) != 'tree':
            return
        iid = self.device_tree.identify_row(event.y)
        if not iid:
            return
        did = str(iid)
        if did in self.checked_devices:
            self.checked_devices.discard(did)
        else:
            self.checked_devices.add(did)
        self.device_tree.item(iid, text='☑' if did in self.checked_devices else '☐')
        self.device_tree.after_idle(self.refresh_devices)
        return 'break'

    def _checked_device_ids(self):
        with self.db_lock:
            known = {str(r['id']) for r in self.db.execute('SELECT id FROM devices').fetchall()}
        self.checked_devices.intersection_update(known)
        return sorted(self.checked_devices)

    def select_all_visible_devices(self):
        for iid in self.device_tree.get_children(''):
            self.checked_devices.add(str(iid))
        self.refresh_devices()

    def clear_device_checks(self):
        self.checked_devices.clear()
        self.refresh_devices()

    def approve_selected_devices(self):
        if not self.require_permission('register_devices'): return
        ids = self._checked_device_ids()
        if not ids:
            messagebox.showwarning(APP, 'Wähle zuerst mindestens ein Gerät über die Kästchen links aus.', parent=self.root); return
        with self.db_lock:
            self.db.executemany('UPDATE devices SET approved=1 WHERE id=?', [(did,) for did in ids])
            self.db.commit()
        self._log((self.current_account or {}).get('username','unknown'), 'devices_bulk_approved', f'{len(ids)} Geräte: {", ".join(ids)}')
        self.refresh_devices(); self.refresh_overview()
        messagebox.showinfo(APP, f'Serverfreigabe für {len(ids)} Gerät(e) gesetzt. Die lokale Zustimmung am jeweiligen Gerät bleibt weiterhin erforderlich.', parent=self.root)

    def revoke_selected_devices(self):
        if not self.require_permission('manage_grants'): return
        ids = self._checked_device_ids()
        if not ids:
            messagebox.showwarning(APP, 'Wähle zuerst mindestens ein Gerät über die Kästchen links aus.', parent=self.root); return
        if not messagebox.askyesno(APP, f'Serverfreigabe für {len(ids)} ausgewählte Geräte widerrufen?', parent=self.root): return
        with self.db_lock:
            self.db.executemany('UPDATE devices SET approved=0 WHERE id=?', [(did,) for did in ids])
            self.db.commit()
        self._log((self.current_account or {}).get('username','unknown'), 'devices_bulk_revoked', f'{len(ids)} Geräte: {", ".join(ids)}')
        self.refresh_devices(); self.refresh_overview()

    def delete_selected_offline_devices(self):
        if not self.require_permission('manage_grants'): return
        ids = self._checked_device_ids()
        if not ids:
            messagebox.showwarning(APP, 'Wähle zuerst mindestens ein Gerät über die Kästchen links aus.', parent=self.root); return
        with self.client_lock: online = set(self.clients)
        removable = [did for did in ids if did not in online]
        if not removable:
            messagebox.showinfo(APP, 'Alle ausgewählten Geräte sind online. Online-Geräte werden aus Sicherheitsgründen nicht entfernt.', parent=self.root); return
        if not messagebox.askyesno(APP, f'{len(removable)} offline Gerät(e) dauerhaft aus der Geräteliste entfernen? Online-Geräte bleiben erhalten.', parent=self.root): return
        with self.db_lock:
            self.db.executemany('DELETE FROM grants WHERE device_id=?', [(did,) for did in removable])
            self.db.executemany('DELETE FROM devices WHERE id=?', [(did,) for did in removable])
            self.db.commit()
        self.checked_devices.difference_update(removable)
        self._log((self.current_account or {}).get('username','unknown'), 'devices_bulk_removed', f'{len(removable)} Offline-Geräte entfernt')
        self.refresh_devices(); self.refresh_overview()
        messagebox.showinfo(APP, f'{len(removable)} Offline-Gerät(e) entfernt. {len(ids)-len(removable)} online Gerät(e) wurden übersprungen.', parent=self.root)

    def export_selected_devices(self):
        ids = self._checked_device_ids()
        if not ids:
            messagebox.showwarning(APP, 'Wähle zuerst mindestens ein Gerät über die Kästchen links aus.', parent=self.root); return
        path = __import__('tkinter.filedialog', fromlist=['asksaveasfilename']).asksaveasfilename(parent=self.root, title='Ausgewählte Geräte exportieren', defaultextension='.csv', filetypes=[('CSV-Datei','*.csv')])
        if not path: return
        try:
            with self.db_lock:
                rows = self.db.execute('SELECT id,name,ip,approved,consent,last_seen,os,notes FROM devices WHERE id IN (%s) ORDER BY name COLLATE NOCASE' % ','.join('?' for _ in ids), ids).fetchall()
            with open(path, 'w', newline='', encoding='utf-8-sig') as handle:
                writer = csv.writer(handle, delimiter=';')
                writer.writerow(['Geräte-ID','Name','IP-Adresse','Serverfreigabe','Lokale Zustimmung','Zuletzt gesehen','Betriebssystem','Notizen'])
                for row in rows: writer.writerow([row['id'],row['name'],row['ip'], 'Ja' if row['approved'] else 'Nein','Ja' if row['consent'] else 'Nein',row['last_seen'],row['os'],row['notes']])
            self._log((self.current_account or {}).get('username','unknown'), 'devices_selected_exported', f'{len(rows)} Geräte nach CSV exportiert')
            messagebox.showinfo(APP, f'{len(rows)} Gerät(e) exportiert.\n{path}', parent=self.root)
        except Exception as exc:
            messagebox.showerror(APP, f'Export fehlgeschlagen:\n{exc}', parent=self.root)

    def copy_selected_device_ids(self):
        ids = self._checked_device_ids()
        if not ids:
            messagebox.showwarning(APP, 'Wähle zuerst mindestens ein Gerät über die Kästchen links aus.', parent=self.root); return
        self.root.clipboard_clear(); self.root.clipboard_append('\n'.join(ids))
        self._log((self.current_account or {}).get('username','unknown'), 'device_ids_copied', f'{len(ids)} Geräte-IDs kopiert')
        messagebox.showinfo(APP, f'{len(ids)} Geräte-ID(s) in die Zwischenablage kopiert.', parent=self.root)

    def refresh_devices(self):
        if not hasattr(self,'device_tree'): return
        # Incremental Treeview updates avoid destroying/recreating every row on each refresh.
        existing_items = set(self.device_tree.get_children())
        with self.db_lock: rows=self.db.execute('SELECT * FROM devices ORDER BY name COLLATE NOCASE').fetchall()
        with self.client_lock: online_ids=set(self.clients)
        query=self.device_search.get().strip().casefold() if hasattr(self,'device_search') else ''
        filter_value=self.device_filter.get() if hasattr(self,'device_filter') else 'Alle'
        visible=[]
        known_ids={str(r['id']) for r in rows}
        self.checked_devices.intersection_update(known_ids)
        for r in rows:
            searchable=' '.join(str(r[k] or '') for k in ('name','id','ip','os','notes')).casefold()
            if query and query not in searchable: continue
            online=r['id'] in online_ids
            fully_approved=bool(r['approved'] and r['consent'])
            if filter_value=='Online' and not online: continue
            if filter_value=='Offline' and online: continue
            if filter_value=='Freigabe ausstehend' and fully_approved: continue
            if filter_value=='Freigegeben' and not fully_approved: continue
            visible.append(r)
            approval_label='Freigegeben' if fully_approved else ('Serverfreigabe fehlt' if r['consent'] else 'Zustimmung fehlt')
            did=str(r['id'])
            values=(r['name'],r['device_group'] or 'Standard',r['ip'] or '-', 'Online' if online else 'Offline',approval_label,'Ja' if r['consent'] else 'Nein',r['last_seen'],r['os'] or '-')
            tags=('online' if online else 'offline', 'approved' if fully_approved else 'pending')
            if did in existing_items:
                self.device_tree.item(did, text='☑' if did in self.checked_devices else '☐', values=values, tags=tags)
                existing_items.discard(did)
            else:
                self.device_tree.insert('', 'end', iid=did, text='☑' if did in self.checked_devices else '☐', values=values, tags=tags)
        for stale_id in existing_items:
            self.device_tree.delete(stale_id)
        self.device_tree.tag_configure('online',foreground='#7be0ad'); self.device_tree.tag_configure('offline',foreground='#9aacc4'); self.device_tree.tag_configure('pending',background='#2a2117')
        approved=sum(1 for r in rows if r['approved'] and r['consent'])
        consent_missing=sum(1 for r in rows if not r['consent'])
        self.device_summary.configure(text=f'Geräte: {len(rows)}  |  Online: {len(online_ids)}  |  Freigegeben: {approved}  |  Zustimmung fehlt: {consent_missing}  |  Angezeigt: {len(visible)}  |  Markiert: {len(self.checked_devices)}')
        if hasattr(self, 'device_info_combo'):
            self.refresh_device_info_menu()

    def refresh_accounts(self):
        if not hasattr(self,'account_tree'): return
        for i in self.account_tree.get_children(): self.account_tree.delete(i)
        with self.db_lock: rows=self.db.execute('SELECT * FROM accounts ORDER BY is_owner DESC,username').fetchall()
        for r in rows:
            try: perms=json.loads(r['permissions']); summary=', '.join(PERMISSIONS.get(p,p) for p in perms)
            except Exception: summary=''
            self.account_tree.insert('', 'end', iid=str(r['id']), values=(r['username'],'OWNER' if r['is_owner'] else 'Konto',summary,'Aktiv' if r['active'] else 'Deaktiviert'))

    def refresh_logs(self):
        if not hasattr(self,'log_tree'): return
        for i in self.log_tree.get_children(): self.log_tree.delete(i)
        with self.db_lock: rows=self.db.execute('SELECT * FROM logs ORDER BY id DESC LIMIT 300').fetchall()
        for r in rows: self.log_tree.insert('', 'end', values=(r['at'],r['actor'] or '-',r['action'],r['detail'] or ''))

    def _poll_ui(self):
        try:
            while True:
                kind,payload=self.ui_events.get_nowait()
                if not self.dashboard_visible or not self.current_account:
                    continue
                if kind=='refresh_devices': self.refresh_devices()
                elif kind=='refresh_logs': self.refresh_logs()
                elif kind=='device_info': self._log('device:'+payload[0],'system_info',json.dumps(payload[1],ensure_ascii=False)[:500])
                elif kind=='refresh_overview': self.refresh_overview()
        except queue.Empty:
            pass
        except tk.TclError:
            # Widgets may be destroyed during logout; keep the service poll alive.
            pass
        if self.running: self.root.after(250,self._poll_ui)

    def close(self):
        self.stop_remote()
        self.running=False
        try: self.tcp.close()
        except OSError: pass
        try:
            if self.admin_tcp: self.admin_tcp.close()
        except OSError: pass
        try: self.db.close()
        except Exception: pass
        self.root.destroy()

if __name__=='__main__':
    if ensure_license('CORE_NEXUS_SERVER', 'CORE Nexus Server'):
        try:
            app = NexusServer()
            schedule_license_reminders(app.root, 'CORE_NEXUS_SERVER')
            app.root.mainloop()
        except OSError as e:
            tk.Tk().withdraw(); messagebox.showerror(APP, f'Server konnte Port {PORT} nicht öffnen. Ist CORE Nexus bereits gestartet?\n\n{e}')
