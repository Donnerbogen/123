# CORE Nexus Agent – Relay-only

Der Agent stellt ausschließlich eine WSS-Verbindung zum zentralen CORE Nexus Relay her. Er sendet keine UDP-LAN-Discovery-Anfragen und baut keine direkte TCP-Verbindung zum Webserver oder lokalen Server auf.

## Einrichtung
1. Die vom CORE-Nexus-Webdashboard heruntergeladene `relay_config.json` in diesen Ordner kopieren.
2. Sicherstellen, dass `room_id` dem gewünschten Server entspricht.
3. Den globalen Relay-Token aus Render als Windows-Benutzer-Environment-Variable `CORE_NEXUS_RELAY_TOKEN` setzen.
4. `install.bat` ausführen.
5. `start.bat` starten.

Alle Agents verwenden denselben globalen Relay-Token. Die Room-ID ist je Server unterschiedlich. Ein Agent kennt genau eine Room-ID.

Die lokale Zustimmung und die Freigabe des Geräts auf Serverseite bleiben Voraussetzung für Fernsteuerung.
