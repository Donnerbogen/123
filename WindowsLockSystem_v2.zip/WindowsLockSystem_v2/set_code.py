import hashlib,json
from getpass import getpass
from pathlib import Path
p=Path(__file__).resolve().parent/"config.json"
d=json.loads(p.read_text(encoding="utf-8"))
a=getpass("Neuen Entsperrcode eingeben: "); b=getpass("Code wiederholen: ")
if not a: raise SystemExit("Code darf nicht leer sein.")
if a!=b: raise SystemExit("Codes stimmen nicht überein.")
d["exit_code_sha256"]=hashlib.sha256(a.encode("utf-8")).hexdigest()
p.write_text(json.dumps(d,indent=4,ensure_ascii=False),encoding="utf-8")
print("Entsperrcode gespeichert.")