param([string]$AllowedBase64='',[int]$OwnPid=0)
$ErrorActionPreference='SilentlyContinue'
try{$allowed=@();if($AllowedBase64){$allowed=ConvertFrom-Json ([Text.Encoding]::UTF8.GetString([Convert]::FromBase64String($AllowedBase64)))}}catch{$allowed=@()}
Add-Type @"
using System; using System.Runtime.InteropServices;
public class FocusWindowApi { [DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr hWnd,int nCmdShow); }
"@ -ErrorAction SilentlyContinue
$exempt=@('explorer','dwm','shellexperiencehost','startmenuexperiencehost','searchhost','searchapp','lockapp','textinputhost','applicationframehost','systemsettings','securityhealthsystray')
$paths=@($allowed | ForEach-Object {([string]$_).ToLowerInvariant()})
Get-Process | Where-Object {$_.MainWindowHandle -ne 0} | ForEach-Object {
 $p=$_;if($OwnPid -gt 0 -and $p.Id -eq $OwnPid){return};$n=([string]$p.ProcessName).ToLowerInvariant();if($exempt -contains $n){return}
 $full='';try{$full=([string]$p.Path).ToLowerInvariant()}catch{};if(-not $full){try{$full=([string]$p.MainModule.FileName).ToLowerInvariant()}catch{}}
 if(-not $full){return};if($paths -contains $full){return};try{[FocusWindowApi]::ShowWindow([IntPtr]$p.MainWindowHandle,6)|Out-Null}catch{}
}
