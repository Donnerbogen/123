# CORE KeySafe – Linux-Paket

Dieses Paket enthält den CORE KeySafe-Desktop-Quellcode und ein Build-Skript für Linux. Es erzeugt auf dem Linux-System, auf dem es ausgeführt wird, eine eigenständige PyInstaller-Anwendung.

## Voraussetzungen

- Linux x86-64 (Build muss auf dem Zielsystem bzw. einer kompatiblen Distribution erfolgen)
- Python 3.11 oder 3.12 empfohlen (3.13 kann funktionieren, ist aber nicht in allen Abhängigkeiten garantiert)
- `python3-venv`, `python3-pip` und eine funktionierende Internetverbindung für die Installation der Python-Abhängigkeiten
- Bei Debian/Ubuntu beispielsweise:

```bash
sudo apt update
sudo apt install python3 python3-venv python3-pip build-essential
```

## Vor dem Build

1. Öffne `desktop/core_keysafe/config.py`.
2. Ersetze `LICENSE_API_URL` durch die öffentliche HTTPS-URL deines Render-Lizenzservers.
3. Setze `LICENSE_SIGNING_PUBLIC_KEY_B64` auf den **öffentlichen** Ed25519-Schlüssel, der zu deinem Lizenzserver gehört.
4. Speichere die Datei. Der private Signaturschlüssel darf niemals in diese App oder in GitHub gelangen.

## Bauen

Im Terminal in den entpackten Ordner wechseln und ausführen:

```bash
chmod +x BUILD-LINUX.sh
./BUILD-LINUX.sh
```

Nach erfolgreichem Build liegt die Anwendung in `dist/CORE KeySafe/`. Starten kannst du sie mit:

```bash
./dist/"CORE KeySafe"/"CORE KeySafe"
```

Das Skript erzeugt außerdem `dist/CORE-KeySafe.desktop`. Du kannst diese Datei in deinen Desktop-Ordner kopieren. Manche Desktop-Umgebungen verlangen, dass du dem Starter ausdrücklich vertraust bzw. „Starten erlaubst“.

## Speicherorte und Vault

Die Anwendung legt ihre Benutzerdaten unter `~/.config/Core Network/CORE KeySafe/` ab (oder unter `$XDG_CONFIG_HOME/Core Network/CORE KeySafe/`, falls gesetzt). Der Importordner befindet sich darin unter `Import/`.

## Hinweise

- Dieses ZIP enthält keine vorgefertigte Linux-Binärdatei. PyInstaller-Builds sollten auf Linux erfolgen und sind nicht als universell kompatibel über alle Distributionen hinweg garantiert.
- Der erste Build benötigt Internetzugriff, um Pakete zu installieren.
- Die App ist weiterhin auf einen korrekt konfigurierten und erreichbaren Lizenzserver angewiesen. Die Verbindung zu deiner konkreten Render-Lizenzserver muss separat getestet werden.
- Ein Build ersetzt keine Sicherheitsprüfung. Teste Lizenzaktivierung, Offline-Ticket, Lizenzfreigabe, Vault-Erstellung, Import und Wiederherstellung vor der Verteilung.

## Benutzerhandbuch
Das ausführliche, bewusst einfach gehaltene Handbuch liegt in `HANDBUCH.md` und ist nach dem Start auch über die Schaltfläche **Handbuch** in der Anwendung erreichbar.
