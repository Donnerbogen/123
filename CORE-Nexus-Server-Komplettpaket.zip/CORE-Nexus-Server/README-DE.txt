CORE Nexus – Server Einzelpaket

Enthalten sind die vollständigen Build-/Quell-Dateien des Server, die gemeinsamen CORE-UI HTML/CSS/JavaScript-Dateien sowie die zugehörige HTML-Oberflächen-Vorschau.

Build:
- Windows Build-PC mit Python 3.11/3.12 vorbereiten.
- In den Ordner Server wechseln.
- build.py ausführen.
- Das release-Verzeichnis für die Zielinstallation verwenden.

Hinweis zur UI-Integration:
Die HTML-Oberflächen und gemeinsamen Styles sind als Design-Prototyp enthalten. Die bestehende Python-App ist noch nicht mit diesen HTML-Seiten verbunden; daher werden die HTML-Dateien nicht automatisch von der erzeugten EXE angezeigt.

Daten:
Konfigurations- und Laufzeitdaten im data-Ordner der erzeugten release-App sichern und bei Updates erhalten.
Relay:
Relay-Code ist nicht Bestandteil dieser Pakete und wurde nicht verändert. Beispiel-Konfigurationsdateien enthalten keine realen Zugangsdaten.
