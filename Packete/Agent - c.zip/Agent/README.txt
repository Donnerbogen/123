CORE Nexus Agent

1. setup.bat: Menue fuer Installation/Reparatur, Deinstallation und Autostart.
2. start.bat: Startet die bereits installierte Anwendung sofort.

setup.bat fragt vor jeder Aktion nach deiner Auswahl. Bei der Deinstallation kannst du lokale Daten behalten oder loeschen.
