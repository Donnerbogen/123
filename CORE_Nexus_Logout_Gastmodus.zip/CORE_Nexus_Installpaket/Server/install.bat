@echo off
setlocal EnableExtensions
chcp 65001 >nul
cd /d "%~dp0"
title CORE Nexus - Installation

echo ============================================
echo       CORE Nexus - Installation
echo ============================================
echo.
where py >nul 2>&1
if %errorlevel%==0 (
  set "PY=py -3"
) else (
  where python >nul 2>&1
  if not %errorlevel%==0 (
    echo FEHLER: Python wurde nicht gefunden.
    echo Installiere Python von https://www.python.org/downloads/windows/
    echo Aktiviere beim Setup unbedingt "Add Python to PATH" und installiere Tcl/Tk.
    pause
    exit /b 1
  )
  set "PY=python"
)
%PY% --version
if errorlevel 1 (
  echo FEHLER: Python konnte nicht gestartet werden.
  pause
  exit /b 1
)
%PY% -c "import tkinter; print('Tkinter OK')" >nul 2>&1
if errorlevel 1 (
  echo FEHLER: Python-Tkinter fehlt. Installiere Python mit Tcl/Tk-Unterstuetzung.
  pause
  exit /b 1
)
%PY% -m pip install --disable-pip-version-check --upgrade pillow
if errorlevel 1 (
  echo FEHLER: Pillow konnte nicht installiert werden.
  echo Pruefe die Internetverbindung waehrend der Installation.
  pause
  exit /b 1
)
%PY% -m py_compile server.py
if errorlevel 1 (
  echo FEHLER: Python-Datei hat einen Syntaxfehler. Installation abgebrochen.
  pause
  exit /b 1
)
if not exist "data" mkdir "data"
>"installed.flag" echo CORE Nexus installiert am %DATE% %TIME%
echo.
echo Installation erfolgreich. Dieses Paket ist portabel und kann im Ordner bleiben.
echo Zum Starten jetzt START.bat verwenden.
echo.
pause
