@echo off
setlocal EnableExtensions
cd /d "%~dp0"
:menu
cls
echo ========================================
echo CORE Nexus Adminserver - Verwaltung
echo ========================================
echo 1. Abhaengigkeiten installieren
 echo 2. Autostart aktivieren
 echo 3. Autostart deaktivieren
 echo 4. Adminserver deinstallieren (Autostart entfernen)
 echo 5. Abbrechen
 echo.
set /p choice=Auswahl: 
if "%choice%"=="1" goto install
if "%choice%"=="2" goto enable
if "%choice%"=="3" goto disable
if "%choice%"=="4" goto uninstall
if "%choice%"=="5" exit /b 0
goto menu
:install
where py >nul 2>&1
if %errorlevel%==0 (py -3 -m pip install -r requirements.txt) else (python -m pip install -r requirements.txt)
if not exist connection_config.json copy connection_config.example.json connection_config.json >nul
echo Verbindungseinstellungen: connection_config.json
echo Server werden nach Einrichtung der Tokens automatisch gefunden.
pause
goto menu
:enable
powershell -NoProfile -ExecutionPolicy Bypass -Command "$s=(New-Object -ComObject WScript.Shell).CreateShortcut((Join-Path ([Environment]::GetFolderPath('Startup')) 'CORE Nexus Adminserver.lnk')); $s.TargetPath='%~dp0start.bat'; $s.WorkingDirectory='%~dp0'; $s.Save()"
echo Autostart eingerichtet.
pause
goto menu
:disable
powershell -NoProfile -ExecutionPolicy Bypass -Command "Remove-Item (Join-Path ([Environment]::GetFolderPath('Startup')) 'CORE Nexus Adminserver.lnk') -Force -ErrorAction SilentlyContinue"
echo Autostart entfernt.
pause
goto menu
:uninstall
powershell -NoProfile -ExecutionPolicy Bypass -Command "Remove-Item (Join-Path ([Environment]::GetFolderPath('Startup')) 'CORE Nexus Adminserver.lnk') -Force -ErrorAction SilentlyContinue"
echo Der Adminserver-Autostart wurde entfernt. Projektdateien und Einstellungen bleiben erhalten.
pause
goto menu
