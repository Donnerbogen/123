@echo off
setlocal EnableExtensions
cd /d "%~dp0"
chcp 65001 >nul
title CORE Nexus Adminserver - Diagnose
echo ========================================
echo CORE Nexus Adminserver - Diagnosemodus
echo ========================================
echo Python 3.15 wird zwingend verwendet. Dieses Fenster offen lassen.
where py >nul 2>&1
if not errorlevel 1 (
  py -V:3.15 -c "import sys; raise SystemExit(0 if sys.version_info[:2] == (3,15) else 1)" >nul 2>&1
  if not errorlevel 1 (py -V:3.15 adminserver.py) else goto no_python
) else (
  python -c "import sys; raise SystemExit(0 if sys.version_info[:2] == (3,15) else 1)" >nul 2>&1
  if not errorlevel 1 (python adminserver.py) else goto no_python
)
echo.
echo Adminserver beendet. Exitcode: %errorlevel%
pause
exit /b
:no_python
echo FEHLER: Python 3.15 wurde nicht gefunden. Keine andere Version wird verwendet.
pause
exit /b 1
