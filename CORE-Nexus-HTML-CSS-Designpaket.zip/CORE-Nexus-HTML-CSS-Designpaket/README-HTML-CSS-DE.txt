CORE NEXUS – HTML/CSS UI DESIGNPAKET

Inhalt:
- CORE-UI/styles.css: gemeinsames CORE Nexus Theme
- CORE-UI/app.js: tab navigation
- Server/ui/index.html: Server dashboard mockup
- Agent/ui/index.html: Agent dashboard mockup
- Adminserver/ui/index.html: Admin dashboard mockup
- Original-Buildpaket/: unveränderte Quelle des vorherigen EXE-Buildkits

WICHTIG: Diese HTML-Oberflächen sind ein Designprototyp, kein integrierter Ersatz für die bisherigen Python/Tkinter-Apps. Sie enthalten Demo-Statuswerte und noch keine Backend-/IPC-Verbindung. Das Original-Buildpaket wurde beigefügt und nicht überschrieben.

Relay wird in diesem Paket nicht verändert.
