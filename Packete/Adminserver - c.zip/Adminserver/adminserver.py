from __future__ import annotations
import base64, json, queue, socket, threading, time, uuid, io, hashlib, hmac, secrets, urllib.request, urllib.error, zipfile, shutil, os, re
from pathlib import Path
import tkinter as tk
from tkinter import ttk, messagebox, simpledialog
ROOT=Path(__file__).resolve().parent; CFG=ROOT/'connection_config.json'
DEFAULT_CFG={'relay_url':'https://core-nexus-relay.onrender.com/ws','relay_token':'','admin_token':''}

def load_connection_config():
    if not CFG.exists():
        CFG.write_text(json.dumps(DEFAULT_CFG,indent=2),encoding='utf-8')
    try:
        c=json.loads(CFG.read_text(encoding='utf-8'))
        return {**DEFAULT_CFG,**c}
    except Exception:
        return dict(DEFAULT_CFG)

def api_base(relay_url):
    value = str(relay_url or '').strip()
    if value.startswith('wss://'): value = 'https://' + value[6:]
    elif value.startswith('ws://'): value = 'http://' + value[5:]
    return value.split('/ws')[0].rstrip('/')

def render_admin_request(config, path, payload=None, session_token=''):
    url = api_base(config.get('relay_url')) + path
    data = json.dumps(payload or {}).encode('utf-8') if payload is not None else None
    headers = {'Content-Type':'application/json'}
    if session_token: headers['Authorization'] = 'Bearer ' + session_token
    req = urllib.request.Request(url, data=data, headers=headers, method='POST' if data is not None else 'GET')
    try:
        with urllib.request.urlopen(req, timeout=12) as response:
            return json.loads(response.read().decode('utf-8'))
    except urllib.error.HTTPError as exc:
        try: detail = json.loads(exc.read().decode('utf-8')).get('detail', str(exc))
        except Exception: detail = str(exc)
        raise RuntimeError(detail) from exc

def password_hash(password):
    salt = secrets.token_bytes(16)
    digest = hashlib.pbkdf2_hmac('sha256', password.encode('utf-8'), salt, 310_000)
    return base64.b64encode(salt + digest).decode('ascii')

def slugify(value):
    return re.sub(r'[^a-zA-Z0-9_-]+', '-', value.strip()).strip('-_')[:48] or 'CORE-Nexus-Server'

def discover_render_servers(config):
    url=str(config.get('relay_url','')).strip(); url = ('wss://' + url[8:] if url.startswith('https://') else 'ws://' + url[7:] if url.startswith('http://') else url); token=str(config.get('relay_token','')).strip()
    if not url.startswith('wss://') or not token or 'PASTE_' in token:
        return []
    import websocket
    ws=websocket.create_connection(url,timeout=8,header=[f'Authorization: Bearer {token}','X-Core-Role: admin','X-Core-Room: __registry__'],origin=url.split('/ws')[0])
    try:
        ws.settimeout(5); ws.send(json.dumps({'type':'discover'})); response=json.loads(ws.recv())
        if response.get('type')!='servers': return []
        return response.get('servers',[])
    finally:
        ws.close()

def discover_lan_servers():
    found=[]; sock=socket.socket(socket.AF_INET,socket.SOCK_DGRAM); sock.setsockopt(socket.SOL_SOCKET,socket.SO_BROADCAST,1); sock.settimeout(0.4)
    try:
        sock.sendto(b'CORE_NEXUS_DISCOVER_V1',('<broadcast>',47622))
        end=time.time()+1.5
        while time.time()<end:
            try: raw,addr=sock.recvfrom(4096)
            except socket.timeout: continue
            try:
                item=json.loads(raw.decode('utf-8'))
                if item.get('app')=='CORE Nexus' and item.get('host'):
                    found.append({'name':f"{item.get('app','CORE Nexus')} · {item['host']}",'host':item['host'],'port':int(item.get('port',47623)),'room_id':'','source':'LAN','connected':True})
            except Exception: pass
    except OSError: pass
    finally: sock.close()
    return found

class Link:
    def __init__(self,c):
        self.c=c; self.id='admin-'+uuid.uuid4().hex; self.kind=''; self.t=None; self.lock=threading.RLock(); self.pending={}; self.plock=threading.Lock(); self.events=queue.Queue(); self.running=True
        host=c.get('host','').strip(); port=int(c.get('port',47623)); err='LAN nicht konfiguriert'
        if host:
            try:
                s=socket.create_connection((host,port),timeout=5); s.settimeout(15); self.t=(s,s.makefile('rwb')); self.kind='tcp'
            except Exception as e:err=str(e)
        if not self.kind and c.get('relay_url') and c.get('relay_token') and c.get('room_id'):
            try:
                import websocket
                relay_url = c['relay_url']; relay_url = ('wss://' + relay_url[8:] if relay_url.startswith('https://') else 'ws://' + relay_url[7:] if relay_url.startswith('http://') else relay_url)
                self.t=websocket.create_connection(relay_url,timeout=12,header=[f"Authorization: Bearer {c['relay_token']}",'X-Core-Role: agent',f"X-Core-Room: {c['room_id']}"],origin=relay_url.split('/ws')[0]); self.t.settimeout(1); self.kind='relay'
            except Exception as e:err=f'{err}; Render: {e}'
        if not self.kind: raise ConnectionError(err)
        self.raw({'type':'hello','client_role':'admin','device_id':self.id,'admin_token':c['admin_token']})
        hello=self.read(timeout=12)
        if not hello or hello.get('type')!='admin_ready' or not hello.get('ok'): self.close(); raise ConnectionError('Admin-Anmeldung fehlgeschlagen: Token/Server prüfen.')
        self.name=hello.get('server_name',c.get('name','Server')); threading.Thread(target=self.reader,daemon=True).start(); threading.Thread(target=self.keepalive,daemon=True).start()
    def raw(self,obj):
        with self.lock:
            if self.kind=='tcp':
                _,f=self.t; f.write((json.dumps(obj,separators=(',',':'))+'\n').encode()); f.flush()
            else:self.t.send(json.dumps({'device_id':self.id,'payload':obj},separators=(',',':')))
    def read(self,timeout=1):
        end=time.time()+timeout
        while self.running and time.time()<end:
            try:
                if self.kind=='tcp':
                    s,f=self.t; line=f.readline()
                    if not line:raise ConnectionError('Serververbindung geschlossen')
                    return json.loads(line.decode())
                raw=self.t.recv(); env=json.loads(raw)
                if env.get('device_id')==self.id and isinstance(env.get('payload'),dict):return env['payload']
            except Exception as e:
                if 'timeout' in str(e).lower() or isinstance(e,socket.timeout):continue
                raise
        return None
    def keepalive(self):
        while self.running:
            time.sleep(7)
            if self.running:
                try:self.send('ping')
                except Exception:pass
    def reader(self):
        while self.running:
            try:
                m=self.read(2)
                if not m:continue
                rid=m.get('request_id')
                if rid:
                    with self.plock:w=self.pending.get(rid)
                    if w:w['msg']=m;w['event'].set();continue
                self.events.put(m)
            except Exception as e:
                if self.running:self.events.put({'type':'connection_lost','error':str(e)})
                break
    def req(self,typ,**kw):
        rid=uuid.uuid4().hex;w={'event':threading.Event(),'msg':None}
        with self.plock:self.pending[rid]=w
        try:
            self.raw({'type':typ,'request_id':rid,**kw})
            if not w['event'].wait(10):raise TimeoutError('Server antwortet nicht.')
            m=w['msg'] or {}
            if not m.get('ok'):raise RuntimeError(m.get('error','Fehler'))
            return m
        finally:
            with self.plock:self.pending.pop(rid,None)
    def send(self,typ,**kw):self.raw({'type':typ,**kw})
    def close(self):
        self.running=False
        try:
            if self.kind=='tcp':self.t[0].close()
            elif self.t:self.t.close()
        except Exception:pass

class Remote:
    def __init__(self,parent,link,device):
        self.link=link;self.d=device;self.win=tk.Toplevel(parent);self.win.title('CORE Nexus Adminserver | '+device['name']);self.win.geometry('1100x720');self.win.configure(bg='#080e1b')
        self.lab=tk.Label(self.win,text='Warte auf Bildschirmframe …',bg='#050914',fg='white',takefocus=1,cursor='crosshair');self.lab.pack(fill='both',expand=True,padx=10,pady=10)
        bar=ttk.Frame(self.win);bar.pack(fill='x',padx=10,pady=8);ttk.Label(bar,text='Fernsteuerung über den ausgewählten Server').pack(side='left');ttk.Button(bar,text='Sitzung beenden',command=self.close).pack(side='right')
        self.size=None;self.shown=None;self.photo=None;self.dead=False
        self.lab.bind('<Motion>',self.motion);self.lab.bind('<Button-1>',lambda e:self.click(e,'left'));self.lab.bind('<Button-3>',lambda e:self.click(e,'right'));self.lab.bind('<MouseWheel>',self.scroll);self.lab.bind('<KeyPress>',self.keydown);self.lab.bind('<KeyRelease>',self.keyup);self.win.bind('<KeyPress>',self.keydown);self.win.bind('<KeyRelease>',self.keyup);self.win.protocol('WM_DELETE_WINDOW',self.close);self.win.after(250,lambda:(self.win.focus_force(),self.lab.focus_set()));self.win.after(80,self.tick)
    def coords(self,e):
        if not self.size or not self.shown:return max(0,e.x),max(0,e.y)
        w,h=self.size;sw,sh=self.shown; x=round((e.x-(self.lab.winfo_width()-sw)/2)*w/max(1,sw));y=round((e.y-(self.lab.winfo_height()-sh)/2)*h/max(1,sh));return min(max(0,x),w-1),min(max(0,y),h-1)
    def inp(self,c):
        if not self.dead:
            try:self.link.send('remote_input',device_id=self.d['id'],command=c)
            except Exception:pass
    def motion(self,e):x,y=self.coords(e);self.inp({'kind':'move','x':x,'y':y})
    def click(self,e,b):self.lab.focus_set();x,y=self.coords(e);self.inp({'kind':'click','x':x,'y':y,'button':b})
    def scroll(self,e):x,y=self.coords(e);self.inp({'kind':'scroll','x':x,'y':y,'dy':1 if e.delta>0 else -1})
    def keydown(self,e):
        names={'Return':'enter','Tab':'tab','Escape':'esc','BackSpace':'backspace','Delete':'delete','space':'space','Up':'up','Down':'down','Left':'left','Right':'right','Shift_L':'shift','Control_L':'ctrl','Alt_L':'alt','Super_L':'win'};k=names.get(e.keysym,e.keysym.lower() if e.keysym.lower().startswith('f') and e.keysym[1:].isdigit() else (e.char if e.char and e.char.isprintable() else ''))
        if k:self.inp({'kind':'key','key':k,'action':'down' if k in ('shift','ctrl','alt','win') else 'press'})
    def keyup(self,e):
        k={'Shift_L':'shift','Control_L':'ctrl','Alt_L':'alt','Super_L':'win'}.get(e.keysym)
        if k:self.inp({'kind':'key','key':k,'action':'up'})
    def tick(self):
        if self.dead:return
        try:
            while True:
                m=self.link.events.get_nowait()
                if m.get('type')=='frame' and m.get('device_id')==self.d['id']:
                    from PIL import Image,ImageTk
                    im=Image.open(io.BytesIO(base64.b64decode(m['frame'])));self.size=im.size;im.thumbnail((max(1,self.lab.winfo_width()),max(1,self.lab.winfo_height())));self.shown=im.size;self.photo=ImageTk.PhotoImage(im);self.lab.configure(image=self.photo,text='')
                elif m.get('type')=='connection_lost':self.lab.configure(text='Verbindung verloren: '+m.get('error',''))
        except queue.Empty:pass
        except Exception as e:self.lab.configure(text='Frame-Fehler: '+str(e))
        self.win.after(80,self.tick)
    def close(self):
        if self.dead:return
        self.dead=True
        try:self.link.req('remote_stop')
        except Exception:pass
        try:self.win.destroy()
        except tk.TclError:pass

class ServerRoom:
    def __init__(self,app,c):
        self.app=app;self.c=c;self.link=None;self.win=tk.Toplevel(app.root);self.win.title('CORE Nexus | '+c['name']);self.win.geometry('1000x620')
        bar=ttk.Frame(self.win,padding=10);bar.pack(fill='x');ttk.Label(bar,text=c['name'],style='Title.TLabel').pack(side='left');ttk.Button(bar,text='Aktualisieren',command=self.refresh).pack(side='right');ttk.Button(bar,text='Fernsteuern',command=self.remote).pack(side='right',padx=6)
        cols=('name','id','online','approved','consent','ip','os');self.tree=ttk.Treeview(self.win,columns=cols,show='headings',selectmode='browse')
        for k,v in zip(cols,['Gerät','Geräte-ID','Online','Freigabe','Zustimmung','IP','Betriebssystem']):self.tree.heading(k,text=v);self.tree.column(k,width={'name':170,'id':210,'online':70,'approved':90,'consent':95,'ip':130,'os':150}[k])
        self.tree.pack(fill='both',expand=True,padx=10,pady=10);self.status=ttk.Label(self.win,text='Verbinde …');self.status.pack(anchor='w',padx=12,pady=8);self.win.protocol('WM_DELETE_WINDOW',self.close);threading.Thread(target=self.connect,daemon=True).start()
    def connect(self):
        try:
            self.link=Link(self.c);self.app.root.after(0,lambda:self.status.configure(text='Verbunden: '+self.link.name));self.refresh()
        except Exception as e:self.app.root.after(0,lambda:messagebox.showerror('CORE Nexus',str(e),parent=self.win))
    def refresh(self):
        if not self.link:return
        def run():
            try:r=self.link.req('list_devices')['devices'];self.app.root.after(0,lambda:self.rows(r))
            except Exception as e:self.app.root.after(0,lambda:self.status.configure(text='Fehler: '+str(e)))
        threading.Thread(target=run,daemon=True).start()
    def rows(self,rows):
        for i in self.tree.get_children():self.tree.delete(i)
        for d in rows:self.tree.insert('','end',iid=d['id'],values=(d.get('name',''),d['id'],'Online' if d.get('online') else 'Offline','Ja' if d.get('approved') else 'Nein','Ja' if d.get('consent') else 'Nein',d.get('ip') or '',d.get('os') or ''))
        self.status.configure(text=f'{len(rows)} Geräte. Fernsteuerung nur bei Online-Status, Serverfreigabe und lokaler Zustimmung.')
    def remote(self):
        if not self.link:return
        sel=self.tree.selection()
        if not sel:messagebox.showinfo('CORE Nexus','Wähle zuerst ein Gerät.');return
        v=self.tree.item(sel[0],'values');d={'id':sel[0],'name':v[0]}
        if v[2]!='Online' or v[3]!='Ja' or v[4]!='Ja':messagebox.showwarning('CORE Nexus','Gerät muss online, freigegeben und bestätigt sein.');return
        def run():
            try:r=self.link.req('remote_start',device_id=d['id']);self.app.root.after(0,lambda:Remote(self.win,self.link,{**d,'name':r.get('device_name',d['name'])}))
            except Exception as e:self.app.root.after(0,lambda:messagebox.showerror('CORE Nexus',str(e),parent=self.win))
        threading.Thread(target=run,daemon=True).start()
    def close(self):
        if self.link:self.link.close()
        self.win.destroy()

class App:
    def __init__(self):
        self.root=tk.Tk();self.root.title('CORE Nexus | Adminserver');self.root.geometry('1000x680');self.root.configure(bg='#080e1b')
        st=ttk.Style();st.theme_use('clam');st.configure('.',font=('Segoe UI',10));st.configure('TFrame',background='#080e1b');st.configure('TLabel',background='#080e1b',foreground='#eaf2ff');st.configure('Title.TLabel',background='#080e1b',foreground='#59d9ff',font=('Segoe UI',17,'bold'));st.configure('Treeview',background='#111b2c',foreground='#eaf2ff',fieldbackground='#111b2c',rowheight=30);st.configure('Treeview.Heading',background='#162944',foreground='#59d9ff');st.configure('TButton',padding=7)
        self.config=load_connection_config(); self.servers=[]; self.scan_running=False; self.session_token=''; self.root_username=''
        self.root.withdraw()
        self._login_window()

    def _login_window(self):
        w=tk.Toplevel(self.root); self.login_win=w; w.title('CORE Nexus | Zentrale Admin-Anmeldung'); w.geometry('520x420'); w.configure(bg='#080e1b'); w.resizable(False,False); w.protocol('WM_DELETE_WINDOW',self.root.destroy)
        body=ttk.Frame(w,padding=24); body.pack(fill='both',expand=True)
        ttk.Label(body,text='CORE NEXUS / ROOT ADMIN',style='Title.TLabel').pack(anchor='w',pady=(0,8))
        ttk.Label(body,text='Die oberste Admin-Anmeldung wird auf Render geprüft. Das Passwort wird nicht lokal gespeichert.',wraplength=450).pack(anchor='w',pady=(0,12))
        ttk.Label(body,text='Render API / Relay URL').pack(anchor='w'); self.login_url=ttk.Entry(body); self.login_url.pack(fill='x',pady=(2,10)); self.login_url.insert(0,api_base(self.config.get('relay_url','https://core-nexus-relay.onrender.com/ws')))
        ttk.Label(body,text='Benutzername aus Render').pack(anchor='w'); self.login_user=ttk.Entry(body); self.login_user.pack(fill='x',pady=(2,10)); self.login_user.insert(0,'core-owner')
        ttk.Label(body,text='Passwort aus CORE_NEXUS_ROOT_PASSWORD').pack(anchor='w'); self.login_pass=ttk.Entry(body,show='*'); self.login_pass.pack(fill='x',pady=(2,10)); self.login_pass.bind('<Return>',lambda e:self.login())
        self.login_status=ttk.Label(body,text='Bitte anmelden.'); self.login_status.pack(anchor='w',pady=(0,8))
        ttk.Button(body,text='Anmelden',command=self.login).pack(anchor='e')
        w.transient(self.root); w.grab_set(); w.focus_force()

    def login(self):
        username=self.login_user.get().strip(); password=self.login_pass.get(); base=self.login_url.get().strip().rstrip('/')
        if base.endswith('/ws'): base=base[:-3]
        if not username or not password or not base.startswith(('https://','http://')):
            self.login_status.configure(text='URL, Benutzername und Passwort werden benötigt.'); return
        self.login_status.configure(text='Prüfe Anmeldung bei Render …')
        def worker():
            try:
                cfg={**self.config,'relay_url':base+'/ws'}
                result=render_admin_request(cfg,'/api/admin/login',{'username':username,'password':password})
                token=result.get('session_token','')
                if not token: raise RuntimeError('Render hat keine Sitzung ausgegeben.')
                self.session_token=token; self.root_username=username; self.config['relay_url']=base+'/ws'
                self.root.after(0,self._login_success)
            except Exception as e:self.root.after(0,lambda:self.login_status.configure(text='Anmeldung fehlgeschlagen: '+str(e)))
        threading.Thread(target=worker,daemon=True).start()

    def _login_success(self):
        try:self.login_win.grab_release();self.login_win.destroy()
        except Exception:pass
        self.root.deiconify(); self._build_dashboard(); self.refresh(); self.root.after(20000,self.periodic_refresh)

    def _build_dashboard(self):
        head=ttk.Frame(self.root,padding=16);head.pack(fill='x');ttk.Label(head,text='CORE NEXUS / ADMIN CONTROL CENTER',style='Title.TLabel').pack(side='left');ttk.Button(head,text='Verbindungseinstellungen',command=self.settings).pack(side='right');ttk.Button(head,text='Abmelden',command=self.logout).pack(side='right',padx=8)
        ttk.Label(self.root,text='Angemeldet als oberster Administrator: '+self.root_username+' · Server werden automatisch über Render und LAN gesucht.',padding=16,wraplength=930).pack(anchor='w')
        self.tree=ttk.Treeview(self.root,columns=('name','room','source','status'),show='headings',selectmode='browse')
        for k,v in [('name','Serverraum / Server'),('room','Render-Raum-ID'),('source','Erkannt über'),('status','Status')]:self.tree.heading(k,text=v)
        self.tree.column('name',width=300);self.tree.column('room',width=300);self.tree.column('source',width=140);self.tree.column('status',width=120);self.tree.pack(fill='both',expand=True,padx=16,pady=8)
        b=ttk.Frame(self.root,padding=16);b.pack(fill='x');ttk.Button(b,text='Jetzt suchen',command=self.refresh).pack(side='left');ttk.Button(b,text='Server öffnen',command=self.open).pack(side='left',padx=8);ttk.Button(b,text='Neuen Server erstellen',command=self.create_server).pack(side='left')
        self.status=ttk.Label(self.root,text='Bereit zur Serversuche.',padding=16);self.status.pack(anchor='w');self.tree.bind('<Double-1>',lambda e:self.open())

    def logout(self):
        self.session_token=''; self.root_username='';
        for child in self.root.winfo_children():
            try: child.destroy()
            except tk.TclError: pass
        self.root.withdraw(); self._login_window()

    def require_session(self):
        if not self.session_token: raise RuntimeError('Bitte zuerst als zentraler Administrator anmelden.')
        render_admin_request(self.config,'/api/admin/verify',session_token=self.session_token)

    def create_server(self):
        try:self.require_session()
        except Exception as e:messagebox.showerror('CORE Nexus',str(e),parent=self.root);self.logout();return
        if not self.config.get('relay_token') or 'PASTE_' in self.config.get('relay_token','') or not self.config.get('admin_token'):
            messagebox.showwarning('CORE Nexus','Öffne zuerst Verbindungseinstellungen und trage den Render Relay Token sowie einen langen Service-Admin-Token ein. Diese Werte werden für die neue Serverinstallation benötigt.',parent=self.root);return
        name=simpledialog.askstring('Neuen Server erstellen','Name des neuen Servers / Serverraums:',parent=self.root)
        if not name or len(name.strip())<2:return
        owner=simpledialog.askstring('Owner-Konto erstellen','Benutzername des Owner-Kontos für diesen Server:',parent=self.root)
        if not owner or len(owner.strip())<2:messagebox.showwarning('CORE Nexus','Owner-Benutzername muss mindestens 2 Zeichen haben.',parent=self.root);return
        password=simpledialog.askstring('Owner-Konto erstellen','Passwort für den Server-Owner (mindestens 12 Zeichen):',show='*',parent=self.root)
        if not password or len(password)<12:messagebox.showwarning('CORE Nexus','Das Owner-Passwort muss mindestens 12 Zeichen haben.',parent=self.root);return
        confirm=simpledialog.askstring('Owner-Konto bestätigen','Owner-Passwort erneut eingeben:',show='*',parent=self.root)
        if password!=confirm:messagebox.showerror('CORE Nexus','Die Passwörter stimmen nicht überein.',parent=self.root);return
        source=ROOT.parent/'Server'
        if not (source/'server.py').exists():messagebox.showerror('CORE Nexus','Der Server-Quellordner fehlt neben Adminserver/.',parent=self.root);return
        room='core-nexus-'+uuid.uuid4().hex
        slug=slugify(name)
        outdir=ROOT/'created_servers';outdir.mkdir(exist_ok=True)
        package=outdir/f'{slug}_{room[-8:]}.zip'
        owner_hash=password_hash(password)
        try:
            self.require_session()
            with zipfile.ZipFile(package,'w',zipfile.ZIP_DEFLATED) as z:
                for f in source.rglob('*'):
                    if not f.is_file() or '__pycache__' in f.parts or f.name in ('core_nexus.sqlite3',):continue
                    rel=Path('Server')/f.relative_to(source)
                    if f.name in ('relay_config.json','admin_config.json'):continue
                    z.write(f,rel.as_posix())
                relay_cfg={'transport':'websocket-relay','relay_url':self.config['relay_url'],'relay_token_env':'CORE_NEXUS_RELAY_TOKEN','relay_token':self.config['relay_token'],'room_id':room,'server_name':name.strip(),'enabled':True}
                admin_cfg={'admin_token':self.config['admin_token'],'bootstrap_owner_username':owner.strip(),'bootstrap_owner_password_hash':owner_hash}
                z.writestr('Server/relay_config.json',json.dumps(relay_cfg,indent=2,ensure_ascii=False)+'\n')
                z.writestr('Server/admin_config.json',json.dumps(admin_cfg,indent=2,ensure_ascii=False)+'\n')
                z.writestr('Server/NEUER_SERVER.txt',f'CORE Nexus – neuer Server\nName: {name.strip()}\nRaum-ID: {room}\nOwner-Benutzername: {owner.strip()}\nDas Owner-Passwort wurde bei der Erstellung eingegeben und wird nicht im Paket gespeichert. Bewahre es sicher auf.\nBeim ersten Start wird der Owner-Account sicher aus dem gespeicherten Passwort-Hash angelegt.\n')
            messagebox.showinfo('CORE Nexus','Serverpaket erstellt.\n\nDatei:\n'+str(package)+'\n\nOwner: '+owner.strip()+'\nRaum-ID: '+room+'\n\nEntpacke das Paket auf dem neuen Server-PC und starte Server/setup.bat, danach Server/start.bat.',parent=self.root)
        except Exception as e:messagebox.showerror('CORE Nexus','Server konnte nicht erstellt werden: '+str(e),parent=self.root)

    def settings(self):
        try:self.require_session()
        except Exception as e:messagebox.showerror('CORE Nexus',str(e),parent=self.root);self.logout();return
        w=tk.Toplevel(self.root);w.title('CORE Nexus – Relay-Einstellungen');w.geometry('600x330');w.transient(self.root);w.grab_set();body=ttk.Frame(w,padding=16);body.pack(fill='both',expand=True);entries={}
        for key,label in [('relay_url','Render WebSocket URL (wss://…/ws)'),('relay_token','CORE_NEXUS_RELAY_TOKEN aus Render'),('admin_token','Service-Admin-Token für Serververbindungen')]:
            ttk.Label(body,text=label).pack(anchor='w',pady=(5,1));e=ttk.Entry(body,show='*' if 'token' in key else None);e.pack(fill='x');e.insert(0,str(self.config.get(key,'')));entries[key]=e
        ttk.Label(body,text='Das oberste Konto wird ausschließlich bei Render geprüft. Benutzername und Passwort werden nicht in dieser Konfigurationsdatei gespeichert.',wraplength=540).pack(anchor='w',pady=8)
        def save():
            new={k:entries[k].get().strip() for k in entries}
            if not new['relay_url'].startswith(('wss://','https://')) or not new['relay_token'] or not new['admin_token']:
                messagebox.showwarning('CORE Nexus','Bitte Relay-URL, Relay-Token und Service-Admin-Token vollständig eintragen.',parent=w);return
            if new['relay_url'].startswith('https://'):new['relay_url']='wss://'+new['relay_url'][8:]
            self.config=new;CFG.write_text(json.dumps(new,indent=2,ensure_ascii=False),encoding='utf-8');w.destroy();self.refresh()
        ttk.Button(body,text='Speichern und suchen',command=save).pack(anchor='e',pady=6)
    def periodic_refresh(self):
        self.refresh();self.root.after(20000,self.periodic_refresh)
    def refresh(self):
        if self.scan_running:return
        self.scan_running=True;self.status.configure(text='Suche nach Servern über Render und LAN …')
        def worker():
            render=[];lan=[];errors=[]
            try:render=discover_render_servers(self.config)
            except Exception as e:errors.append('Render: '+str(e))
            try:lan=discover_lan_servers()
            except Exception as e:errors.append('LAN: '+str(e))
            merged=[];seen=set()
            for r in render:
                room=str(r.get('room','')).strip()
                if not room:continue
                item={'name':f"{r.get('name') or 'CORE Nexus'} · {room[-8:]}",'room_id':room,'host':'','port':47623,'source':'Render','connected':bool(r.get('connected',True)),'relay_url':self.config.get('relay_url',''),'relay_token':self.config.get('relay_token',''),'admin_token':self.config.get('admin_token','')}
                merged.append(item);seen.add(('room',room))
            for l in lan:
                key=('host',l.get('host'))
                if key not in seen:
                    merged.append({**l,'admin_token':self.config.get('admin_token','')});seen.add(key)
            self.root.after(0,lambda:self._show_servers(merged,errors))
        threading.Thread(target=worker,daemon=True).start()
    def _show_servers(self,servers,errors):
        self.scan_running=False;self.servers=servers
        for i in self.tree.get_children():self.tree.delete(i)
        for i,c in enumerate(servers):self.tree.insert('','end',iid=str(i),values=(c.get('name','CORE Nexus'),c.get('room_id') or '—',c.get('source','LAN'),'Online' if c.get('connected',True) else 'Offline'))
        msg=f'{len(servers)} Server gefunden. Automatische Suche alle 20 Sekunden.'
        if errors and not servers:msg+=' Konfiguration prüfen: '+ ' | '.join(errors)
        elif errors:msg+=' Hinweis: '+' | '.join(errors)
        self.status.configure(text=msg)
    def open(self):
        try:self.require_session()
        except Exception as e:messagebox.showerror('CORE Nexus',str(e),parent=self.root);self.logout();return
        s=self.tree.selection()
        if not s:messagebox.showinfo('CORE Nexus','Wähle zuerst einen gefundenen Server aus.');return
        try:c=self.servers[int(s[0])]
        except (ValueError,IndexError):return
        if not c.get('admin_token'):
            messagebox.showwarning('CORE Nexus','Öffne Verbindungseinstellungen und trage den gemeinsamen Admin-Token ein.');return
        ServerRoom(self,c)
    def run(self):self.root.mainloop()
if __name__=='__main__':App().run()
