FOCUS SYSTEM 3.0 – BUILD- UND BENUTZERHANDBUCH
================================================

WAS DU BENÖTIGST
- Windows 10 oder Windows 11 (64 Bit)
- Python 3.10 oder neuer NUR für den einmaligen Build
- Internetverbindung beim ersten Build

Du musst Node.js und npm NICHT selbst installieren. build.py lädt eine portable Node.js-Version in den Projektordner .build-tools herunter. Sie wird nicht systemweit installiert.

EINMALIGER BUILD
1. Entpacke den gesamten Projektordner.
2. Starte build.py per Doppelklick.
3. Warte, bis BUILD ERFOLGREICH angezeigt wird.
4. Im Projektordner findest du Focus-System-Windows.zip.
5. Entpacke diese ZIP an den gewünschten Ort.
6. Starte Focus System.exe im Ordner Focus-System.

WICHTIG: Für den Build wird Internet benötigt, da Node.js und die Electron-Build-Abhängigkeiten geladen werden. Der Build benötigt mehrere GB freien Speicherplatz als Reserve. Der Ziel-PC benötigt weder Python noch Node.js/npm.

WINDOWS-SUCHE
- Windows-Suche-einrichten.bat fügt eine Verknüpfung zur Windows-Startmenüsuche hinzu. In der fertigen Build-ZIP liegen die BAT-Dateien neben dem Ordner Focus-System.
- Windows-Suche-entfernen.bat entfernt ausschließlich diese Verknüpfung.
- Beide BAT-Dateien sind unabhängig vom Programmstart und können separat ausgeführt werden.
- Die Verknüpfung kopiert keine Programmdateien. Wird der Programmordner verschoben, muss die Einrichten-BAT erneut ausgeführt werden.
- Lege die BAT-Dateien neben den Ordner Focus-System oder nutze die im Projektordner vorhandene dist-Ausgabe.

DATEN UND PORTABILITÄT
config.json und focus.log werden neben der EXE gespeichert. Verschiebe immer den gesamten Focus-System-Ordner, nicht nur die EXE.

SICHERHEITSHINWEISE
- Das Hauptpasswort wird entsprechend der Vorgabe im Klartext in config.json gespeichert. Schütze den Programmordner entsprechend.
- Das Screen-Lock-Passwort wird nur während der jeweiligen Sitzung im Arbeitsspeicher gehalten.
- Focus-Modus und Screen-Lock minimieren Fenster, beenden aber keine Prozesse. Windows-Systemfunktionen, administrative Werkzeuge, Neustart oder Herunterfahren können die Sperre umgehen. Dies ist kein Ersatz für die Windows-Kontosperre.
- Die Fenstersteuerung ist eine Konzentrationshilfe; einzelne Anwendungen oder geschützte Windows-Fenster können technisch nicht zuverlässig kontrolliert werden.

HINWEIS ZUM AKTUELLEN UMFANG
Diese Ausgabe ist ein portabler Entwicklungsstand mit Kategorien, Programm-Allowlist, Zeitplanung, Screen-Lock, Protokollierung und Tray-Steuerung. Bitte vor produktiver Nutzung auf dem eigenen Windows-PC testen.
